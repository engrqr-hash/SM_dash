# AI-Powered Social Media Manager

## Overview

This is a comprehensive AI-powered social media management application built as a full-stack web application. The platform enables users to create, schedule, and manage social media content across multiple platforms (Instagram, Facebook, Twitter/X, LinkedIn) with AI assistance for content generation, hashtag suggestions, and analytics insights. The application features a modern dashboard interface with real-time preview capabilities, engagement management, and comprehensive analytics tools.

## Recent Changes (September 2025)

### Scheduled Posts Functionality
- **Complete Scheduling System**: Implemented end-to-end post scheduling with date/time picker UI
- **Real-time Calendar Integration**: Calendar now displays actual scheduled posts with platform icons on correct dates
- **Performance Optimization**: Implemented optimistic updates for instant UI feedback on schedule/draft operations
- **API Integration**: All scheduling buttons now connect to backend endpoints with proper validation
- **Data Management**: UpcomingPosts component displays real API data instead of mock data with proper loading states

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: Tailwind CSS with custom design system based on Material Design principles
- **Component Library**: shadcn/ui components built on Radix UI primitives for accessibility
- **State Management**: React Query (@tanstack/react-query) for server state and caching
- **Styling Approach**: Utility-first CSS with custom CSS variables for theming

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for full-stack type safety
- **API Design**: RESTful API architecture with `/api` prefix routing
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database Schema**: PostgreSQL with user authentication schema
- **Session Management**: Built-in session handling with middleware

### UI/UX Design System
- **Design Language**: Material Design principles with system-based approach
- **Color Scheme**: Dual-mode support (light/dark) with brand colors (blue primary, purple secondary)
- **Typography**: Inter font family for clean, modern appearance
- **Component Patterns**: Card-based layouts, responsive grid systems, and mobile-first design
- **Interactive Elements**: Hover states, elevation effects, and smooth transitions

### Data Storage Architecture
- **Primary Database**: PostgreSQL via Neon Database serverless platform
- **ORM Layer**: Drizzle ORM with schema-first approach and Zod validation
- **Migration System**: Drizzle Kit for database schema management
- **Connection**: Connection pooling through @neondatabase/serverless

### Authentication & Authorization
- **User Management**: Custom user schema with username/password authentication
- **Session Storage**: PostgreSQL-based session storage using connect-pg-simple
- **Security**: Input validation using Zod schemas and type-safe database operations

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **drizzle-zod**: Integration between Drizzle and Zod for schema validation
- **@tanstack/react-query**: Server state management and caching

### UI Component Libraries
- **@radix-ui/***: Accessible, unstyled UI primitives for complex components
- **class-variance-authority**: Component variant management
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library for consistent iconography

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Static type checking
- **esbuild**: Fast JavaScript bundler for production
- **@replit/vite-plugin-runtime-error-modal**: Development error handling

### Social Media Platform Integration
The application is designed to integrate with major social media platforms:
- Instagram API for post publishing and analytics
- Facebook Graph API for page management
- Twitter/X API for tweet scheduling and engagement
- LinkedIn API for professional content distribution

### Third-Party Services
- **Font Services**: Google Fonts (Inter, JetBrains Mono)
- **Icon Services**: Font Awesome for social media and interface icons
- **Development Platform**: Replit for hosting and development environment