# Design Guidelines for AI-Powered Social Media Manager

## Design Approach
**System-Based Approach** using Material Design principles for this productivity-focused application. The tool is utility-focused with information-dense content requiring efficient workflows and clear data hierarchy.

## Core Design Elements

### Color Palette
**Light Mode:**
- Primary: 219 94% 55% (vibrant blue)
- Secondary: 270 30% 40% (muted purple)
- Background: 0 0% 98% (near white)
- Surface: 0 0% 100% (pure white)
- Text: 222 84% 5% (near black)

**Dark Mode:**
- Primary: 219 94% 65% (lighter blue)
- Secondary: 270 40% 65% (lighter purple)
- Background: 222 47% 11% (dark blue-gray)
- Surface: 215 28% 17% (elevated dark)
- Text: 210 40% 98% (near white)

### Typography
- **Primary Font**: Inter via Google Fonts
- **Code Font**: JetBrains Mono for code snippets
- Hierarchy: text-4xl, text-2xl, text-xl, text-lg, text-base, text-sm

### Layout System
**Spacing Units**: Tailwind 2, 4, 6, 8, 12, 16
- Consistent padding: p-4, p-6, p-8
- Margins: m-2, m-4, m-8
- Grid gaps: gap-4, gap-6, gap-8

### Component Library

**Navigation:**
- Top navigation bar with logo, main sections, and user profile
- Sidebar navigation for dashboard sections
- Breadcrumb navigation for deep pages

**Cards & Containers:**
- Post preview cards with rounded corners (rounded-lg)
- Analytics cards with subtle shadows (shadow-sm)
- Settings panels with clear sectioning

**Forms:**
- Clean input fields with focus states
- Multi-step wizards for content creation
- Toggle switches for settings
- Dropdown menus for platform selection

**Data Displays:**
- Analytics charts and graphs
- Performance metrics tables
- Social media feed previews
- Engagement statistics

**Interactive Elements:**
- Primary buttons (solid blue)
- Secondary buttons (outline)
- Icon buttons for quick actions
- Floating action button for new posts

## Visual Hierarchy
- **Dashboard Focus**: Clean, scannable layout prioritizing key metrics
- **Content Creation**: Step-by-step workflow with clear progress indicators
- **Analytics**: Data visualization with clear labeling and context
- **Settings**: Grouped sections with clear categorization

## Interactions
- Subtle hover states on interactive elements
- Loading states for API calls and processing
- Success/error feedback for user actions
- Minimal, purposeful animations for state changes

## Images
**Hero Section**: Medium-sized hero image (not full-viewport) showing diverse social media platforms or team collaboration. Place at top of landing page.

**Dashboard Icons**: Use Heroicons for consistent iconography throughout the interface - social media platform icons, analytics charts, settings gear, user avatars.

**Content Previews**: Placeholder images for social media post previews in various aspect ratios (square, landscape, portrait).

This design prioritizes functionality and clarity while maintaining a modern, professional appearance suitable for business users managing social media presence.