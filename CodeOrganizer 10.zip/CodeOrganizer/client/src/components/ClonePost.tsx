import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import PlatformToggle from "./PlatformToggle";

interface ClonePostProps {
  onClone: (cloneData: any) => void;
  onViewChange?: (view: string) => void;
}

interface ExistingPost {
  id: string;
  content: string;
  postName: string;
  campaignLabel: string;
  platforms: string[];
  scheduledTime?: string;
  status: 'draft' | 'scheduled' | 'published';
  engagement?: {
    likes: number;
    comments: number;
    shares: number;
  };
}

const mockExistingPosts: ExistingPost[] = [
  {
    id: "1",
    content: "🚀 Excited to announce our new product launch! Join us for an exclusive preview this Friday. #ProductLaunch #Innovation #TechNews",
    postName: "Product Launch Announcement",
    campaignLabel: "product-launch",
    platforms: ["instagram", "facebook", "linkedin"],
    scheduledTime: "2025-09-20T10:00:00",
    status: "scheduled",
    engagement: { likes: 127, comments: 23, shares: 15 }
  },
  {
    id: "2", 
    content: "Tips for boosting productivity: 1. Set clear goals 2. Eliminate distractions 3. Take regular breaks 4. Use time-blocking. What works best for you?",
    postName: "Productivity Tips",
    campaignLabel: "engagement",
    platforms: ["twitter", "linkedin"],
    status: "published",
    engagement: { likes: 89, comments: 34, shares: 28 }
  },
  {
    id: "3",
    content: "Behind the scenes at our office! Our team is working hard to bring you the best experience possible. #TeamWork #OfficeLife #Company",
    postName: "Behind the Scenes",
    campaignLabel: "brand-awareness",
    platforms: ["instagram", "facebook"],
    status: "draft"
  }
];

export default function ClonePost({ onClone, onViewChange }: ClonePostProps) {
  const [selectedPost, setSelectedPost] = useState<ExistingPost | null>(null);
  const [cloneContent, setCloneContent] = useState("");
  const [clonePostName, setClonePostName] = useState("");
  const [clonePlatforms, setClonePlatforms] = useState(new Set<string>());
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("09:00");
  const [modifyContent, setModifyContent] = useState(false);

  const platforms = [
    { id: 'facebook', name: 'Facebook', icon: 'fab fa-facebook-f', color: '#1877f2' },
    { id: 'instagram', name: 'Instagram', icon: 'fab fa-instagram', color: '#E4405F' },
    { id: 'twitter', name: 'X (Twitter)', icon: 'fab fa-x-twitter', color: '#000000' },
    { id: 'linkedin', name: 'LinkedIn', icon: 'fab fa-linkedin-in', color: '#0077b5' },
  ];

  const handlePostSelect = (post: ExistingPost) => {
    setSelectedPost(post);
    setCloneContent(post.content);
    setClonePostName(`${post.postName} (Clone)`);
    setClonePlatforms(new Set(post.platforms));
  };

  const handlePlatformToggle = (platformId: string) => {
    const newActive = new Set(clonePlatforms);
    if (newActive.has(platformId)) {
      newActive.delete(platformId);
    } else {
      newActive.add(platformId);
    }
    setClonePlatforms(newActive);
  };

  const handleCloneSubmit = () => {
    if (!selectedPost) return;

    const cloneData = {
      originalPostId: selectedPost.id,
      content: cloneContent,
      postName: clonePostName,
      campaignLabel: selectedPost.campaignLabel,
      platforms: Array.from(clonePlatforms),
      scheduledTime: scheduleDate && scheduleTime ? `${scheduleDate}T${scheduleTime}:00` : null,
      isClone: true
    };

    onClone(cloneData);
    console.log('Post cloned:', cloneData);
    
    // Reset form
    setSelectedPost(null);
    setCloneContent("");
    setClonePostName("");
    setClonePlatforms(new Set());
    setScheduleDate("");
    setScheduleTime("09:00");
    setModifyContent(false);
  };

  const getPlatformIcon = (platformId: string) => {
    const platform = platforms.find(p => p.id === platformId);
    return platform ? platform.icon : 'fas fa-share-alt';
  };

  const getPlatformColor = (platformId: string) => {
    const platform = platforms.find(p => p.id === platformId);
    return platform ? platform.color : '#6B7280';
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4" data-testid="clone-post-manager">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-lg font-bold text-gray-800">Clone Post</h1>
          <div className="flex items-center gap-1 text-xs text-gray-600">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span>Clone to Calendar</span>
          </div>
        </div>

        {!selectedPost ? (
          <>
            {/* Existing Posts Library */}
            <div className="mb-4">
              <Label className="text-xs font-semibold text-gray-700 mb-2 flex items-center">
                <i className="fas fa-copy mr-1 text-blue-500 text-xs"></i>
                Select Post to Clone
              </Label>
              <div className="space-y-3">
                {mockExistingPosts.map((post) => (
                  <Card 
                    key={post.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow border-gray-200"
                    onClick={() => handlePostSelect(post)}
                    data-testid={`post-card-${post.id}`}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-sm font-semibold text-gray-800">
                            {post.postName}
                          </CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              post.status === 'published' ? 'bg-green-100 text-green-700' :
                              post.status === 'scheduled' ? 'bg-blue-100 text-blue-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {post.status}
                            </span>
                            {post.campaignLabel && (
                              <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded-full">
                                {post.campaignLabel}
                              </span>
                            )}
                          </div>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="text-xs"
                          data-testid={`button-clone-${post.id}`}
                        >
                          <i className="fas fa-copy mr-1"></i>
                          Clone
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-xs text-gray-600 mb-3 line-clamp-2">
                        {post.content}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {post.platforms.map((platformId) => (
                            <div 
                              key={platformId}
                              className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs"
                              style={{ backgroundColor: getPlatformColor(platformId) }}
                              title={platformId}
                            >
                              <i className={getPlatformIcon(platformId)}></i>
                            </div>
                          ))}
                        </div>
                        
                        {post.engagement && (
                          <div className="flex items-center gap-3 text-xs text-gray-500">
                            <span><i className="fas fa-heart mr-1"></i>{post.engagement.likes}</span>
                            <span><i className="fas fa-comment mr-1"></i>{post.engagement.comments}</span>
                            <span><i className="fas fa-share mr-1"></i>{post.engagement.shares}</span>
                          </div>
                        )}
                      </div>
                      
                      {post.scheduledTime && (
                        <div className="mt-2 pt-2 border-t border-gray-100">
                          <p className="text-xs text-gray-500">
                            <i className="fas fa-clock mr-1"></i>
                            Scheduled: {new Date(post.scheduledTime).toLocaleString()}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Clone Configuration */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-2 mb-3">
                <i className="fas fa-info-circle text-blue-600 text-sm mt-0.5"></i>
                <div>
                  <p className="text-xs text-blue-800 font-medium">Cloning: {selectedPost.postName}</p>
                  <p className="text-xs text-blue-700">
                    Original posted to: {selectedPost.platforms.join(", ")}
                  </p>
                </div>
              </div>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setSelectedPost(null)}
                className="text-xs"
                data-testid="button-back-to-selection"
              >
                <i className="fas fa-arrow-left mr-1"></i>
                Choose Different Post
              </Button>
            </div>

            {/* Content Modification */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <Label className="text-xs font-semibold text-gray-700">Post Content</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="modify-content"
                    checked={modifyContent}
                    onCheckedChange={(checked) => setModifyContent(checked as boolean)}
                    data-testid="checkbox-modify-content"
                  />
                  <Label htmlFor="modify-content" className="text-xs text-gray-600">
                    Modify Content
                  </Label>
                </div>
              </div>
              {modifyContent ? (
                <Textarea 
                  className="min-h-[80px] resize-none text-sm"
                  value={cloneContent}
                  onChange={(e) => setCloneContent(e.target.value)}
                  data-testid="textarea-clone-content"
                />
              ) : (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                  <p className="text-sm text-gray-700">{cloneContent}</p>
                </div>
              )}
            </div>

            {/* Clone Post Name */}
            <div className="mb-4">
              <Label className="text-xs font-semibold text-gray-700 mb-1">Clone Post Name</Label>
              <Input 
                type="text" 
                value={clonePostName}
                onChange={(e) => setClonePostName(e.target.value)}
                data-testid="input-clone-post-name"
              />
            </div>

            {/* Platform Selection */}
            <div className="mb-4">
              <Label className="text-xs font-semibold text-gray-700 mb-2 flex items-center">
                <i className="fas fa-share-alt mr-1 text-blue-500 text-xs"></i>
                Target Platforms
              </Label>
              <PlatformToggle 
                platforms={platforms}
                activePlatforms={clonePlatforms}
                onToggle={handlePlatformToggle}
              />
            </div>

            {/* Schedule Clone */}
            <div className="mb-4">
              <Label className="text-xs font-semibold text-gray-700 mb-2 flex items-center">
                <i className="fas fa-calendar mr-1 text-green-500 text-xs"></i>
                Schedule Clone (Optional)
              </Label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs text-gray-600 mb-1">Date</Label>
                  <Input 
                    type="date" 
                    value={scheduleDate}
                    onChange={(e) => setScheduleDate(e.target.value)}
                    data-testid="input-schedule-date"
                  />
                </div>
                <div>
                  <Label className="text-xs text-gray-600 mb-1">Time</Label>
                  <Input 
                    type="time" 
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                    data-testid="input-schedule-time"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button 
                className="flex-1"
                onClick={handleCloneSubmit}
                data-testid="button-clone-submit"
              >
                <i className="fas fa-copy mr-2"></i>
                {scheduleDate ? 'Clone & Schedule' : 'Clone Post'}
              </Button>
              <Button 
                variant="outline"
                onClick={() => setSelectedPost(null)}
                data-testid="button-cancel-clone"
              >
                Cancel
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}