import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import PlatformToggle from "./PlatformToggle";
import type { InsertPost } from '@shared/schema';

interface PostComposerProps {
  onPost?: (postData: any) => void;
  onViewChange?: (view: string) => void;
  onPreviewToggle?: (visible: boolean) => void;
  isPreviewVisible?: boolean;
  onPostCreated?: () => void;
}

export default function PostComposer({ onPost, onViewChange, onPreviewToggle, isPreviewVisible = false, onPostCreated }: PostComposerProps) {
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [postName, setPostName] = useState("");
  const [campaignLabel, setCampaignLabel] = useState("");
  const [postType, setPostType] = useState("text");
  const [firstComment, setFirstComment] = useState("");
  const [enableFirstComment, setEnableFirstComment] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Evergreen/Repeat Post settings
  const [isEvergreen, setIsEvergreen] = useState(false);
  const [repeatInterval, setRepeatInterval] = useState<"daily" | "weekly" | "monthly">("daily");
  const [repeatDays, setRepeatDays] = useState<string[]>([]);
  const [monthlyDay, setMonthlyDay] = useState(1);
  const [repeatTime, setRepeatTime] = useState("09:00");
  const [endDate, setEndDate] = useState("");
  const [maxRepeats, setMaxRepeats] = useState("");
  
  // Scheduling state
  const [scheduledDate, setScheduledDate] = useState("");
  const [scheduledTime, setScheduledTime] = useState("09:00");

  // Separate mutations for independent button behavior
  const draftMutation = useMutation({
    mutationFn: async (postData: InsertPost) => {
      console.time('draft-request');
      const response = await apiRequest('POST', '/api/posts', postData);
      console.timeEnd('draft-request');
      return response.json();
    },
    onSuccess: (newPost) => {
      queryClient.setQueryData(['/api/posts'], (old: any) => {
        if (!old) return [newPost];
        return [newPost, ...old];
      });
      
      toast({
        title: 'Draft Saved Successfully',
        description: 'Your post has been saved as draft.',
        variant: 'default'
      });
      
      // Reset form
      setContent('');
      setPostName('');
      setCampaignLabel('');
      setFirstComment('');
      setEnableFirstComment(false);
      setIsEvergreen(false);
      onPostCreated?.();
    },
    onError: (err) => {
      toast({
        title: 'Failed to Save Draft',
        description: err.message || 'Please try again.',
        variant: 'destructive'
      });
    }
  });

  const scheduleMutation = useMutation({
    mutationFn: async (postData: InsertPost) => {
      console.time('schedule-request');
      const response = await apiRequest('POST', '/api/posts', postData);
      console.timeEnd('schedule-request');
      return response.json();
    },
    onSuccess: (newPost) => {
      queryClient.setQueryData(['/api/posts'], (old: any) => {
        if (!old) return [newPost];
        return [newPost, ...old];
      });
      
      toast({
        title: 'Post Scheduled Successfully',
        description: 'Your post has been scheduled.',
        variant: 'default'
      });
      
      // Reset form
      setContent('');
      setPostName('');
      setCampaignLabel('');
      setFirstComment('');
      setEnableFirstComment(false);
      setIsEvergreen(false);
      setScheduledDate('');
      setScheduledTime('09:00');
      onPostCreated?.();
    },
    onError: (err) => {
      toast({
        title: 'Failed to Schedule Post',
        description: err.message || 'Please try again.',
        variant: 'destructive'
      });
    }
  });

  // Platforms data - can be moved to a constants file later
  const platforms = [
    { id: 'instagram', name: 'Instagram', icon: 'fab fa-instagram', color: '#E4405F' },
    { id: 'facebook', name: 'Facebook', icon: 'fab fa-facebook', color: '#1877f2' },
    { id: 'twitter', name: 'Twitter', icon: 'fab fa-x-twitter', color: '#000000' },
    { id: 'linkedin', name: 'LinkedIn', icon: 'fab fa-linkedin', color: '#0077b5' },
    { id: 'youtube', name: 'YouTube', icon: 'fab fa-youtube', color: '#FF0000' },
    { id: 'tiktok', name: 'TikTok', icon: 'fab fa-tiktok', color: '#000000' },
    { id: 'snapchat', name: 'Snapchat', icon: 'fab fa-snapchat', color: '#FFFC00' },
  ];

  const [activePlatforms, setActivePlatforms] = useState(new Set(['instagram', 'facebook', 'twitter']));

  // Platform eligibility rules based on content type
  const platformEligibilityRules = {
    'text': ['facebook', 'twitter', 'linkedin'],
    'photo': ['instagram', 'facebook', 'twitter', 'linkedin', 'snapchat'], // all except TikTok & YouTube
    'video': ['instagram', 'facebook', 'twitter', 'linkedin', 'youtube', 'tiktok', 'snapchat'], // will be filtered by duration
    'carousel': ['facebook', 'instagram', 'linkedin', 'twitter'], // multiple images
    'story': ['instagram', 'facebook', 'snapchat'],
    'reel': ['instagram', 'tiktok', 'youtube', 'facebook', 'snapchat'], // short video
    'poll': ['instagram', 'facebook', 'twitter', 'linkedin'],
    'live': ['facebook', 'instagram', 'tiktok', 'youtube', 'linkedin']
  };

  // Determine content type and eligible platforms
  const getContentTypeAndEligiblePlatforms = () => {
    const hasContent = content.trim().length > 0;
    const hasLink = /https?:\/\//i.test(content);
    
    // Determine content type based on postType and content
    let contentType = postType;
    let eligiblePlatforms: string[] = [];
    let reason = '';
    
    if (postType === 'text') {
      if (hasLink && !content.replace(/https?:\/\/\S+/g, '').trim()) {
        // Link-only post
        eligiblePlatforms = ['facebook', 'linkedin', 'twitter'];
        reason = 'Link posts';
      } else {
        // Text post
        eligiblePlatforms = platformEligibilityRules.text;
        reason = 'Text posts';
      }
    } else if (postType === 'photo') {
      eligiblePlatforms = platformEligibilityRules.photo;
      reason = 'Photo posts';
    } else if (postType === 'carousel') {
      eligiblePlatforms = platformEligibilityRules.carousel;
      reason = 'Multiple image posts';
    } else if (postType === 'video') {
      // For now, assume short video - in real implementation would check duration
      eligiblePlatforms = platformEligibilityRules.video;
      reason = 'Video posts';
    } else if (postType === 'reel') {
      eligiblePlatforms = platformEligibilityRules.reel;
      reason = 'Short video posts';
    } else if (postType === 'story') {
      eligiblePlatforms = platformEligibilityRules.story;
      reason = 'Story posts';
    } else if (postType === 'poll') {
      eligiblePlatforms = platformEligibilityRules.poll;
      reason = 'Poll posts';
    } else if (postType === 'live') {
      eligiblePlatforms = platformEligibilityRules.live;
      reason = 'Live stream posts';
    } else {
      // Default to text rules
      eligiblePlatforms = platformEligibilityRules.text;
      reason = 'Default content';
    }
    
    return { contentType, eligiblePlatforms, reason };
  };
  
  // Check if current platform selection is valid
  const validatePlatformSelection = () => {
    const { eligiblePlatforms, reason } = getContentTypeAndEligiblePlatforms();
    const selectedPlatforms = Array.from(activePlatforms);
    const invalidPlatforms = selectedPlatforms.filter(p => !eligiblePlatforms.includes(p));
    const validPlatforms = selectedPlatforms.filter(p => eligiblePlatforms.includes(p));
    
    return {
      isValid: invalidPlatforms.length === 0 && validPlatforms.length > 0,
      invalidPlatforms,
      validPlatforms,
      eligiblePlatforms,
      reason,
      hasSelection: selectedPlatforms.length > 0
    };
  };
  
  const validation = validatePlatformSelection();

  const handlePlatformToggle = (platformId: string) => {
    const newActive = new Set(activePlatforms);
    if (newActive.has(platformId)) {
      newActive.delete(platformId);
    } else {
      newActive.add(platformId);
    }
    setActivePlatforms(newActive);
  };

  const handleDraft = () => {
    if (!validation.isValid) {
      toast({
        title: 'Invalid Platform Selection',
        description: 'Please select compatible platforms for your content type.',
        variant: 'destructive'
      });
      return;
    }

    if (!content.trim()) {
      toast({
        title: 'Content Required',
        description: 'Please add some content to your post.',
        variant: 'destructive'
      });
      return;
    }

    const postData: InsertPost = {
      content: content.trim(),
      postName: postName.trim() || null,
      campaignLabel: campaignLabel || null,
      platforms: Array.from(activePlatforms),
      firstComment: enableFirstComment ? firstComment.trim() : null,
      status: 'draft',
      scheduledTime: null,
      isEvergreen,
      evergreenSettings: isEvergreen ? {
        repeatInterval,
        repeatDays: repeatInterval === "weekly" ? repeatDays : undefined,
        monthlyDay: repeatInterval === "monthly" ? monthlyDay : undefined,
        repeatTime,
        endDate: endDate || null,
        maxRepeats: maxRepeats ? parseInt(maxRepeats) : null,
        nextExecution: null, // will be calculated on backend
        executionCount: 0
      } : null,
    };
    
    draftMutation.mutate(postData);
  };

  const handleSchedule = () => {
    if (!validation.isValid) {
      toast({
        title: 'Invalid Platform Selection',
        description: 'Please select compatible platforms for your content type.',
        variant: 'destructive'
      });
      return;
    }

    if (!content.trim()) {
      toast({
        title: 'Content Required',
        description: 'Please add some content to your post.',
        variant: 'destructive'
      });
      return;
    }

    if (!scheduledDate || !scheduledTime) {
      toast({
        title: 'Scheduling Information Required',
        description: 'Please select a date and time to schedule your post.',
        variant: 'destructive'
      });
      return;
    }

    const postData: InsertPost = {
      content: content.trim(),
      postName: postName.trim() || null,
      campaignLabel: campaignLabel || null,
      platforms: Array.from(activePlatforms),
      firstComment: enableFirstComment ? firstComment.trim() : null,
      status: 'scheduled',
      scheduledTime: new Date(`${scheduledDate}T${scheduledTime}`),
      isEvergreen,
      evergreenSettings: isEvergreen ? {
        repeatInterval,
        repeatDays: repeatInterval === "weekly" ? repeatDays : undefined,
        monthlyDay: repeatInterval === "monthly" ? monthlyDay : undefined,
        repeatTime,
        endDate: endDate || null,
        maxRepeats: maxRepeats ? parseInt(maxRepeats) : null,
        nextExecution: null, // will be calculated on backend
        executionCount: 0
      } : null,
    };
    
    scheduleMutation.mutate(postData);
  };

  const handleRepeatDayToggle = (day: string) => {
    setRepeatDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day)
        : [...prev, day]
    );
  };

  const handleRepeatIntervalChange = (value: string) => {
    setRepeatInterval(value as "daily" | "weekly" | "monthly");
  };

  const handleAiAssist = async () => {
    setIsGenerating(true);
    try {
      const prompt = `Generate engaging social media content for a ${postType} post. ${content ? `Build upon this existing content: "${content}"` : 'Create fresh content.'} Target platforms: ${Array.from(activePlatforms).join(', ')}. ${campaignLabel && campaignLabel !== 'none' ? `Campaign: ${campaignLabel}.` : ''} Make it engaging and platform-appropriate.`;
      
      const response = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, type: 'content-generation' })
      });
      
      if (!response.ok) throw new Error('Failed to generate content');
      
      const data = await response.json();
      setContent(data.content || data.text || 'Generated content unavailable');
      
      toast({
        title: 'AI Content Generated',
        description: 'Your post content has been generated successfully!',
        variant: 'default'
      });
    } catch (error) {
      console.error('AI generation error:', error);
      toast({
        title: 'Generation Failed', 
        description: 'Unable to generate content. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleOptimize = async () => {
    if (!content.trim()) {
      toast({
        title: 'No Content to Optimize',
        description: 'Please add some content first.',
        variant: 'destructive'
      });
      return;
    }
    
    setIsGenerating(true);
    try {
      const prompt = `Optimize this social media post for better engagement: "${content}". Post type: ${postType}. Target platforms: ${Array.from(activePlatforms).join(', ')}. Improve readability, add relevant hashtags, and make it more engaging while keeping the core message.`;
      
      const response = await fetch('/api/ai/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, platforms: Array.from(activePlatforms), postType })
      });
      
      if (!response.ok) throw new Error('Failed to optimize content');
      
      const data = await response.json();
      setContent(data.optimizedContent || data.content || content);
      
      toast({
        title: 'Content Optimized',
        description: 'Your post has been optimized for better engagement!',
        variant: 'default'
      });
    } catch (error) {
      console.error('Optimization error:', error);
      toast({
        title: 'Optimization Failed',
        description: 'Unable to optimize content. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const insertEmoji = (emoji: string) => {
    setContent(prev => prev + emoji);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4" data-testid="post-composer">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-lg font-bold text-gray-800">Create Post</h1>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-xs text-gray-600">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span>AI Connected</span>
          </div>
          <Button variant="ghost" size="icon" data-testid="button-settings">
            <i className="fas fa-cog text-sm"></i>
          </Button>
        </div>
      </div>

      {/* Campaign, Post Type & Post Name */}
      <div className="mb-4">
        <div className="grid grid-cols-3 gap-4">
          <div>
            <Label className="text-xs font-semibold text-gray-700 mb-1 flex items-center">
              <i className="fas fa-tag mr-1 text-purple-500 text-xs"></i>
              Campaign Label
            </Label>
            <Select value={campaignLabel} onValueChange={setCampaignLabel}>
              <SelectTrigger data-testid="select-campaign">
                <SelectValue placeholder="No Campaign" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No Campaign</SelectItem>
                <SelectItem value="product-launch">🚀 Product Launch</SelectItem>
                <SelectItem value="brand-awareness">📢 Brand Awareness</SelectItem>
                <SelectItem value="engagement">💬 Engagement Drive</SelectItem>
                <SelectItem value="seasonal">🎄 Seasonal Campaign</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-semibold text-gray-700 mb-1 flex items-center">
              <i className="fas fa-layer-group mr-1 text-blue-500 text-xs"></i>
              Post Type
            </Label>
            <Select value={postType} onValueChange={setPostType}>
              <SelectTrigger data-testid="select-post-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="text">📝 Text Post</SelectItem>
                <SelectItem value="photo">📷 Photo</SelectItem>
                <SelectItem value="video">🎥 Video</SelectItem>
                <SelectItem value="carousel">🎠 Carousel</SelectItem>
                <SelectItem value="story">📖 Story</SelectItem>
                <SelectItem value="reel">🎬 Reel/Short</SelectItem>
                <SelectItem value="poll">📊 Poll</SelectItem>
                <SelectItem value="live">📡 Live Stream</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs font-semibold text-gray-700 mb-1 flex items-center">
              <i className="fas fa-edit mr-1 text-green-500 text-xs"></i>
              Post Name (Optional)
            </Label>
            <Input 
              placeholder="My awesome post..."
              value={postName}
              onChange={(e) => setPostName(e.target.value)}
              data-testid="input-post-name"
            />
          </div>
        </div>
      </div>

      {/* Platform Selection */}
      <div className="mb-4">
        <Label className="text-xs font-semibold text-gray-700 mb-2 flex items-center">
          <i className="fas fa-share-alt mr-1 text-blue-500 text-xs"></i>
          Select Platforms
        </Label>
        <PlatformToggle 
          platforms={platforms}
          activePlatforms={activePlatforms}
          onToggle={handlePlatformToggle}
        />
        
        {/* Platform Validation Feedback */}
        {!validation.isValid && (
          <div className="mt-3 p-3 rounded-lg border">
            {validation.invalidPlatforms.length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded p-2 mb-2">
                <div className="flex items-start gap-2">
                  <i className="fas fa-exclamation-triangle text-red-500 text-sm mt-0.5"></i>
                  <div>
                    <p className="text-xs text-red-800 font-medium">Platform Compatibility Issue</p>
                    <p className="text-xs text-red-700 mt-1">
                      {validation.reason} are not supported on: {validation.invalidPlatforms.map(p => platforms.find(platform => platform.id === p)?.name).join(', ')}
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            {validation.validPlatforms.length === 0 && validation.hasSelection && (
              <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mb-2">
                <div className="flex items-start gap-2">
                  <i className="fas fa-info-circle text-yellow-600 text-sm mt-0.5"></i>
                  <div>
                    <p className="text-xs text-yellow-800 font-medium">No Compatible Platforms Selected</p>
                    <p className="text-xs text-yellow-700 mt-1">
                      Please select platforms that support {validation.reason.toLowerCase()}: {validation.eligiblePlatforms.map(p => platforms.find(platform => platform.id === p)?.name).join(', ')}
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            {!validation.hasSelection && (
              <div className="bg-blue-50 border border-blue-200 rounded p-2">
                <div className="flex items-start gap-2">
                  <i className="fas fa-info-circle text-blue-600 text-sm mt-0.5"></i>
                  <div>
                    <p className="text-xs text-blue-800 font-medium">Select Platforms</p>
                    <p className="text-xs text-blue-700 mt-1">
                      Choose from compatible platforms for {validation.reason.toLowerCase()}: {validation.eligiblePlatforms.map(p => platforms.find(platform => platform.id === p)?.name).join(', ')}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        
        {validation.isValid && validation.validPlatforms.length > 0 && (
          <div className="mt-3 bg-green-50 border border-green-200 rounded p-2">
            <div className="flex items-start gap-2">
              <i className="fas fa-check-circle text-green-600 text-sm mt-0.5"></i>
              <div>
                <p className="text-xs text-green-800 font-medium">Ready to Post</p>
                <p className="text-xs text-green-700 mt-1">
                  {validation.validPlatforms.length} platform{validation.validPlatforms.length !== 1 ? 's' : ''} selected: {validation.validPlatforms.map(p => platforms.find(platform => platform.id === p)?.name).join(', ')}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Post Content */}
      <div className="mb-4">
        <Label className="text-xs font-semibold text-gray-700 mb-2 flex items-center justify-between">
          <span className="flex items-center">
            <i className="fas fa-pen mr-1 text-indigo-500 text-xs"></i>
            Post Content
          </span>
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              className="text-xs bg-gradient-to-r from-brand-primary to-brand-secondary text-white"
              onClick={handleAiAssist}
              disabled={isGenerating}
              data-testid="button-ai-assist"
            >
              <i className={`fas ${isGenerating ? 'fa-spinner fa-spin' : 'fa-robot'} mr-1`}></i>
              {isGenerating ? 'Generating...' : 'AI'}
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              className="text-xs"
              onClick={() => onPreviewToggle?.(!isPreviewVisible)}
              data-testid="button-toggle-preview"
            >
              <i className={`fas ${isPreviewVisible ? 'fa-eye-slash' : 'fa-eye'} mr-1`}></i>
              {isPreviewVisible ? 'Hide' : 'Preview'}
            </Button>
            <Button 
              size="sm" 
              variant="secondary"
              className="text-xs bg-green-100 text-green-700 hover:bg-green-200"
              onClick={handleOptimize}
              disabled={isGenerating || !content.trim()}
              data-testid="button-optimize"
            >
              <i className={`fas ${isGenerating ? 'fa-spinner fa-spin' : 'fa-magic'} mr-1`}></i>
              {isGenerating ? 'Optimizing...' : 'Optimize'}
            </Button>
          </div>
        </Label>
        <Textarea 
          placeholder="What would you like to share with your audience today?"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-24 resize-none"
          data-testid="textarea-content"
        />
        
        {/* Quick Emoji Bar */}
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-1 h-6 hover:bg-gray-100"
              onClick={() => insertEmoji('😊')}
              data-testid="emoji-smile"
            >
              😊
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-1 h-6 hover:bg-gray-100"
              onClick={() => insertEmoji('🎉')}
              data-testid="emoji-party"
            >
              🎉
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-1 h-6 hover:bg-gray-100"
              onClick={() => insertEmoji('❤️')}
              data-testid="emoji-heart"
            >
              ❤️
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-1 h-6 hover:bg-gray-100"
              onClick={() => insertEmoji('🔥')}
              data-testid="emoji-fire"
            >
              🔥
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-1 h-6 hover:bg-gray-100"
              onClick={() => insertEmoji('💯')}
              data-testid="emoji-hundred"
            >
              💯
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-1 h-6 hover:bg-gray-100"
              onClick={() => insertEmoji('✨')}
              data-testid="emoji-sparkles"
            >
              ✨
            </Button>
          </div>
          <span className="text-xs text-gray-500">{content.length} characters</span>
        </div>
      </div>

      {/* First Comment (Optional) */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs font-semibold text-gray-700 flex items-center">
            <i className="fas fa-comment-alt mr-1 text-orange-500 text-xs"></i>
            First Comment
          </Label>
          <Checkbox 
            checked={enableFirstComment}
            onCheckedChange={(checked) => setEnableFirstComment(checked === true)}
            data-testid="checkbox-first-comment"
          />
        </div>
        {enableFirstComment && (
          <Textarea 
            placeholder="Pin this comment to the top of your post..."
            value={firstComment}
            onChange={(e) => setFirstComment(e.target.value)}
            className="min-h-16 resize-none"
            data-testid="textarea-first-comment"
          />
        )}
      </div>

      {/* Evergreen Post Settings */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <Label className="text-xs font-semibold text-gray-700 flex items-center">
            <i className="fas fa-recycle mr-1 text-green-500 text-xs"></i>
            Evergreen Post (Auto-Repeat)
          </Label>
          <Checkbox 
            checked={isEvergreen}
            onCheckedChange={(checked) => setIsEvergreen(checked === true)}
            data-testid="checkbox-evergreen"
          />
        </div>
        
        {isEvergreen && (
          <div className="space-y-4 p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs font-semibold text-gray-700 mb-1">Repeat Frequency</Label>
                <Select value={repeatInterval} onValueChange={handleRepeatIntervalChange}>
                  <SelectTrigger data-testid="select-repeat-interval">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs font-semibold text-gray-700 mb-1">Time</Label>
                <Input 
                  type="time" 
                  value={repeatTime}
                  onChange={(e) => setRepeatTime(e.target.value)}
                  data-testid="input-repeat-time"
                />
              </div>
            </div>

            {repeatInterval === "weekly" && (
              <div>
                <Label className="text-xs font-semibold text-gray-700 mb-2">Days of Week</Label>
                <div className="flex gap-2">
                  {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => (
                    <Button
                      key={day}
                      variant={repeatDays.includes(day) ? "default" : "outline"}
                      size="sm"
                      className="text-xs"
                      onClick={() => handleRepeatDayToggle(day)}
                      data-testid={`button-day-${day.toLowerCase()}`}
                    >
                      {day.slice(0, 3)}
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {repeatInterval === "monthly" && (
              <div>
                <Label className="text-xs font-semibold text-gray-700 mb-1">Day of Month</Label>
                <Select value={monthlyDay.toString()} onValueChange={(value) => setMonthlyDay(parseInt(value))}>
                  <SelectTrigger data-testid="select-monthly-day">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 28 }, (_, i) => i + 1).map(day => (
                      <SelectItem key={day} value={day.toString()}>
                        {day === 1 ? '1st' : day === 2 ? '2nd' : day === 3 ? '3rd' : `${day}th`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs font-semibold text-gray-700 mb-1">End Date (Optional)</Label>
                <Input 
                  type="date" 
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  data-testid="input-end-date"
                />
              </div>
              <div>
                <Label className="text-xs font-semibold text-gray-700 mb-1">Max Repeats (Optional)</Label>
                <Input 
                  type="number" 
                  placeholder="e.g., 10"
                  value={maxRepeats}
                  onChange={(e) => setMaxRepeats(e.target.value)}
                  data-testid="input-max-repeats"
                />
              </div>
            </div>

            <div className="bg-green-100 border border-green-300 rounded p-3">
              <div className="flex items-start gap-2">
                <i className="fas fa-info-circle text-green-600 text-sm mt-0.5"></i>
                <div>
                  <p className="text-xs text-green-800 font-medium">Evergreen Post Preview</p>
                  <p className="text-xs text-green-700 mt-1">
                    This post will repeat {repeatInterval}
                    {repeatInterval === "weekly" && repeatDays.length > 0 && (
                      <span> on {repeatDays.map(d => d.slice(0, 3)).join(", ")}</span>
                    )}
                    {repeatInterval === "monthly" && (
                      <span> on the {monthlyDay === 1 ? "1st" : monthlyDay === 2 ? "2nd" : monthlyDay === 3 ? "3rd" : `${monthlyDay}th`}</span>
                    )}
                    {` at ${repeatTime}`}
                    {endDate && <span> until {new Date(endDate).toLocaleDateString()}</span>}
                    {maxRepeats && <span> for maximum {maxRepeats} times</span>}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Scheduling Section */}
      <div className="border border-gray-200 rounded-lg p-4 space-y-4">
        <div className="flex items-center gap-2">
          <i className="fas fa-calendar-alt text-blue-500"></i>
          <h4 className="text-sm font-semibold text-gray-800">Schedule Post</h4>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-xs font-semibold text-gray-700 mb-1">Date</Label>
            <Input 
              type="date" 
              value={scheduledDate}
              onChange={(e) => setScheduledDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              data-testid="input-scheduled-date"
            />
          </div>
          <div>
            <Label className="text-xs font-semibold text-gray-700 mb-1">Time</Label>
            <Input 
              type="time" 
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              data-testid="input-scheduled-time"
            />
          </div>
        </div>
        
        {scheduledDate && scheduledTime && (
          <div className="bg-blue-50 border border-blue-200 rounded p-3">
            <div className="flex items-start gap-2">
              <i className="fas fa-info-circle text-blue-600 text-sm mt-0.5"></i>
              <div>
                <p className="text-xs text-blue-800 font-medium">Scheduled for:</p>
                <p className="text-xs text-blue-700 mt-1">
                  {new Date(`${scheduledDate}T${scheduledTime}`).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <div className="flex gap-2">
          <Button 
            className="flex-1"
            onClick={handleDraft}
            disabled={!validation.isValid || !content.trim() || draftMutation.isPending}
            data-testid="button-post-now"
          >
            <i className={`fas ${draftMutation.isPending ? 'fa-spinner fa-spin' : 'fa-paper-plane'} mr-2`}></i>
            {draftMutation.isPending ? 'Creating...' : 'Post Now'}
          </Button>
          <Button 
            variant="outline"
            onClick={handleSchedule}
            disabled={!validation.isValid || !content.trim() || !scheduledDate || !scheduledTime || scheduleMutation.isPending}
            data-testid="button-schedule"
          >
            <i className={`fas ${scheduleMutation.isPending ? 'fa-spinner fa-spin' : 'fa-clock'} mr-2`}></i>
            {scheduleMutation.isPending ? 'Scheduling...' : 'Schedule'}
          </Button>
          <Button 
            variant="outline"
            onClick={handleDraft}
            disabled={!validation.isValid || !content.trim() || draftMutation.isPending}
            data-testid="button-save-draft"
          >
            <i className={`fas ${draftMutation.isPending ? 'fa-spinner fa-spin' : 'fa-save'} mr-2`}></i>
            {draftMutation.isPending ? 'Saving...' : 'Save Draft'}
          </Button>
        </div>
        
        {/* View All Button */}
        <Button 
          variant="outline"
          size="sm"
          className="w-full text-xs"
          onClick={() => {
            console.log('View scheduled posts triggered');
            onViewChange?.('upcoming-posts');
          }}
          data-testid="button-view-scheduled"
        >
          <i className="fas fa-calendar-check mr-1"></i>
          View All Scheduled Posts
          <i className="fas fa-arrow-right ml-auto"></i>
        </Button>
      </div>
    </div>
  );
}