import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface Activity {
  id: string;
  type: 'post' | 'comment' | 'like' | 'share' | 'connection';
  platform: 'instagram' | 'facebook' | 'twitter' | 'linkedin';
  title: string;
  description: string;
  timestamp: string;
  status: 'success' | 'pending' | 'failed';
}

interface ActivityFeedProps {
  activities?: Activity[];
  maxItems?: number;
  onViewChange?: (view: string) => void;
}

export default function ActivityFeed({ activities = [], maxItems = 10, onViewChange }: ActivityFeedProps) {
  // Fetch activities from API
  const { data: apiActivities = [], isLoading } = useQuery({
    queryKey: ['/api/activities'],
    queryFn: async () => {
      const response = await fetch('/api/activities');
      if (!response.ok) throw new Error('Failed to fetch activities');
      return response.json();
    }
  });

  const allActivities = [...activities, ...apiActivities].slice(0, maxItems);

  const getActivityIcon = (type: string, status: string) => {
    const icons = {
      post: 'fas fa-file-alt',
      comment: 'fas fa-comment',
      like: 'fas fa-heart',
      share: 'fas fa-share',
      connection: 'fas fa-user-plus'
    };
    
    const statusColors = {
      success: 'text-green-600',
      pending: 'text-yellow-600', 
      failed: 'text-red-600'
    };
    
    return {
      icon: icons[type as keyof typeof icons] || 'fas fa-circle',
      color: statusColors[status as keyof typeof statusColors] || 'text-gray-600'
    };
  };

  const getPlatformIcon = (platform: string) => {
    const platformIcons = {
      instagram: 'fab fa-instagram',
      facebook: 'fab fa-facebook-f',
      twitter: 'fab fa-x-twitter',
      linkedin: 'fab fa-linkedin-in'
    };
    
    return platformIcons[platform as keyof typeof platformIcons] || 'fas fa-globe';
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      success: 'default' as const,
      pending: 'secondary' as const,
      failed: 'destructive' as const
    };
    
    const labels = {
      success: 'Success',
      pending: 'Pending', 
      failed: 'Failed'
    };
    
    return {
      variant: variants[status as keyof typeof variants] || 'secondary' as const,
      label: labels[status as keyof typeof labels] || 'Unknown'
    };
  };

  return (
    <Card className="w-full" data-testid="activity-feed">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-gray-800 flex items-center justify-between">
          <div className="flex items-center">
            <i className="fas fa-history mr-2 text-gray-500"></i>
            Recent Activity
          </div>
          <Badge variant="secondary" className="text-xs">
            {allActivities.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-2 max-h-64 overflow-y-auto" data-testid="activity-list">
          {isLoading ? (
            <div className="text-center py-8">
              <i className="fas fa-spinner fa-spin text-xl text-gray-400 mb-2"></i>
              <p className="text-sm text-gray-500">Loading activities...</p>
            </div>
          ) : allActivities.map((activity) => {
            const activityStyle = getActivityIcon(activity.type, activity.status);
            const statusBadge = getStatusBadge(activity.status);
            
            return (
              <div 
                key={activity.id}
                className="flex items-start gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors hover-elevate cursor-pointer"
                onClick={() => console.log(`Activity clicked: ${activity.id}`)}
                data-testid={`activity-${activity.id}`}
              >
                {/* Activity Icon */}
                <div className={`mt-0.5 ${activityStyle.color}`}>
                  <i className={`${activityStyle.icon} text-sm`}></i>
                </div>
                
                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 leading-tight">
                        {activity.title}
                      </p>
                      <p className="text-xs text-gray-600 mt-0.5 leading-tight">
                        {activity.description}
                      </p>
                    </div>
                    
                    {/* Platform & Status */}
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <i className={`${getPlatformIcon(activity.platform)} text-xs text-gray-400`}></i>
                      <Badge 
                        variant={statusBadge.variant}
                        className="text-xs px-1 py-0 h-4"
                      >
                        {statusBadge.label}
                      </Badge>
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-400 mt-1">
                    {activity.timestamp}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {!isLoading && allActivities.length === 0 && (
          <div className="text-center py-8">
            <i className="fas fa-inbox text-xl text-gray-300 mb-2"></i>
            <p className="text-sm text-gray-500">No recent activity</p>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex gap-2 pt-2 border-t border-gray-100">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1 text-xs"
            onClick={() => {
              console.log('View all activity triggered');
              // For now, just show a success message since there's no dedicated activity view
              // Could navigate to a specific view in the future
            }}
            data-testid="button-view-all"
          >
            View All
            <i className="fas fa-arrow-right ml-1"></i>
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs"
            onClick={() => console.log('Refresh activity triggered')}
            data-testid="button-refresh"
          >
            <i className="fas fa-sync"></i>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}