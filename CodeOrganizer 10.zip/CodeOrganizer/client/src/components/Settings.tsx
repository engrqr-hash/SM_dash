import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

export default function Settings() {
  // Profile Settings State
  const [profile, setProfile] = useState({
    name: "Alex Morgan",
    email: "alex.morgan@company.com",
    bio: "Social Media Manager & Content Creator",
    timezone: "america-new_york",
    language: "english"
  });

  // Connected Accounts State
  const [connectedAccounts, setConnectedAccounts] = useState({
    facebook: { connected: true, username: "@alexmorgan" },
    instagram: { connected: true, username: "@alex_creates" },
    twitter: { connected: true, username: "@alextweets" },
    linkedin: { connected: false, username: "" },
    youtube: { connected: false, username: "" },
    tiktok: { connected: true, username: "@alex.creates" },
    snapchat: { connected: false, username: "" }
  });

  // Notification Settings State
  const [notifications, setNotifications] = useState({
    postPublished: true,
    scheduledReminders: true,
    engagementAlerts: true,
    weeklyReports: true,
    securityAlerts: true,
    emailDigests: false,
    pushNotifications: true,
    smsAlerts: false
  });

  // Display Settings State
  const [display, setDisplay] = useState({
    theme: "light",
    compactMode: false,
    animationsEnabled: true,
    autoRefresh: true,
    defaultView: "dashboard"
  });

  // Billing Settings State
  const [billing, setBilling] = useState({
    currentPlan: "professional",
    paymentMethod: "card",
    autoRenew: true,
    billingCycle: "monthly"
  });

  const [paymentMethods] = useState([
    { id: "1", type: "card", last4: "4242", brand: "visa", isDefault: true },
    { id: "2", type: "card", last4: "1234", brand: "mastercard", isDefault: false }
  ]);

  const [billingHistory] = useState([
    { id: "1", date: "2025-09-01", amount: 29.99, status: "paid", plan: "Professional" },
    { id: "2", date: "2025-08-01", amount: 29.99, status: "paid", plan: "Professional" },
    { id: "3", date: "2025-07-01", amount: 29.99, status: "paid", plan: "Professional" },
    { id: "4", date: "2025-06-01", amount: 19.99, status: "paid", plan: "Starter" }
  ]);

  const handleProfileUpdate = () => {
    console.log("Profile updated:", profile);
    // Here you would normally make an API call to update the profile
  };

  const handleAccountConnect = (platform: string) => {
    console.log(`Connecting to ${platform}`);
    // Here you would implement OAuth flow for the platform
  };

  const handleAccountDisconnect = (platform: string) => {
    setConnectedAccounts(prev => ({
      ...prev,
      [platform]: { connected: false, username: "" }
    }));
  };

  const renderAccountCard = (platform: string, icon: string, color: string) => {
    const account = connectedAccounts[platform as keyof typeof connectedAccounts];
    
    return (
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center text-white`}>
              <i className={icon}></i>
            </div>
            <div>
              <h4 className="font-medium capitalize">{platform}</h4>
              {account.connected ? (
                <p className="text-sm text-gray-500">{account.username}</p>
              ) : (
                <p className="text-sm text-gray-400">Not connected</p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {account.connected ? (
              <>
                <Badge variant="secondary" className="text-green-600 bg-green-50">Connected</Badge>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleAccountDisconnect(platform)}
                  data-testid={`button-disconnect-${platform}`}
                >
                  Disconnect
                </Button>
              </>
            ) : (
              <Button 
                variant="default" 
                size="sm"
                onClick={() => handleAccountConnect(platform)}
                data-testid={`button-connect-${platform}`}
              >
                Connect
              </Button>
            )}
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="space-y-6" data-testid="settings-page">
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile" data-testid="tab-profile">Profile</TabsTrigger>
          <TabsTrigger value="accounts" data-testid="tab-accounts">Accounts</TabsTrigger>
          <TabsTrigger value="billing" data-testid="tab-billing">Billing</TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">Notifications</TabsTrigger>
          <TabsTrigger value="preferences" data-testid="tab-preferences">Preferences</TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-user mr-2 text-blue-500"></i>
                Profile Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4 mb-6">
                <Avatar className="w-20 h-20">
                  <AvatarImage src="/api/placeholder/80/80" />
                  <AvatarFallback className="text-lg">AM</AvatarFallback>
                </Avatar>
                <div>
                  <Button variant="outline" size="sm" data-testid="button-change-avatar">
                    <i className="fas fa-camera mr-2"></i>
                    Change Photo
                  </Button>
                  <p className="text-sm text-gray-500 mt-1">JPG, GIF or PNG. Max size 2MB.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input 
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    data-testid="input-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email"
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                    data-testid="input-email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Input 
                  id="bio"
                  value={profile.bio}
                  onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                  placeholder="Tell us about yourself..."
                  data-testid="input-bio"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select value={profile.timezone} onValueChange={(value) => setProfile({ ...profile, timezone: value })}>
                    <SelectTrigger data-testid="select-timezone">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="america-new_york">Eastern Time (ET)</SelectItem>
                      <SelectItem value="america-chicago">Central Time (CT)</SelectItem>
                      <SelectItem value="america-denver">Mountain Time (MT)</SelectItem>
                      <SelectItem value="america-los_angeles">Pacific Time (PT)</SelectItem>
                      <SelectItem value="europe-london">London (GMT)</SelectItem>
                      <SelectItem value="europe-paris">Paris (CET)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select value={profile.language} onValueChange={(value) => setProfile({ ...profile, language: value })}>
                    <SelectTrigger data-testid="select-language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="spanish">Spanish</SelectItem>
                      <SelectItem value="french">French</SelectItem>
                      <SelectItem value="german">German</SelectItem>
                      <SelectItem value="japanese">Japanese</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="pt-4">
                <Button onClick={handleProfileUpdate} data-testid="button-save-profile">
                  <i className="fas fa-save mr-2"></i>
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Connected Accounts */}
        <TabsContent value="accounts" className="space-y-6">
          {/* Integration Guide */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center text-blue-800">
                <i className="fas fa-info-circle mr-2"></i>
                Social Media Integration Guide
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 text-sm">
                <div>
                  <h4 className="font-semibold text-blue-800 mb-2">Getting Started</h4>
                  <p className="text-blue-700 mb-2">
                    Connect your social media accounts to enable cross-platform posting, analytics, and engagement management.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-3 rounded border">
                    <h5 className="font-semibold text-gray-800 mb-2">
                      <i className="fab fa-facebook-f mr-2 text-blue-600"></i>
                      Facebook & Instagram
                    </h5>
                    <ul className="text-xs text-gray-600 space-y-1">
                      <li>• Requires Facebook Business account</li>
                      <li>• Instagram must be connected to Facebook Page</li>
                      <li>• Supports posts, stories, and reels</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white p-3 rounded border">
                    <h5 className="font-semibold text-gray-800 mb-2">
                      <i className="fab fa-x-twitter mr-2 text-black"></i>
                      X (Twitter)
                    </h5>
                    <ul className="text-xs text-gray-600 space-y-1">
                      <li>• Requires X Premium for API access</li>
                      <li>• Supports tweets and media</li>
                      <li>• Real-time engagement tracking</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white p-3 rounded border">
                    <h5 className="font-semibold text-gray-800 mb-2">
                      <i className="fab fa-linkedin-in mr-2 text-blue-700"></i>
                      LinkedIn
                    </h5>
                    <ul className="text-xs text-gray-600 space-y-1">
                      <li>• Personal profiles and company pages</li>
                      <li>• Professional content optimization</li>
                      <li>• Industry analytics</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white p-3 rounded border">
                    <h5 className="font-semibold text-gray-800 mb-2">
                      <i className="fab fa-youtube mr-2 text-red-600"></i>
                      YouTube
                    </h5>
                    <ul className="text-xs text-gray-600 space-y-1">
                      <li>• Video uploads and management</li>
                      <li>• Community posts</li>
                      <li>• Detailed video analytics</li>
                    </ul>
                  </div>
                </div>

                <div className="border-t pt-3">
                  <h4 className="font-semibold text-blue-800 mb-2">Security & Permissions</h4>
                  <div className="bg-white p-3 rounded border">
                    <ul className="text-xs text-gray-600 space-y-1">
                      <li><i className="fas fa-shield-alt mr-2 text-green-500"></i>OAuth 2.0 authentication ensures secure connections</li>
                      <li><i className="fas fa-key mr-2 text-yellow-500"></i>API credentials are encrypted and stored securely</li>
                      <li><i className="fas fa-user-lock mr-2 text-blue-500"></i>You can revoke access at any time from your account settings</li>
                      <li><i className="fas fa-eye mr-2 text-purple-500"></i>Only necessary permissions are requested for each platform</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Connected Accounts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <i className="fas fa-link mr-2 text-green-500"></i>
                  Connected Social Media Accounts
                </div>
                <Button variant="outline" size="sm" data-testid="button-refresh-connections">
                  <i className="fas fa-sync-alt mr-2"></i>
                  Refresh All
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {renderAccountCard("facebook", "fab fa-facebook-f", "bg-blue-600")}
              {renderAccountCard("instagram", "fab fa-instagram", "bg-pink-500")}
              {renderAccountCard("twitter", "fab fa-x-twitter", "bg-black")}
              {renderAccountCard("linkedin", "fab fa-linkedin-in", "bg-blue-700")}
              {renderAccountCard("youtube", "fab fa-youtube", "bg-red-600")}
              {renderAccountCard("tiktok", "fab fa-tiktok", "bg-black")}
              {renderAccountCard("snapchat", "fab fa-snapchat", "bg-yellow-500")}
            </CardContent>
          </Card>

          {/* Advanced Integration Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-cogs mr-2 text-gray-500"></i>
                Advanced Integration Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800">Posting Preferences</h4>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-hashtags">Auto-generate hashtags</Label>
                      <p className="text-sm text-gray-500">AI-powered hashtag suggestions</p>
                    </div>
                    <Switch 
                      id="auto-hashtags"
                      defaultChecked={true}
                      data-testid="switch-auto-hashtags"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="cross-post">Enable cross-posting</Label>
                      <p className="text-sm text-gray-500">Post to multiple platforms simultaneously</p>
                    </div>
                    <Switch 
                      id="cross-post"
                      defaultChecked={true}
                      data-testid="switch-cross-post"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="url-shortening">Auto-shorten URLs</Label>
                      <p className="text-sm text-gray-500">Automatically shorten links for character limits</p>
                    </div>
                    <Switch 
                      id="url-shortening"
                      defaultChecked={false}
                      data-testid="switch-url-shortening"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-800">Analytics & Tracking</h4>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="engagement-tracking">Real-time engagement tracking</Label>
                      <p className="text-sm text-gray-500">Monitor likes, comments, shares</p>
                    </div>
                    <Switch 
                      id="engagement-tracking"
                      defaultChecked={true}
                      data-testid="switch-engagement-tracking"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="competitor-monitoring">Competitor monitoring</Label>
                      <p className="text-sm text-gray-500">Track competitor activity and trends</p>
                    </div>
                    <Switch 
                      id="competitor-monitoring"
                      defaultChecked={false}
                      data-testid="switch-competitor-monitoring"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="sentiment-analysis">Sentiment analysis</Label>
                      <p className="text-sm text-gray-500">AI-powered comment sentiment tracking</p>
                    </div>
                    <Switch 
                      id="sentiment-analysis"
                      defaultChecked={true}
                      data-testid="switch-sentiment-analysis"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <h4 className="font-semibold text-gray-800">API Rate Limits & Usage</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="text-sm font-medium text-gray-700">Daily API Calls</div>
                    <div className="text-xl font-bold text-blue-600">2,847</div>
                    <div className="text-xs text-gray-500">of 10,000 limit</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="text-sm font-medium text-gray-700">Posts Scheduled</div>
                    <div className="text-xl font-bold text-green-600">156</div>
                    <div className="text-xs text-gray-500">this month</div>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <div className="text-sm font-medium text-gray-700">Accounts Connected</div>
                    <div className="text-xl font-bold text-purple-600">4</div>
                    <div className="text-xs text-gray-500">of 50 limit</div>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <Button data-testid="button-save-integration-settings">
                  <i className="fas fa-save mr-2"></i>
                  Save Integration Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Billing & Subscription */}
        <TabsContent value="billing" className="space-y-6">
          {/* Current Plan */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-credit-card mr-2 text-blue-500"></i>
                Current Plan
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-semibold">Professional Plan</h3>
                  <p className="text-gray-600">$29.99/month • Billed monthly</p>
                  <p className="text-sm text-gray-500 mt-1">Next billing date: October 1, 2025</p>
                </div>
                <Badge variant="default" className="bg-green-100 text-green-800">Active</Badge>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">50</div>
                  <div className="text-sm text-gray-600">Social Accounts</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">500</div>
                  <div className="text-sm text-gray-600">Posts per Month</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">Unlimited</div>
                  <div className="text-sm text-gray-600">Team Members</div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" data-testid="button-change-plan">
                  <i className="fas fa-exchange-alt mr-2"></i>
                  Change Plan
                </Button>
                <Button variant="outline" data-testid="button-billing-portal">
                  <i className="fas fa-external-link-alt mr-2"></i>
                  Manage Billing
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Available Plans */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-star mr-2 text-yellow-500"></i>
                Available Plans
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Starter Plan */}
                <div className="border rounded-lg p-4 relative">
                  <div className="mb-4">
                    <h4 className="font-semibold text-lg">Starter</h4>
                    <div className="text-2xl font-bold text-gray-900">$19.99<span className="text-sm font-normal text-gray-500">/month</span></div>
                  </div>
                  <ul className="space-y-2 text-sm text-gray-600 mb-4">
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>5 Social Accounts</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>100 Posts/Month</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Basic Analytics</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>1 Team Member</li>
                  </ul>
                  <Button variant="outline" className="w-full" data-testid="button-select-starter">
                    Select Plan
                  </Button>
                </div>

                {/* Professional Plan */}
                <div className="border-2 border-blue-500 rounded-lg p-4 relative">
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-500 text-white">Current Plan</Badge>
                  </div>
                  <div className="mb-4">
                    <h4 className="font-semibold text-lg">Professional</h4>
                    <div className="text-2xl font-bold text-gray-900">$29.99<span className="text-sm font-normal text-gray-500">/month</span></div>
                  </div>
                  <ul className="space-y-2 text-sm text-gray-600 mb-4">
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>50 Social Accounts</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>500 Posts/Month</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Advanced Analytics</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Unlimited Team Members</li>
                  </ul>
                  <Button className="w-full bg-blue-500" disabled data-testid="button-select-professional">
                    Current Plan
                  </Button>
                </div>

                {/* Enterprise Plan */}
                <div className="border rounded-lg p-4 relative">
                  <div className="mb-4">
                    <h4 className="font-semibold text-lg">Enterprise</h4>
                    <div className="text-2xl font-bold text-gray-900">$99.99<span className="text-sm font-normal text-gray-500">/month</span></div>
                  </div>
                  <ul className="space-y-2 text-sm text-gray-600 mb-4">
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Unlimited Accounts</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Unlimited Posts</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Custom Analytics</li>
                    <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Priority Support</li>
                  </ul>
                  <Button variant="outline" className="w-full" data-testid="button-select-enterprise">
                    Upgrade
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Methods */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <i className="fas fa-wallet mr-2 text-green-500"></i>
                  Payment Methods
                </div>
                <Button variant="outline" size="sm" data-testid="button-add-payment">
                  <i className="fas fa-plus mr-2"></i>
                  Add Method
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {paymentMethods.map((method) => (
                <div key={method.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-6 bg-gray-100 rounded flex items-center justify-center">
                      <i className={`fab fa-cc-${method.brand} text-lg`}></i>
                    </div>
                    <div>
                      <div className="font-medium">•••• •••• •••• {method.last4}</div>
                      <div className="text-sm text-gray-500 capitalize">{method.brand} {method.type}</div>
                    </div>
                    {method.isDefault && (
                      <Badge variant="secondary">Default</Badge>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {!method.isDefault && (
                      <Button variant="outline" size="sm" data-testid={`button-set-default-${method.id}`}>
                        Set Default
                      </Button>
                    )}
                    <Button variant="outline" size="sm" data-testid={`button-remove-payment-${method.id}`}>
                      Remove
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Billing History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-receipt mr-2 text-purple-500"></i>
                Billing History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {billingHistory.map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="font-medium">{invoice.plan} Plan</div>
                      <div className="text-sm text-gray-500">{new Date(invoice.date).toLocaleDateString()}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${invoice.amount}</div>
                      <Badge 
                        variant={invoice.status === 'paid' ? 'default' : 'secondary'}
                        className={invoice.status === 'paid' ? 'bg-green-100 text-green-800' : ''}
                      >
                        {invoice.status.toUpperCase()}
                      </Badge>
                    </div>
                    <Button variant="outline" size="sm" className="ml-4" data-testid={`button-download-${invoice.id}`}>
                      <i className="fas fa-download mr-2"></i>
                      Download
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Billing Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-cog mr-2 text-gray-500"></i>
                Billing Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-renew">Auto-renew subscription</Label>
                  <p className="text-sm text-gray-500">Automatically renew your subscription each billing cycle</p>
                </div>
                <Switch 
                  id="auto-renew"
                  checked={billing.autoRenew}
                  onCheckedChange={(checked) => setBilling({ ...billing, autoRenew: checked })}
                  data-testid="switch-auto-renew"
                />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="billing-cycle">Billing Cycle</Label>
                <Select value={billing.billingCycle} onValueChange={(value) => setBilling({ ...billing, billingCycle: value })}>
                  <SelectTrigger data-testid="select-billing-cycle">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monthly (Higher cost, more flexibility)</SelectItem>
                    <SelectItem value="yearly">Yearly (20% discount, billed annually)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-4">
                <Button data-testid="button-save-billing">
                  <i className="fas fa-save mr-2"></i>
                  Save Billing Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-bell mr-2 text-yellow-500"></i>
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="post-published">Post Published</Label>
                    <p className="text-sm text-gray-500">Get notified when your posts are published</p>
                  </div>
                  <Switch 
                    id="post-published"
                    checked={notifications.postPublished}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, postPublished: checked })}
                    data-testid="switch-post-published"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="scheduled-reminders">Scheduled Reminders</Label>
                    <p className="text-sm text-gray-500">Reminders for upcoming scheduled posts</p>
                  </div>
                  <Switch 
                    id="scheduled-reminders"
                    checked={notifications.scheduledReminders}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, scheduledReminders: checked })}
                    data-testid="switch-scheduled-reminders"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="engagement-alerts">Engagement Alerts</Label>
                    <p className="text-sm text-gray-500">Notifications for comments, likes, and shares</p>
                  </div>
                  <Switch 
                    id="engagement-alerts"
                    checked={notifications.engagementAlerts}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, engagementAlerts: checked })}
                    data-testid="switch-engagement-alerts"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="weekly-reports">Weekly Reports</Label>
                    <p className="text-sm text-gray-500">Weekly analytics and performance reports</p>
                  </div>
                  <Switch 
                    id="weekly-reports"
                    checked={notifications.weeklyReports}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, weeklyReports: checked })}
                    data-testid="switch-weekly-reports"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Preferences */}
        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-cog mr-2 text-gray-500"></i>
                Display & Behavior
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="theme">Theme</Label>
                    <Select value={display.theme} onValueChange={(value) => setDisplay({ ...display, theme: value })}>
                      <SelectTrigger data-testid="select-theme">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Light</SelectItem>
                        <SelectItem value="dark">Dark</SelectItem>
                        <SelectItem value="auto">Auto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="default-view">Default View</Label>
                    <Select value={display.defaultView} onValueChange={(value) => setDisplay({ ...display, defaultView: value })}>
                      <SelectTrigger data-testid="select-default-view">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dashboard">Dashboard</SelectItem>
                        <SelectItem value="composer">Post Composer</SelectItem>
                        <SelectItem value="analytics">Analytics</SelectItem>
                        <SelectItem value="calendar">Calendar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="compact-mode">Compact Mode</Label>
                      <p className="text-sm text-gray-500">Use smaller spacing and components</p>
                    </div>
                    <Switch 
                      id="compact-mode"
                      checked={display.compactMode}
                      onCheckedChange={(checked) => setDisplay({ ...display, compactMode: checked })}
                      data-testid="switch-compact-mode"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="animations">Animations</Label>
                      <p className="text-sm text-gray-500">Enable smooth transitions</p>
                    </div>
                    <Switch 
                      id="animations"
                      checked={display.animationsEnabled}
                      onCheckedChange={(checked) => setDisplay({ ...display, animationsEnabled: checked })}
                      data-testid="switch-animations"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="auto-refresh">Auto Refresh</Label>
                      <p className="text-sm text-gray-500">Automatically refresh data</p>
                    </div>
                    <Switch 
                      id="auto-refresh"
                      checked={display.autoRefresh}
                      onCheckedChange={(checked) => setDisplay({ ...display, autoRefresh: checked })}
                      data-testid="switch-auto-refresh"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <Button data-testid="button-save-preferences">
                  <i className="fas fa-save mr-2"></i>
                  Save Preferences
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}