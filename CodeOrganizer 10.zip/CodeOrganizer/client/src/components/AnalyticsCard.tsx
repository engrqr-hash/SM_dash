import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface AnalyticsData {
  title: string;
  value: string | number;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: string;
}

interface PlatformData {
  platform: string;
  reach: number;
  engagement: number;
  color: string;
  icon: string;
}

interface TopPost {
  id: string;
  content: string;
  platform: string;
  engagement: number;
  reach: number;
  date: string;
}

interface AnalyticsCardProps {
  data: AnalyticsData[];
  showChart?: boolean;
  onViewChange?: (view: string) => void;
}

export default function AnalyticsCard({ data, showChart = false, onViewChange }: AnalyticsCardProps) {
  // Enhanced mock data
  const enhancedData = [
    { title: "Total Reach", value: "47.2K", change: "+24%", changeType: "positive" as const, icon: "fas fa-eye" },
    { title: "Impressions", value: "156.8K", change: "+18%", changeType: "positive" as const, icon: "fas fa-chart-bar" },
    { title: "Engagement Rate", value: "8.9%", change: "+12%", changeType: "positive" as const, icon: "fas fa-heart" },
    { title: "Click Rate", value: "3.2%", change: "-2%", changeType: "negative" as const, icon: "fas fa-mouse-pointer" },
    { title: "Comments", value: "2,156", change: "+15%", changeType: "positive" as const, icon: "fas fa-comment" },
    { title: "Shares", value: "890", change: "+28%", changeType: "positive" as const, icon: "fas fa-share" },
    { title: "Saves", value: "1,432", change: "+35%", changeType: "positive" as const, icon: "fas fa-bookmark" },
    { title: "Followers Growth", value: "+284", change: "+22%", changeType: "positive" as const, icon: "fas fa-user-plus" }
  ];

  const platformData: PlatformData[] = [
    { platform: "Instagram", reach: 18500, engagement: 9.2, color: "bg-pink-500", icon: "fab fa-instagram" },
    { platform: "Facebook", reach: 15200, engagement: 6.8, color: "bg-blue-600", icon: "fab fa-facebook-f" },
    { platform: "Twitter", reach: 8900, engagement: 5.4, color: "bg-blue-400", icon: "fab fa-twitter" },
    { platform: "LinkedIn", reach: 4600, engagement: 7.1, color: "bg-blue-700", icon: "fab fa-linkedin-in" },
    { platform: "YouTube", reach: 12300, engagement: 8.5, color: "bg-red-600", icon: "fab fa-youtube" },
    { platform: "TikTok", reach: 9800, engagement: 11.2, color: "bg-black", icon: "fab fa-tiktok" },
    { platform: "Snapchat", reach: 5400, engagement: 6.9, color: "bg-yellow-500", icon: "fab fa-snapchat" }
  ];

  const topPosts: TopPost[] = [
    {
      id: "1",
      content: "5 Tips for Better Social Media Engagement",
      platform: "Instagram",
      engagement: 892,
      reach: 12400,
      date: "2 days ago"
    },
    {
      id: "2", 
      content: "Behind the scenes of our latest campaign",
      platform: "Facebook",
      engagement: 654,
      reach: 8900,
      date: "4 days ago"
    },
    {
      id: "3",
      content: "Industry insights: Marketing trends 2024",
      platform: "LinkedIn", 
      engagement: 543,
      reach: 6700,
      date: "1 week ago"
    },
    {
      id: "4",
      content: "How to Create Viral Content Tutorial",
      platform: "YouTube",
      engagement: 1205,
      reach: 15600,
      date: "3 days ago"
    },
    {
      id: "5",
      content: "Quick productivity hack for entrepreneurs",
      platform: "TikTok",
      engagement: 2341,
      reach: 28900,
      date: "1 day ago"
    }
  ];

  const audienceData = [
    { age: "18-24", percentage: 28, color: "bg-blue-500" },
    { age: "25-34", percentage: 35, color: "bg-blue-600" },
    { age: "35-44", percentage: 22, color: "bg-blue-700" },
    { age: "45-54", percentage: 12, color: "bg-blue-800" },
    { age: "55+", percentage: 3, color: "bg-blue-900" }
  ];

  return (
    <Card className="w-full" data-testid="analytics-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold text-gray-800 flex items-center justify-between">
          <div className="flex items-center">
            <i className="fas fa-chart-line mr-2 text-blue-500"></i>
            Comprehensive Analytics
          </div>
          <Badge variant="secondary" className="text-xs">
            Last 30 days
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
            <TabsTrigger value="platforms" className="text-xs">Platforms</TabsTrigger>
            <TabsTrigger value="posts" className="text-xs">Top Posts</TabsTrigger>
            <TabsTrigger value="audience" className="text-xs">Audience</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            {/* Main Metrics Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {enhancedData.map((item, index) => (
                <div 
                  key={index}
                  className="text-center p-3 bg-gray-50 rounded-lg hover-elevate"
                  data-testid={`stat-${index}`}
                >
                  <div className="flex items-center justify-center mb-1">
                    <i className={`${item.icon} text-lg text-blue-500`}></i>
                  </div>
                  <p className="text-lg font-bold text-gray-800">{item.value}</p>
                  <p className="text-xs text-gray-600 mb-1">{item.title}</p>
                  <div className={`text-xs flex items-center justify-center gap-1 ${
                    item.changeType === 'positive' ? 'text-green-600' : 
                    item.changeType === 'negative' ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    <i className={`fas fa-arrow-${
                      item.changeType === 'positive' ? 'up' : 
                      item.changeType === 'negative' ? 'down' : 'right'
                    } text-xs`}></i>
                    <span>{item.change}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Enhanced Chart */}
            {showChart && (
              <div className="space-y-3">
                <div 
                  className="h-32 rounded-lg relative overflow-hidden"
                  style={{
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                  }}
                  data-testid="analytics-chart"
                >
                  <div className="absolute inset-0 flex items-end justify-around p-4">
                    {[65, 78, 52, 89, 76, 82, 94, 71, 85, 90, 67, 88, 73, 92].map((height, index) => (
                      <div 
                        key={index}
                        className="bg-white/40 rounded-sm w-2 transition-all duration-500 hover:bg-white/60"
                        style={{ height: `${height}%` }}
                      ></div>
                    ))}
                  </div>
                  <div className="absolute top-3 left-4 text-white text-sm">
                    <p className="font-semibold">Engagement Trend</p>
                    <p className="text-white/90 text-xs">14-day period</p>
                  </div>
                  <div className="absolute top-3 right-4 text-white text-right">
                    <p className="text-xs text-white/90">Peak: 94%</p>
                    <p className="text-xs text-white/90">Avg: 79%</p>
                  </div>
                </div>
              </div>
            )}

            {/* AI Insights Enhanced */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-200">
              <h4 className="text-sm font-semibold text-blue-800 mb-2 flex items-center">
                <i className="fas fa-brain mr-2"></i>
                AI-Powered Insights
              </h4>
              <div className="space-y-2 text-sm">
                <p className="text-blue-700">
                  <i className="fas fa-lightbulb mr-1 text-yellow-500"></i>
                  Your engagement rate increased by 24% this week. Posts with videos perform 31% better than image-only posts.
                </p>
                <p className="text-blue-700">
                  <i className="fas fa-clock mr-1 text-green-500"></i>
                  Best posting time: 6-8 PM on weekdays generates 45% more engagement.
                </p>
                <p className="text-blue-700">
                  <i className="fas fa-hashtag mr-1 text-purple-500"></i>
                  Posts with 5-8 hashtags get 23% more reach than posts with fewer hashtags.
                </p>
              </div>
            </div>
          </TabsContent>

          {/* Platforms Tab */}
          <TabsContent value="platforms" className="space-y-4">
            <div className="space-y-3">
              {platformData.map((platform, index) => (
                <div key={index} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 ${platform.color} rounded-lg flex items-center justify-center text-white`}>
                        <i className={platform.icon}></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">{platform.platform}</h4>
                        <p className="text-sm text-gray-600">Reach: {platform.reach.toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-gray-800">{platform.engagement}%</p>
                      <p className="text-xs text-gray-600">Engagement</p>
                    </div>
                  </div>
                  <Progress value={platform.engagement * 10} className="h-2" />
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Top Posts Tab */}
          <TabsContent value="posts" className="space-y-4">
            <div className="space-y-3">
              {topPosts.map((post, index) => (
                <div key={post.id} className="bg-gray-50 p-4 rounded-lg hover-elevate">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <p className="font-medium text-gray-800 text-sm mb-1">{post.content}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-600">
                        <span className="flex items-center">
                          <i className="fas fa-eye mr-1"></i>
                          {post.reach.toLocaleString()} reach
                        </span>
                        <span className="flex items-center">
                          <i className="fas fa-heart mr-1"></i>
                          {post.engagement} engagement
                        </span>
                        <span>{post.date}</span>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs ml-2">
                      {post.platform}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Audience Tab */}
          <TabsContent value="audience" className="space-y-4">
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <i className="fas fa-users mr-2 text-purple-500"></i>
                  Age Demographics
                </h4>
                <div className="space-y-3">
                  {audienceData.map((demographic, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 ${demographic.color} rounded`}></div>
                        <span className="text-sm font-medium text-gray-700">{demographic.age}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Progress value={demographic.percentage} className="w-24 h-2" />
                        <span className="text-sm text-gray-600 w-8">{demographic.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-lg font-bold text-blue-800">62%</p>
                  <p className="text-xs text-blue-600">Female</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-lg font-bold text-green-800">38%</p>
                  <p className="text-xs text-green-600">Male</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-4 border-t">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1 text-xs"
            onClick={() => {
              console.log('Full analytics triggered');
              onViewChange?.('analytics');
            }}
            data-testid="button-full-analytics"
          >
            <i className="fas fa-chart-bar mr-1"></i>
            Full Report
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1 text-xs"
            onClick={() => console.log('Export data triggered')}
            data-testid="button-export-data"
          >
            <i className="fas fa-download mr-1"></i>
            Export Data
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1 text-xs"
            onClick={() => console.log('Schedule report triggered')}
            data-testid="button-schedule-report"
          >
            <i className="fas fa-calendar mr-1"></i>
            Schedule
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}