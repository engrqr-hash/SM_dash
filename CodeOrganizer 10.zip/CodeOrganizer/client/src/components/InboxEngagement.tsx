import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface InboxMessage {
  id: string;
  platform: 'instagram' | 'facebook' | 'twitter' | 'linkedin' | 'youtube' | 'tiktok' | 'snapchat';
  type: 'comment' | 'mention' | 'dm' | 'review';
  user: {
    name: string;
    username: string;
    avatar?: string;
  };
  content: string;
  timestamp: string;
  isRead: boolean;
  sentiment: 'positive' | 'negative' | 'neutral' | 'urgent';
}

export default function InboxEngagement() {
  const [activeTab, setActiveTab] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [messages, setMessages] = useState<InboxMessage[]>([
    {
      id: '1',
      platform: 'instagram',
      type: 'comment',
      user: {
        name: 'Sarah Johnson',
        username: '@sarah_j',
        avatar: ''
      },
      content: 'Love this product! Where can I buy it?',
      timestamp: '2 minutes ago',
      isRead: false,
      sentiment: 'positive'
    },
    {
      id: '2',
      platform: 'facebook',
      type: 'comment',
      user: {
        name: 'Mike Chen',
        username: 'mike.chen',
        avatar: ''
      },
      content: 'Great quality and fast shipping!',
      timestamp: '15 minutes ago',
      isRead: true,
      sentiment: 'positive'
    },
    {
      id: '3',
      platform: 'twitter',
      type: 'mention',
      user: {
        name: 'Emily Davis',
        username: '@emily_design',
        avatar: ''
      },
      content: 'Thanks @yourbrand for the amazing customer service!',
      timestamp: '1 hour ago',
      isRead: false,
      sentiment: 'positive'
    },
    {
      id: '4',
      platform: 'linkedin',
      type: 'comment',
      user: {
        name: 'Robert Wilson',
        username: 'robert.wilson',
        avatar: ''
      },
      content: 'Interesting insights on the industry trends.',
      timestamp: '3 hours ago',
      isRead: true,
      sentiment: 'neutral'
    },
    {
      id: '5',
      platform: 'youtube',
      type: 'comment',
      user: {
        name: 'Alex Turner',
        username: '@alexturner',
        avatar: ''
      },
      content: 'This video helped me so much! Thank you for the tutorial.',
      timestamp: '30 minutes ago',
      isRead: false,
      sentiment: 'positive'
    },
    {
      id: '6',
      platform: 'tiktok',
      type: 'comment',
      user: {
        name: 'Jessica Wong',
        username: '@jessicaw',
        avatar: ''
      },
      content: 'This product broke after one week! Very disappointed.',
      timestamp: '45 minutes ago',
      isRead: false,
      sentiment: 'negative'
    },
    {
      id: '7',
      platform: 'snapchat',
      type: 'dm',
      user: {
        name: 'David Martinez',
        username: 'david.m',
        avatar: ''
      },
      content: 'URGENT: Issue with my order #12345. Need immediate help!',
      timestamp: '5 minutes ago',
      isRead: false,
      sentiment: 'urgent'
    },
    {
      id: '8',
      platform: 'instagram',
      type: 'comment',
      user: {
        name: 'Lisa Park',
        username: '@lisa_park',
        avatar: ''
      },
      content: 'Your service is terrible. Never ordering again!',
      timestamp: '1 hour ago',
      isRead: false,
      sentiment: 'negative'
    }
  ]);

  const getPlatformIcon = (platform: string) => {
    const icons = {
      instagram: 'fab fa-instagram text-pink-500',
      facebook: 'fab fa-facebook-f text-blue-500',
      twitter: 'fab fa-x-twitter text-gray-800',
      linkedin: 'fab fa-linkedin-in text-blue-600',
      youtube: 'fab fa-youtube text-red-600',
      tiktok: 'fab fa-tiktok text-black',
      snapchat: 'fab fa-snapchat text-yellow-500'
    };
    return icons[platform as keyof typeof icons] || 'fas fa-globe';
  };

  const getSentimentColor = (sentiment: string) => {
    const colors = {
      positive: 'text-green-600 bg-green-50',
      negative: 'text-red-600 bg-red-50',
      neutral: 'text-gray-600 bg-gray-50',
      urgent: 'text-orange-600 bg-orange-50'
    };
    return colors[sentiment as keyof typeof colors] || 'text-gray-600 bg-gray-50';
  };

  const getTypeIcon = (type: string) => {
    const icons = {
      comment: 'fas fa-comment',
      mention: 'fas fa-at',
      dm: 'fas fa-envelope',
      review: 'fas fa-star'
    };
    return icons[type as keyof typeof icons] || 'fas fa-message';
  };

  const markAsRead = (id: string) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id ? { ...msg, isRead: true } : msg
    ));
  };

  const unreadCount = messages.filter(msg => !msg.isRead).length;
  const urgentCount = messages.filter(msg => msg.sentiment === 'urgent').length;

  const filteredMessages = messages.filter(msg => {
    // Filter by platform/tab
    let passesTabFilter = true;
    if (activeTab === 'all') passesTabFilter = true;
    else if (activeTab === 'unread') passesTabFilter = !msg.isRead;
    else passesTabFilter = msg.platform === activeTab;

    // Filter by priority/sentiment
    let passesPriorityFilter = true;
    if (priorityFilter === 'all') passesPriorityFilter = true;
    else passesPriorityFilter = msg.sentiment === priorityFilter;

    return passesTabFilter && passesPriorityFilter;
  });

  return (
    <div className="space-y-6" data-testid="inbox-engagement">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center">
            <i className="fas fa-inbox mr-2 text-blue-500"></i>
            Inbox & Engagement
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage comments, mentions, and messages across all platforms
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {unreadCount} unread
          </Badge>
          {urgentCount > 0 && (
            <Badge variant="destructive" className="text-xs">
              {urgentCount} urgent
            </Badge>
          )}
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => console.log('Mark all as read')}
            data-testid="button-mark-all-read"
          >
            <i className="fas fa-check-double mr-1"></i>
            Mark All Read
          </Button>
        </div>
      </div>

      {/* Priority Filter */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h3 className="text-sm font-semibold text-blue-800 flex items-center">
                <i className="fas fa-filter mr-2"></i>
                Priority Filter
              </h3>
              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-48" data-testid="select-priority-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Messages</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                  <SelectItem value="negative">Negative</SelectItem>
                  <SelectItem value="positive">Positive</SelectItem>
                  <SelectItem value="neutral">Neutral</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center gap-3 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                <span className="text-orange-700">Urgent: {messages.filter(m => m.sentiment === 'urgent').length}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="text-red-700">Negative: {messages.filter(m => m.sentiment === 'negative').length}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-green-700">Positive: {messages.filter(m => m.sentiment === 'positive').length}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-700">Neutral: {messages.filter(m => m.sentiment === 'neutral').length}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">24</p>
              <p className="text-xs text-gray-600">New Comments</p>
            </div>
            <i className="fas fa-comment text-blue-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">8</p>
              <p className="text-xs text-gray-600">Mentions</p>
            </div>
            <i className="fas fa-at text-purple-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">12</p>
              <p className="text-xs text-gray-600">Direct Messages</p>
            </div>
            <i className="fas fa-envelope text-green-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">94%</p>
              <p className="text-xs text-gray-600">Response Rate</p>
            </div>
            <i className="fas fa-chart-line text-orange-500 text-xl"></i>
          </div>
        </Card>
      </div>

      {/* Main Content */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Messages</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="w-full overflow-x-auto">
              <TabsList className="inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground min-w-full">
                <TabsTrigger value="all" className="text-xs whitespace-nowrap">All</TabsTrigger>
                <TabsTrigger value="unread" className="text-xs whitespace-nowrap">Unread</TabsTrigger>
                <TabsTrigger value="instagram" className="text-xs whitespace-nowrap">Instagram</TabsTrigger>
                <TabsTrigger value="facebook" className="text-xs whitespace-nowrap">Facebook</TabsTrigger>
                <TabsTrigger value="twitter" className="text-xs whitespace-nowrap">X</TabsTrigger>
                <TabsTrigger value="linkedin" className="text-xs whitespace-nowrap">LinkedIn</TabsTrigger>
                <TabsTrigger value="youtube" className="text-xs whitespace-nowrap">YouTube</TabsTrigger>
                <TabsTrigger value="tiktok" className="text-xs whitespace-nowrap">TikTok</TabsTrigger>
                <TabsTrigger value="snapchat" className="text-xs whitespace-nowrap">Snapchat</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value={activeTab} className="mt-4">
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`p-4 border rounded-lg hover-elevate cursor-pointer transition-all ${
                      message.isRead ? 'bg-white border-gray-200' : 'bg-blue-50 border-blue-200'
                    }`}
                    onClick={() => markAsRead(message.id)}
                    data-testid={`message-${message.id}`}
                  >
                    <div className="flex items-start gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">
                          {message.user.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium text-gray-800">
                              {message.user.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              {message.user.username}
                            </p>
                            <i className={getPlatformIcon(message.platform)}></i>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge 
                              variant="outline" 
                              className={`text-xs px-1 py-0 h-4 ${getSentimentColor(message.sentiment)}`}
                            >
                              {message.sentiment}
                            </Badge>
                            {!message.isRead && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            )}
                          </div>
                        </div>
                        
                        <p className="text-sm text-gray-700 mb-2">{message.content}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <i className={getTypeIcon(message.type)}></i>
                              {message.type}
                            </span>
                            <span>{message.timestamp}</span>
                          </div>
                          
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                              <i className="fas fa-reply mr-1"></i>
                              Reply
                            </Button>
                            <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                              <i className="fas fa-heart mr-1"></i>
                              Like
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {filteredMessages.length === 0 && (
                  <div className="text-center py-12">
                    <i className="fas fa-inbox text-4xl text-gray-300 mb-4"></i>
                    <p className="text-gray-500">No messages in this category</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}