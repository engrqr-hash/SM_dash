import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'editor' | 'viewer';
  avatar?: string;
  status: 'active' | 'pending' | 'disabled';
  lastActive: string;
  permissions: {
    canPost: boolean;
    canSchedule: boolean;
    canAnalyze: boolean;
    canManageTeam: boolean;
  };
}

export default function TeamManagement() {
  const [isInviting, setIsInviting] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<'admin' | 'editor' | 'viewer'>('editor');

  const [teamMembers] = useState<TeamMember[]>([
    {
      id: "1",
      name: "Alex Morgan",
      email: "alex.morgan@company.com",
      role: "owner",
      status: "active",
      lastActive: "Currently active",
      permissions: {
        canPost: true,
        canSchedule: true,
        canAnalyze: true,
        canManageTeam: true
      }
    },
    {
      id: "2",
      name: "Sarah Johnson",
      email: "sarah.j@company.com",
      role: "admin",
      status: "active",
      lastActive: "2 hours ago",
      permissions: {
        canPost: true,
        canSchedule: true,
        canAnalyze: true,
        canManageTeam: true
      }
    },
    {
      id: "3",
      name: "Mike Chen",
      email: "mike.chen@company.com",
      role: "editor",
      status: "active",
      lastActive: "1 day ago",
      permissions: {
        canPost: true,
        canSchedule: true,
        canAnalyze: false,
        canManageTeam: false
      }
    },
    {
      id: "4",
      name: "Emma Davis",
      email: "emma.davis@company.com",
      role: "viewer",
      status: "pending",
      lastActive: "Never",
      permissions: {
        canPost: false,
        canSchedule: false,
        canAnalyze: true,
        canManageTeam: false
      }
    }
  ]);

  const roleDescriptions = {
    owner: "Full access to all features and billing",
    admin: "Manage team, content, and analytics",
    editor: "Create and schedule content",
    viewer: "View analytics and content only"
  };

  const getRoleBadgeColor = (role: string) => {
    const colors = {
      owner: "bg-purple-100 text-purple-800",
      admin: "bg-blue-100 text-blue-800",
      editor: "bg-green-100 text-green-800",
      viewer: "bg-gray-100 text-gray-800"
    };
    return colors[role as keyof typeof colors] || colors.viewer;
  };

  const getStatusBadgeColor = (status: string) => {
    const colors = {
      active: "bg-green-100 text-green-800",
      pending: "bg-yellow-100 text-yellow-800",
      disabled: "bg-red-100 text-red-800"
    };
    return colors[status as keyof typeof colors] || colors.active;
  };

  const handleInvite = () => {
    if (!inviteEmail) return;
    
    console.log('Inviting team member:', { email: inviteEmail, role: inviteRole });
    setInviteEmail("");
    setInviteRole('editor');
    setIsInviting(false);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="space-y-6" data-testid="team-management">
      {/* Team Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <i className="fas fa-users mr-2 text-blue-500"></i>
              Team Management
            </div>
            <Button onClick={() => setIsInviting(true)} data-testid="button-invite-member">
              <i className="fas fa-user-plus mr-2"></i>
              Invite Member
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{teamMembers.length}</div>
              <div className="text-sm text-gray-600">Total Members</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {teamMembers.filter(m => m.status === 'active').length}
              </div>
              <div className="text-sm text-gray-600">Active Members</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">
                {teamMembers.filter(m => m.status === 'pending').length}
              </div>
              <div className="text-sm text-gray-600">Pending Invites</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {teamMembers.filter(m => m.permissions.canPost).length}
              </div>
              <div className="text-sm text-gray-600">Can Create Posts</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invite Member Form */}
      {isInviting && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-800">Invite Team Member</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="invite-email">Email Address</Label>
                <Input
                  id="invite-email"
                  type="email"
                  placeholder="colleague@company.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  data-testid="input-invite-email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invite-role">Role</Label>
                <Select value={inviteRole} onValueChange={(value: 'admin' | 'editor' | 'viewer') => setInviteRole(value)}>
                  <SelectTrigger data-testid="select-invite-role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="editor">Editor</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="bg-white p-3 rounded border">
              <p className="text-sm text-gray-700 font-medium">
                {inviteRole.charAt(0).toUpperCase() + inviteRole.slice(1)} Role:
              </p>
              <p className="text-xs text-gray-600">
                {roleDescriptions[inviteRole as keyof typeof roleDescriptions]}
              </p>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleInvite} data-testid="button-send-invite">
                <i className="fas fa-paper-plane mr-2"></i>
                Send Invitation
              </Button>
              <Button variant="outline" onClick={() => setIsInviting(false)} data-testid="button-cancel-invite">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Team Members List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-list mr-2 text-gray-500"></i>
            Team Members
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {teamMembers.map((member) => (
              <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center space-x-4">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={member.avatar} />
                    <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-gray-900">{member.name}</h4>
                      <Badge className={getRoleBadgeColor(member.role)}>
                        {member.role}
                      </Badge>
                      <Badge className={getStatusBadgeColor(member.status)}>
                        {member.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{member.email}</p>
                    <p className="text-xs text-gray-500">Last active: {member.lastActive}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  {/* Permissions Display */}
                  <div className="flex items-center gap-1">
                    {member.permissions.canPost && (
                      <Badge variant="outline" className="text-xs">
                        <i className="fas fa-edit mr-1"></i>Post
                      </Badge>
                    )}
                    {member.permissions.canSchedule && (
                      <Badge variant="outline" className="text-xs">
                        <i className="fas fa-calendar mr-1"></i>Schedule
                      </Badge>
                    )}
                    {member.permissions.canAnalyze && (
                      <Badge variant="outline" className="text-xs">
                        <i className="fas fa-chart-bar mr-1"></i>Analytics
                      </Badge>
                    )}
                    {member.permissions.canManageTeam && (
                      <Badge variant="outline" className="text-xs">
                        <i className="fas fa-users mr-1"></i>Team
                      </Badge>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-1">
                    {member.role !== 'owner' && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`button-edit-${member.id}`}
                        >
                          <i className="fas fa-edit text-xs"></i>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:text-red-700"
                          data-testid={`button-remove-${member.id}`}
                        >
                          <i className="fas fa-trash text-xs"></i>
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Role Permissions Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-shield-alt mr-2 text-green-500"></i>
            Role Permissions Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(roleDescriptions).map(([role, description]) => (
              <div key={role} className="border rounded-lg p-4">
                <div className="flex items-center mb-3">
                  <Badge className={getRoleBadgeColor(role)}>
                    {role.charAt(0).toUpperCase() + role.slice(1)}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-3">{description}</p>
                
                <div className="space-y-2">
                  <div className="flex items-center text-xs">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      ['owner', 'admin', 'editor'].includes(role) ? 'bg-green-500' : 'bg-gray-300'
                    }`}></div>
                    <span>Create & Edit Posts</span>
                  </div>
                  <div className="flex items-center text-xs">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      ['owner', 'admin', 'editor'].includes(role) ? 'bg-green-500' : 'bg-gray-300'
                    }`}></div>
                    <span>Schedule Content</span>
                  </div>
                  <div className="flex items-center text-xs">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      ['owner', 'admin', 'viewer'].includes(role) ? 'bg-green-500' : 'bg-gray-300'
                    }`}></div>
                    <span>View Analytics</span>
                  </div>
                  <div className="flex items-center text-xs">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      ['owner', 'admin'].includes(role) ? 'bg-green-500' : 'bg-gray-300'
                    }`}></div>
                    <span>Manage Team</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}