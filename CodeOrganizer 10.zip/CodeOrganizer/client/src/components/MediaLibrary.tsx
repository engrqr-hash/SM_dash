import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";

interface MediaItem {
  id: string;
  name: string;
  type: 'image' | 'video' | 'gif' | 'document';
  size: number;
  uploadDate: string;
  tags: string[];
  usageCount: number;
  url?: string;
  dimensions?: {
    width: number;
    height: number;
  };
}

export default function MediaLibrary() {
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  const mediaItems: MediaItem[] = [
    {
      id: '1',
      name: 'product-hero-banner.jpg',
      type: 'image',
      size: 2048000,
      uploadDate: '2024-01-10',
      tags: ['product', 'banner', 'hero'],
      usageCount: 15,
      dimensions: { width: 1920, height: 1080 }
    },
    {
      id: '2',
      name: 'team-photo-2024.jpg',
      type: 'image',
      size: 1536000,
      uploadDate: '2024-01-08',
      tags: ['team', 'about', 'people'],
      usageCount: 8,
      dimensions: { width: 1200, height: 800 }
    },
    {
      id: '3',
      name: 'product-demo-video.mp4',
      type: 'video',
      size: 15728640,
      uploadDate: '2024-01-05',
      tags: ['demo', 'product', 'tutorial'],
      usageCount: 23,
      dimensions: { width: 1920, height: 1080 }
    },
    {
      id: '4',
      name: 'celebration-gif.gif',
      type: 'gif',
      size: 512000,
      uploadDate: '2024-01-03',
      tags: ['celebration', 'animation', 'fun'],
      usageCount: 12
    },
    {
      id: '5',
      name: 'office-workspace.jpg',
      type: 'image',
      size: 1024000,
      uploadDate: '2024-01-01',
      tags: ['office', 'workspace', 'culture'],
      usageCount: 5,
      dimensions: { width: 1600, height: 900 }
    },
    {
      id: '6',
      name: 'brand-guidelines.pdf',
      type: 'document',
      size: 3072000,
      uploadDate: '2023-12-28',
      tags: ['brand', 'guidelines', 'reference'],
      usageCount: 3
    }
  ];

  const getFileIcon = (type: string) => {
    const icons = {
      image: 'fas fa-image text-blue-500',
      video: 'fas fa-video text-red-500',
      gif: 'fas fa-film text-purple-500',
      document: 'fas fa-file-alt text-gray-500'
    };
    return icons[type as keyof typeof icons] || 'fas fa-file';
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const filteredItems = mediaItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (activeTab === 'all') return matchesSearch;
    return item.type === activeTab && matchesSearch;
  });

  const toggleItemSelection = (itemId: string) => {
    setSelectedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const getTypeCounts = () => {
    return {
      all: mediaItems.length,
      image: mediaItems.filter(item => item.type === 'image').length,
      video: mediaItems.filter(item => item.type === 'video').length,
      gif: mediaItems.filter(item => item.type === 'gif').length,
      document: mediaItems.filter(item => item.type === 'document').length
    };
  };

  const typeCounts = getTypeCounts();
  const totalSize = mediaItems.reduce((sum, item) => sum + item.size, 0);

  return (
    <div className="space-y-6" data-testid="media-library">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center">
            <i className="fas fa-folder-open mr-2 text-orange-500"></i>
            Media Library
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage your images, videos, and documents for social media content
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selectedItems.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {selectedItems.length} selected
            </Badge>
          )}
          <div className="flex bg-gray-100 rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              className="text-xs h-7 px-2"
              onClick={() => setViewMode('grid')}
              data-testid="button-grid-view"
            >
              <i className="fas fa-th"></i>
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              className="text-xs h-7 px-2"
              onClick={() => setViewMode('list')}
              data-testid="button-list-view"
            >
              <i className="fas fa-list"></i>
            </Button>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => console.log('Upload media')}
            data-testid="button-upload-media"
          >
            <i className="fas fa-upload mr-1"></i>
            Upload
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">{typeCounts.all}</p>
              <p className="text-xs text-gray-600">Total Files</p>
            </div>
            <i className="fas fa-files text-blue-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">{formatFileSize(totalSize)}</p>
              <p className="text-xs text-gray-600">Storage Used</p>
            </div>
            <i className="fas fa-hdd text-green-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">{typeCounts.image}</p>
              <p className="text-xs text-gray-600">Images</p>
            </div>
            <i className="fas fa-image text-purple-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">{typeCounts.video}</p>
              <p className="text-xs text-gray-600">Videos</p>
            </div>
            <i className="fas fa-video text-red-500 text-xl"></i>
          </div>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex items-center gap-4">
        <div className="flex-1">
          <Input
            placeholder="Search by filename or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
            data-testid="search-input"
          />
        </div>
        {selectedItems.length > 0 && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="text-xs">
              <i className="fas fa-download mr-1"></i>
              Download
            </Button>
            <Button variant="outline" size="sm" className="text-xs">
              <i className="fas fa-trash mr-1"></i>
              Delete
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs"
              onClick={() => setSelectedItems([])}
            >
              Clear
            </Button>
          </div>
        )}
      </div>

      {/* Media Content */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Files</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 mb-4">
              <TabsTrigger value="all" className="text-xs">
                All ({typeCounts.all})
              </TabsTrigger>
              <TabsTrigger value="image" className="text-xs">
                Images ({typeCounts.image})
              </TabsTrigger>
              <TabsTrigger value="video" className="text-xs">
                Videos ({typeCounts.video})
              </TabsTrigger>
              <TabsTrigger value="gif" className="text-xs">
                GIFs ({typeCounts.gif})
              </TabsTrigger>
              <TabsTrigger value="document" className="text-xs">
                Documents ({typeCounts.document})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab}>
              {viewMode === 'grid' ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {filteredItems.map((item) => (
                    <div
                      key={item.id}
                      className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 hover-elevate cursor-pointer"
                      onClick={() => toggleItemSelection(item.id)}
                      data-testid={`media-item-${item.id}`}
                    >
                      <div className="relative">
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(item.id)}
                          onChange={() => toggleItemSelection(item.id)}
                          className="absolute top-2 right-2 z-10"
                          onClick={(e) => e.stopPropagation()}
                        />
                        
                        <div className="w-[50px] h-[50px] bg-gray-100 rounded-lg flex items-center justify-center mb-3 flex-shrink-0">
                          <i className={`${getFileIcon(item.type)} text-xl`}></i>
                        </div>
                        
                        <div className="space-y-1">
                          <p className="text-sm font-medium text-gray-800 truncate" title={item.name}>
                            {item.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {formatFileSize(item.size)}
                          </p>
                          {item.dimensions && (
                            <p className="text-xs text-gray-400">
                              {item.dimensions.width} × {item.dimensions.height}
                            </p>
                          )}
                          <div className="flex items-center justify-between">
                            <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                              Used {item.usageCount}x
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-4 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 hover-elevate cursor-pointer"
                      onClick={() => toggleItemSelection(item.id)}
                      data-testid={`media-item-list-${item.id}`}
                    >
                      <input
                        type="checkbox"
                        checked={selectedItems.includes(item.id)}
                        onChange={() => toggleItemSelection(item.id)}
                        onClick={(e) => e.stopPropagation()}
                      />
                      
                      <div className="w-[50px] h-[50px] bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <i className={getFileIcon(item.type)}></i>
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-800 truncate">
                            {item.name}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span>{formatFileSize(item.size)}</span>
                            {item.dimensions && (
                              <span>{item.dimensions.width} × {item.dimensions.height}</span>
                            )}
                            <span>Used {item.usageCount}x</span>
                            <span>{formatDate(item.uploadDate)}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-1 mt-1">
                          {item.tags.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs px-1 py-0 h-4">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                          <i className="fas fa-eye"></i>
                        </Button>
                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                          <i className="fas fa-download"></i>
                        </Button>
                        <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                          <i className="fas fa-ellipsis-v"></i>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {filteredItems.length === 0 && (
                <div className="text-center py-12">
                  <i className="fas fa-folder-open text-4xl text-gray-300 mb-4"></i>
                  <p className="text-gray-500">No files found</p>
                  {searchQuery && (
                    <p className="text-sm text-gray-400 mt-1">
                      Try different search terms or clear filters
                    </p>
                  )}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-3"
                    onClick={() => console.log('Upload first file')}
                  >
                    <i className="fas fa-upload mr-1"></i>
                    Upload Your First File
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}