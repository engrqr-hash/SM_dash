import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface AIResponse {
  id: string;
  type: 'content' | 'hashtags' | 'optimization' | 'strategy';
  prompt: string;
  response: string;
  timestamp: string;
}

export default function AIAssistant() {
  const [activeTab, setActiveTab] = useState('content');
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [responses, setResponses] = useState<AIResponse[]>([]);

  const predefinedPrompts = {
    content: [
      "Write a compelling Instagram post about our new product launch",
      "Create an engaging Facebook post for our weekend sale",
      "Generate a professional LinkedIn article about industry trends",
      "Write a Twitter thread about our company values"
    ],
    hashtags: [
      "Generate trending hashtags for a tech startup",
      "Create lifestyle hashtags for a wellness brand",
      "Find business hashtags for professional content",
      "Generate viral hashtags for entertainment content"
    ],
    optimization: [
      "Analyze this post and suggest improvements for better engagement",
      "Optimize posting times for maximum reach",
      "Improve this caption for better conversion rates",
      "Suggest A/B testing strategies for social media content"
    ],
    strategy: [
      "Create a content calendar strategy for next month",
      "Develop a social media growth plan",
      "Plan a product launch campaign across platforms",
      "Design an influencer collaboration strategy"
    ]
  };

  const handleSubmit = async () => {
    if (!prompt.trim()) return;
    
    setIsLoading(true);
    
    // Simulate AI response
    setTimeout(() => {
      const newResponse: AIResponse = {
        id: Date.now().toString(),
        type: activeTab as any,
        prompt: prompt,
        response: generateMockResponse(activeTab, prompt),
        timestamp: new Date().toLocaleTimeString()
      };
      
      setResponses(prev => [newResponse, ...prev]);
      setPrompt('');
      setIsLoading(false);
    }, 2000);
  };

  const generateMockResponse = (type: string, prompt: string): string => {
    const responses = {
      content: `Here's an engaging post idea:\n\n🚀 Exciting news! We're thrilled to announce our latest innovation that's going to transform how you work. This isn't just another product – it's a game-changer that puts the power back in your hands.\n\n✨ Key benefits:\n• Save 3+ hours daily\n• Boost productivity by 40%\n• Seamless integration\n• Enterprise-grade security\n\nReady to revolutionize your workflow? Link in bio! 👆\n\n#Innovation #Productivity #TechNews #NewProduct`,
      hashtags: `Here are trending hashtags for your content:\n\n🔥 High Volume:\n#TechInnovation #DigitalTransformation #FutureOfWork #StartupLife #Innovation\n\n📈 Medium Volume:\n#ProductivityHacks #TechStartup #SaaSTech #WorkSmarter #TechTrends\n\n🎯 Niche Specific:\n#B2BTech #EnterpriseTools #WorkflowOptimization #TechSolutions #BusinessGrowth\n\nRecommended mix: Use 2-3 high volume + 3-4 medium volume + 2-3 niche hashtags`,
      optimization: `Content Optimization Analysis:\n\n📊 Current Performance: Good baseline engagement\n\n🚀 Improvement Suggestions:\n\n1. **Hook Enhancement**: Start with a compelling question or statistic\n2. **Call-to-Action**: Add clear, specific CTAs ("Double-tap if you agree!")\n3. **Visual Elements**: Include more emojis and line breaks for readability\n4. **Timing**: Post during peak hours (6-9 PM for your audience)\n5. **Engagement Triggers**: Ask questions to encourage comments\n\n📈 Expected Results: 25-40% increase in engagement`,
      strategy: `30-Day Social Media Strategy:\n\n🗓️ **Week 1: Foundation**\n- Brand story series (4 posts)\n- Behind-the-scenes content\n- Team introductions\n\n🗓️ **Week 2: Value Delivery**\n- Educational carousel posts\n- Tips and tutorials\n- User-generated content campaign\n\n🗓️ **Week 3: Community Building**\n- Interactive polls and Q&As\n- Live sessions\n- Customer spotlight features\n\n🗓️ **Week 4: Conversion Focus**\n- Product showcases\n- Customer testimonials\n- Limited-time offers\n\n🎯 **KPIs to Track**: Engagement rate, reach, website clicks, conversions`
    };
    
    return responses[type as keyof typeof responses] || "AI response generated based on your prompt.";
  };

  const usePredefinedPrompt = (promptText: string) => {
    setPrompt(promptText);
  };

  const getTabIcon = (tab: string) => {
    const icons = {
      content: 'fas fa-edit',
      hashtags: 'fas fa-hashtag',
      optimization: 'fas fa-chart-line',
      strategy: 'fas fa-chess'
    };
    return icons[tab as keyof typeof icons];
  };

  return (
    <div className="space-y-6" data-testid="ai-assistant">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center">
            <i className="fas fa-robot mr-2 text-purple-500"></i>
            AI Assistant
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Get AI-powered help with content creation, optimization, and strategy
          </p>
        </div>
        <Badge variant="secondary" className="bg-purple-100 text-purple-700">
          <i className="fas fa-magic mr-1"></i>
          AI Powered
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Input Panel */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <i className="fas fa-comments mr-2 text-blue-500"></i>
                Chat with AI
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="content" className="text-xs">
                    <i className={`${getTabIcon('content')} mr-1`}></i>
                    Content
                  </TabsTrigger>
                  <TabsTrigger value="hashtags" className="text-xs">
                    <i className={`${getTabIcon('hashtags')} mr-1`}></i>
                    Hashtags
                  </TabsTrigger>
                  <TabsTrigger value="optimization" className="text-xs">
                    <i className={`${getTabIcon('optimization')} mr-1`}></i>
                    Optimize
                  </TabsTrigger>
                  <TabsTrigger value="strategy" className="text-xs">
                    <i className={`${getTabIcon('strategy')} mr-1`}></i>
                    Strategy
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value={activeTab} className="mt-4">
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-gray-700">Quick Prompts:</h4>
                    <div className="grid grid-cols-1 gap-2">
                      {predefinedPrompts[activeTab as keyof typeof predefinedPrompts].map((promptText, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="justify-start text-left h-auto p-3 text-xs"
                          onClick={() => usePredefinedPrompt(promptText)}
                          data-testid={`prompt-${activeTab}-${index}`}
                        >
                          <i className="fas fa-lightbulb mr-2 text-yellow-500"></i>
                          {promptText}
                        </Button>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <div className="space-y-3">
                <Textarea
                  placeholder={`Ask AI to help with ${activeTab}... (e.g., "Create an Instagram post about our new product launch")`}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-[100px] resize-none"
                  data-testid="ai-prompt-input"
                />
                
                <div className="flex gap-2">
                  <Button
                    onClick={handleSubmit}
                    disabled={!prompt.trim() || isLoading}
                    className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500"
                    data-testid="button-submit-prompt"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                        Generating...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-paper-plane mr-2"></i>
                        Generate with AI
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setPrompt('')}
                    data-testid="button-clear-prompt"
                  >
                    <i className="fas fa-eraser"></i>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Response History */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center justify-between">
                <span className="flex items-center">
                  <i className="fas fa-history mr-2 text-green-500"></i>
                  Recent Responses
                </span>
                <Badge variant="secondary" className="text-xs">
                  {responses.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {responses.map((response) => (
                  <div
                    key={response.id}
                    className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 hover-elevate cursor-pointer"
                    data-testid={`response-${response.id}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="text-xs">
                        <i className={`${getTabIcon(response.type)} mr-1`}></i>
                        {response.type}
                      </Badge>
                      <span className="text-xs text-gray-500">{response.timestamp}</span>
                    </div>
                    <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                      {response.prompt}
                    </p>
                    <p className="text-xs text-gray-800 line-clamp-3">
                      {response.response}
                    </p>
                    <div className="flex gap-1 mt-2">
                      <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                        <i className="fas fa-copy mr-1"></i>
                        Copy
                      </Button>
                      <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                        <i className="fas fa-edit mr-1"></i>
                        Use
                      </Button>
                    </div>
                  </div>
                ))}
                
                {responses.length === 0 && (
                  <div className="text-center py-8">
                    <i className="fas fa-robot text-xl text-gray-300 mb-3"></i>
                    <p className="text-sm text-gray-500">No AI responses yet</p>
                    <p className="text-xs text-gray-400">Start a conversation with AI</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}