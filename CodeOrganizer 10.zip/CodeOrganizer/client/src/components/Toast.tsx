import { useEffect, useState } from "react";

interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'warning';
  isVisible: boolean;
  onClose: () => void;
}

export default function Toast({ message, type = 'success', isVisible, onClose }: ToastProps) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  const typeStyles = {
    success: 'bg-green-500',
    error: 'bg-red-500', 
    warning: 'bg-yellow-500'
  };

  return (
    <div 
      className={`fixed top-4 right-4 p-3 rounded-lg text-white font-medium z-50 transition-transform duration-300 ${
        typeStyles[type]
      } ${isVisible ? 'translate-x-0' : 'translate-x-full'}`}
      data-testid={`toast-${type}`}
    >
      <div className="flex items-center gap-2">
        <span>{message}</span>
        <button 
          onClick={onClose}
          className="ml-2 text-white hover:text-gray-200"
          data-testid="button-close-toast"
        >
          <i className="fas fa-times text-sm"></i>
        </button>
      </div>
    </div>
  );
}

// Toast Provider Hook
export function useToast() {
  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'error' | 'warning';
    isVisible: boolean;
  }>({
    message: '',
    type: 'success',
    isVisible: false
  });

  const showToast = (message: string, type: 'success' | 'error' | 'warning' = 'success') => {
    setToast({ message, type, isVisible: true });
  };

  const hideToast = () => {
    setToast(prev => ({ ...prev, isVisible: false }));
  };

  return { toast, showToast, hideToast };
}