import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AutoReply, InsertAutoReply } from '@shared/schema';
import { Bot, Brain, User, Sparkles, MessageSquare, Heart, AlertTriangle, Zap, Target, Globe } from "lucide-react";

interface AutoRepliesProps {
  onSave: (autoReplyData: InsertAutoReply) => void;
  onViewChange?: (view: string) => void;
}

export default function AutoReplies({ onSave, onViewChange }: AutoRepliesProps) {
  // Fetch auto-replies from API
  const { data: autoReplies = [], isLoading } = useQuery<AutoReply[]>({
    queryKey: ['/api/auto-replies'],
  });

  // State management
  const [isCreating, setIsCreating] = useState(false);
  const [editingReply, setEditingReply] = useState<AutoReply | null>(null);
  const [previewText, setPreviewText] = useState("");
  const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
  const [previewResult, setPreviewResult] = useState<any>(null);
  
  // Form state - enhanced with AI fields
  const [replyName, setReplyName] = useState("");
  const [triggerKeywords, setTriggerKeywords] = useState<string[]>([]);
  const [keywordInput, setKeywordInput] = useState("");
  const [responseTemplate, setResponseTemplate] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState(new Set<string>());
  const [replyType, setReplyType] = useState<"comment" | "message" | "both">("comment");
  const [isActive, setIsActive] = useState(true);
  
  // AI-enhanced fields
  const [mode, setMode] = useState<"auto" | "assist" | "manual">("assist");
  const [selectedIntents, setSelectedIntents] = useState<string[]>([]);
  const [language, setLanguage] = useState("en");
  const [riskThreshold, setRiskThreshold] = useState(0.7);
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(150);
  const [escalateAfter, setEscalateAfter] = useState(3);
  const [escalateTo, setEscalateTo] = useState("");

  const platforms = [
    { id: 'facebook', name: 'Facebook', icon: 'fab fa-facebook-f', color: '#1877f2' },
    { id: 'instagram', name: 'Instagram', icon: 'fab fa-instagram', color: '#E4405F' },
    { id: 'twitter', name: 'X (Twitter)', icon: 'fab fa-x-twitter', color: '#000000' },
    { id: 'linkedin', name: 'LinkedIn', icon: 'fab fa-linkedin-in', color: '#0077b5' },
    { id: 'tiktok', name: 'TikTok', icon: 'fab fa-tiktok', color: '#000000' },
    { id: 'youtube', name: 'YouTube', icon: 'fab fa-youtube', color: '#FF0000' },
  ];

  const intents = [
    { id: 'support', label: 'Support Inquiry', icon: Heart, color: 'text-blue-600' },
    { id: 'complaint', label: 'Complaint', icon: AlertTriangle, color: 'text-red-600' },
    { id: 'question', label: 'General Question', icon: MessageSquare, color: 'text-green-600' },
    { id: 'compliment', label: 'Compliment', icon: Sparkles, color: 'text-purple-600' },
    { id: 'purchase', label: 'Purchase Interest', icon: Target, color: 'text-orange-600' },
    { id: 'feedback', label: 'Feedback', icon: Globe, color: 'text-teal-600' },
  ];

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'it', name: 'Italian' },
    { code: 'pt', name: 'Portuguese' },
  ];

  // Mutations
  const createMutation = useMutation({
    mutationFn: async (data: InsertAutoReply) => {
      const res = await apiRequest('POST', '/api/auto-replies', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-replies'] });
      setIsCreating(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string, data: Partial<InsertAutoReply> }) => {
      const res = await apiRequest('PUT', `/api/auto-replies/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-replies'] });
      setIsCreating(false);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('DELETE', `/api/auto-replies/${id}`);
      return res.ok;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auto-replies'] });
    },
  });

  const handlePlatformToggle = (platformId: string) => {
    const newSelected = new Set(selectedPlatforms);
    if (newSelected.has(platformId)) {
      newSelected.delete(platformId);
    } else {
      newSelected.add(platformId);
    }
    setSelectedPlatforms(newSelected);
  };

  const handleIntentToggle = (intent: string) => {
    setSelectedIntents(prev => 
      prev.includes(intent) 
        ? prev.filter(i => i !== intent)
        : [...prev, intent]
    );
  };

  const handleAddKeyword = () => {
    if (keywordInput.trim() && !triggerKeywords.includes(keywordInput.trim().toLowerCase())) {
      setTriggerKeywords([...triggerKeywords, keywordInput.trim().toLowerCase()]);
      setKeywordInput("");
    }
  };

  const handleRemoveKeyword = (keyword: string) => {
    setTriggerKeywords(triggerKeywords.filter(k => k !== keyword));
  };

  const resetForm = () => {
    setReplyName("");
    setTriggerKeywords([]);
    setKeywordInput("");
    setResponseTemplate("");
    setSelectedPlatforms(new Set());
    setReplyType("comment");
    setIsActive(true);
    setMode("assist");
    setSelectedIntents([]);
    setLanguage("en");
    setRiskThreshold(0.7);
    setTemperature(0.7);
    setMaxTokens(150);
    setEscalateAfter(3);
    setEscalateTo("");
    setEditingReply(null);
    setPreviewText("");
    setPreviewResult(null);
  };

  const handleEdit = (reply: AutoReply) => {
    setEditingReply(reply);
    setReplyName(reply.name);
    setTriggerKeywords(reply.triggerKeywords as string[]);
    setResponseTemplate(reply.responseTemplate);
    setSelectedPlatforms(new Set(reply.platforms as string[]));
    setReplyType(reply.replyType as "comment" | "message" | "both");
    setIsActive(reply.isActive);
    setMode(reply.mode as "auto" | "assist" | "manual" || "assist");
    setSelectedIntents(reply.intents as string[] || []);
    setLanguage(reply.language || "en");
    setRiskThreshold(typeof reply.riskThreshold === 'string' ? parseFloat(reply.riskThreshold) : reply.riskThreshold || 0.7);
    setTemperature(typeof reply.temperature === 'string' ? parseFloat(reply.temperature) : reply.temperature || 0.7);
    setMaxTokens(reply.maxTokens || 150);
    setEscalateAfter(reply.escalateAfter || 3);
    setEscalateTo(reply.escalateTo || "");
    setIsCreating(true);
  };

  const generatePreview = async () => {
    if (!previewText.trim() || !selectedIntents.length) return;
    
    setIsGeneratingPreview(true);
    try {
      const res = await apiRequest('POST', '/api/ai/generate', {
        context: previewText,
        intent: selectedIntents[0],
        template: responseTemplate,
        platform: Array.from(selectedPlatforms)[0] || 'instagram',
        tone: temperature > 0.8 ? 'casual' : temperature > 0.4 ? 'friendly' : 'professional',
        maxTokens,
        language
      });
      const response = await res.json();
      setPreviewResult(response);
    } catch (error) {
      console.error('Failed to generate preview:', error);
    }
    setIsGeneratingPreview(false);
  };

  const handleSave = () => {
    const autoReplyData: InsertAutoReply = {
      name: replyName,
      triggerKeywords,
      responseTemplate,
      platforms: Array.from(selectedPlatforms),
      isActive,
      replyType,
      mode,
      intents: selectedIntents,
      language,
      riskThreshold: riskThreshold,
      temperature: temperature,
      maxTokens,
      escalateAfter,
      escalateTo: escalateTo || null,
      // Required fields with defaults
      rateLimit: { perMinute: 5, perHour: 50 },
      schedule: { days: [], start: "09:00", end: "17:00" },
      useLLM: true,
      modelId: "gemini-2.0-flash-lite",
      safety: { moderate: true, blockPII: true },
    };

    if (editingReply) {
      updateMutation.mutate({ id: editingReply.id, data: autoReplyData });
    } else {
      createMutation.mutate(autoReplyData);
    }
  };

  const handleToggleActive = async (replyId: string, currentState: boolean) => {
    try {
      await apiRequest('PUT', `/api/auto-replies/${replyId}`, { isActive: !currentState });
      queryClient.invalidateQueries({ queryKey: ['/api/auto-replies'] });
    } catch (error) {
      console.error('Failed to toggle active state:', error);
    }
  };

  const handleDelete = (replyId: string) => {
    if (confirm('Are you sure you want to delete this auto-reply?')) {
      deleteMutation.mutate(replyId);
    }
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'auto': return <Bot className="w-4 h-4" />;
      case 'assist': return <Brain className="w-4 h-4" />;
      case 'manual': return <User className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const getModeColor = (mode: string) => {
    switch (mode) {
      case 'auto': return 'text-green-600 bg-green-50 border-green-200';
      case 'assist': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'manual': return 'text-gray-600 bg-gray-50 border-gray-200';
      default: return 'text-blue-600 bg-blue-50 border-blue-200';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6" data-testid="auto-replies-manager">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">AI Auto-Replies</h1>
            <p className="text-gray-600 mt-1">Intelligent automated responses powered by AI</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-gray-600 bg-purple-50 px-3 py-1.5 rounded-full">
              <Zap className="w-4 h-4 text-purple-600" />
              <span className="font-medium">AI Powered</span>
            </div>
            <Button 
              onClick={() => setIsCreating(true)}
              data-testid="button-create-auto-reply"
            >
              <Bot className="w-4 h-4 mr-2" />
              Create Auto-Reply
            </Button>
          </div>
        </div>

        {!isCreating ? (
          <>
            {/* Auto Replies List */}
            <div className="space-y-4">
              {autoReplies.map((reply) => (
                <Card key={reply.id} className="border-gray-200 hover-elevate" data-testid={`auto-reply-card-${reply.id}`}>
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <CardTitle className="text-lg font-semibold text-gray-800">
                            {reply.name}
                          </CardTitle>
                          <div className={`flex items-center gap-1 px-2 py-1 rounded-md text-sm font-medium border ${getModeColor(reply.mode)}`}>
                            {getModeIcon(reply.mode)}
                            <span className="capitalize">{reply.mode}</span>
                          </div>
                          <Switch
                            checked={reply.isActive}
                            onCheckedChange={() => handleToggleActive(reply.id, reply.isActive)}
                            data-testid={`switch-active-${reply.id}`}
                          />
                          <span className="text-sm text-gray-500">
                            {reply.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-3 mb-3">
                          <Badge variant={reply.replyType === 'comment' ? 'default' : reply.replyType === 'message' ? 'secondary' : 'outline'}>
                            {reply.replyType === 'comment' ? 'Comments Only' : 
                             reply.replyType === 'message' ? 'Messages Only' : 'Comments & Messages'}
                          </Badge>
                          
                          <div className="flex items-center gap-1">
                            {(reply.platforms as string[]).map((platformId) => {
                              const platform = platforms.find(p => p.id === platformId);
                              return platform ? (
                                <div 
                                  key={platformId}
                                  className="w-6 h-6 rounded-full flex items-center justify-center text-white text-sm"
                                  style={{ backgroundColor: platform.color }}
                                  title={platform.name}
                                >
                                  <i className={platform.icon}></i>
                                </div>
                              ) : null;
                            })}
                          </div>

                          {(() => {
                            const intents = reply.intents as string[] | null;
                            return intents && intents.length > 0 ? (
                              <div className="flex items-center gap-1">
                                <Brain className="w-4 h-4 text-gray-400" />
                                <span className="text-sm text-gray-600">
                                  {intents.length} intent{intents.length > 1 ? 's' : ''}
                                </span>
                              </div>
                            ) : null;
                          })()}
                        </div>
                        
                        <div className="flex flex-wrap gap-1 mb-3">
                          {(reply.triggerKeywords as string[]).slice(0, 4).map((keyword) => (
                            <Badge key={keyword} variant="outline" className="text-xs">
                              {keyword}
                            </Badge>
                          ))}
                          {(reply.triggerKeywords as string[]).length > 4 && (
                            <Badge variant="outline" className="text-xs">
                              +{(reply.triggerKeywords as string[]).length - 4} more
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleEdit(reply)}
                          data-testid={`button-edit-${reply.id}`}
                        >
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleDelete(reply.id)}
                          className="text-red-600 hover:text-red-700"
                          data-testid={`button-delete-${reply.id}`}
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="bg-gray-50 rounded-lg p-4 mb-4">
                      <p className="text-sm text-gray-700">{reply.responseTemplate}</p>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center gap-4">
                        <span>Risk: {(parseFloat(reply.riskThreshold as string || '0.7') * 100).toFixed(0)}%</span>
                        <span>Temp: {(parseFloat(reply.temperature as string || '0.7')).toFixed(1)}</span>
                        <span>Tokens: {reply.maxTokens || 150}</span>
                      </div>
                      <span>Updated: {new Date(reply.updatedAt).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {autoReplies.length === 0 && (
              <div className="text-center py-12">
                <Bot className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No AI Auto-Replies Yet</h3>
                <p className="text-gray-500 mb-6">Create intelligent automated responses powered by AI</p>
                <Button onClick={() => setIsCreating(true)}>
                  <Bot className="w-4 h-4 mr-2" />
                  Create Your First Auto-Reply
                </Button>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Create/Edit Form */}
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-6 mb-6">
              <div className="flex items-start gap-3">
                <Brain className="w-6 h-6 text-purple-600 mt-1" />
                <div>
                  <h3 className="text-lg font-semibold text-purple-800 mb-2">
                    {editingReply ? 'Edit AI Auto-Reply' : 'Create AI Auto-Reply'}
                  </h3>
                  <p className="text-purple-700">
                    Configure intelligent automated responses with sentiment analysis and context-aware generation
                  </p>
                </div>
              </div>
            </div>

            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="basic">Basic Setup</TabsTrigger>
                <TabsTrigger value="ai">AI Configuration</TabsTrigger>
                <TabsTrigger value="rules">Advanced Rules</TabsTrigger>
                <TabsTrigger value="preview">Preview & Test</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-6 mt-6">
                {/* Basic Configuration */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-semibold text-gray-700 mb-2">Reply Name</Label>
                    <Input 
                      placeholder="e.g., Customer Support Assistant"
                      value={replyName}
                      onChange={(e) => setReplyName(e.target.value)}
                      data-testid="input-reply-name"
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-semibold text-gray-700 mb-2">Reply Type</Label>
                    <Select value={replyType} onValueChange={(value: "comment" | "message" | "both") => setReplyType(value)}>
                      <SelectTrigger data-testid="select-reply-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="comment">Comments Only</SelectItem>
                        <SelectItem value="message">Messages Only</SelectItem>
                        <SelectItem value="both">Comments & Messages</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* AI Mode Selection */}
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-3">AI Mode</Label>
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { 
                        mode: 'auto', 
                        label: 'Fully Automatic', 
                        description: 'AI generates and sends responses automatically',
                        icon: <Bot className="w-5 h-5" />
                      },
                      { 
                        mode: 'assist', 
                        label: 'AI Assisted', 
                        description: 'AI suggests responses for your approval',
                        icon: <Brain className="w-5 h-5" />
                      },
                      { 
                        mode: 'manual', 
                        label: 'Manual Override', 
                        description: 'Use template responses without AI',
                        icon: <User className="w-5 h-5" />
                      },
                    ].map(({ mode: modeValue, label, description, icon }) => (
                      <div 
                        key={modeValue}
                        className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                          mode === modeValue 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setMode(modeValue as any)}
                        data-testid={`mode-${modeValue}`}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          {icon}
                          <span className="font-semibold text-sm">{label}</span>
                        </div>
                        <p className="text-xs text-gray-600">{description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Trigger Keywords */}
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-2">Trigger Keywords</Label>
                  <div className="flex gap-2 mb-3">
                    <Input 
                      placeholder="Add keyword or phrase..."
                      value={keywordInput}
                      onChange={(e) => setKeywordInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddKeyword()}
                      data-testid="input-trigger-keyword"
                    />
                    <Button onClick={handleAddKeyword} data-testid="button-add-keyword">
                      Add
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {triggerKeywords.map((keyword) => (
                      <Badge key={keyword} variant="outline" className="text-sm">
                        {keyword}
                        <button 
                          onClick={() => handleRemoveKeyword(keyword)}
                          className="ml-2 text-red-500 hover:text-red-700"
                          data-testid={`button-remove-keyword-${keyword}`}
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Platform Selection */}
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-3">Target Platforms</Label>
                  <div className="grid grid-cols-3 gap-3">
                    {platforms.map((platform) => (
                      <div 
                        key={platform.id}
                        className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                          selectedPlatforms.has(platform.id) 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handlePlatformToggle(platform.id)}
                        data-testid={`platform-toggle-${platform.id}`}
                      >
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-8 h-8 rounded-full flex items-center justify-center text-white"
                            style={{ backgroundColor: platform.color }}
                          >
                            <i className={platform.icon}></i>
                          </div>
                          <span className="font-medium text-sm">{platform.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="ai" className="space-y-6 mt-6">
                {/* AI Configuration */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-semibold text-gray-700 mb-2">Language</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {languages.map((lang) => (
                          <SelectItem key={lang.code} value={lang.code}>
                            {lang.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-sm font-semibold text-gray-700 mb-2">Max Response Length</Label>
                    <Input 
                      type="number"
                      min="50"
                      max="500"
                      value={maxTokens}
                      onChange={(e) => setMaxTokens(parseInt(e.target.value) || 150)}
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-3">
                    Response Creativity: {(temperature * 100).toFixed(0)}%
                  </Label>
                  <Slider
                    value={[temperature]}
                    onValueChange={(value) => setTemperature(value[0])}
                    max={1}
                    min={0}
                    step={0.1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>Conservative</span>
                    <span>Balanced</span>
                    <span>Creative</span>
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-3">
                    Risk Threshold: {(riskThreshold * 100).toFixed(0)}%
                  </Label>
                  <Slider
                    value={[riskThreshold]}
                    onValueChange={(value) => setRiskThreshold(value[0])}
                    max={1}
                    min={0}
                    step={0.05}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>Cautious</span>
                    <span>Moderate</span>
                    <span>Permissive</span>
                  </div>
                </div>

                {/* Intent Detection */}
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-3">Intent Detection</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {intents.map((intent) => {
                      const IconComponent = intent.icon;
                      return (
                        <div 
                          key={intent.id}
                          className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                            selectedIntents.includes(intent.id) 
                              ? 'border-blue-500 bg-blue-50' 
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                          onClick={() => handleIntentToggle(intent.id)}
                        >
                          <div className="flex items-center gap-2">
                            <IconComponent className={`w-4 h-4 ${intent.color}`} />
                            <span className="text-sm font-medium">{intent.label}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="rules" className="space-y-6 mt-6">
                {/* Response Template */}
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-2">Response Template</Label>
                  <Textarea 
                    className="min-h-[100px] text-sm"
                    placeholder="Write your response template with variables like {name}, {username}, {platform}..."
                    value={responseTemplate}
                    onChange={(e) => setResponseTemplate(e.target.value)}
                    data-testid="textarea-response-template"
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    Use variables like {`{name}, {username}, {platform}`} for personalization
                  </p>
                </div>

                {/* Escalation Settings */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-semibold text-gray-700 mb-2">Escalate After (attempts)</Label>
                    <Input 
                      type="number"
                      min="1"
                      max="10"
                      value={escalateAfter}
                      onChange={(e) => setEscalateAfter(parseInt(e.target.value) || 3)}
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-semibold text-gray-700 mb-2">Escalate To (email)</Label>
                    <Input 
                      type="email"
                      placeholder="support@company.com"
                      value={escalateTo}
                      onChange={(e) => setEscalateTo(e.target.value)}
                    />
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-yellow-800">Smart Escalation</h4>
                      <p className="text-sm text-yellow-700 mt-1">
                        AI will automatically escalate complex issues that exceed the risk threshold or require human intervention
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="preview" className="space-y-6 mt-6">
                {/* Live Preview */}
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-2">Test Message</Label>
                  <Textarea 
                    className="min-h-[80px] text-sm"
                    placeholder="Enter a sample message to test AI response generation..."
                    value={previewText}
                    onChange={(e) => setPreviewText(e.target.value)}
                  />
                  <Button 
                    onClick={generatePreview}
                    disabled={!previewText.trim() || isGeneratingPreview || !selectedIntents.length}
                    className="mt-3"
                  >
                    {isGeneratingPreview ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate AI Response
                      </>
                    )}
                  </Button>
                </div>

                {previewResult && (
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-blue-800 mb-3 flex items-center gap-2">
                      <Bot className="w-4 h-4" />
                      AI Generated Response
                    </h4>
                    <div className="bg-white rounded p-3 mb-3">
                      <p className="text-sm text-gray-800">{previewResult.response}</p>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-blue-700">
                      <span>Confidence: {(previewResult.confidence * 100).toFixed(0)}%</span>
                      <span>Intent: {previewResult.intent}</span>
                      <span>Sentiment: {previewResult.sentiment}</span>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-6 border-t">
              <Button 
                className="flex-1"
                onClick={handleSave}
                disabled={
                  !replyName || 
                  !responseTemplate || 
                  triggerKeywords.length === 0 || 
                  selectedPlatforms.size === 0 ||
                  createMutation.isPending ||
                  updateMutation.isPending
                }
                data-testid="button-save-auto-reply"
              >
                {(createMutation.isPending || updateMutation.isPending) ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Bot className="w-4 h-4 mr-2" />
                    {editingReply ? 'Update Auto-Reply' : 'Create Auto-Reply'}
                  </>
                )}
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  setIsCreating(false);
                  resetForm();
                }}
                data-testid="button-cancel-auto-reply"
              >
                Cancel
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}