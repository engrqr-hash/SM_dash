import { useState, useMemo, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { 
  Heart, 
  MessageCircle, 
  Share, 
  Bookmark, 
  MoreHorizontal, 
  Send, 
  Play, 
  ThumbsUp, 
  Repeat2, 
  Search, 
  Settings, 
  Video, 
  Music, 
  CheckCircle,
  ExternalLink,
  Smartphone,
  Monitor,
  Plus,
  Eye,
  User,
  Camera,
  Image,
  FileText
} from "lucide-react";

interface MobilePreviewProps {
  content: string;
  platform: string;
  mediaFiles?: File[];
}

export default function MobilePreview({ content, platform, mediaFiles = [] }: MobilePreviewProps) {
  const [device, setDevice] = useState<'mobile' | 'desktop'>('mobile');
  const [selectedPlatform, setSelectedPlatform] = useState(platform || 'instagram');
  const [imageErrors, setImageErrors] = useState<Set<string>>(new Set());

  // Create object URLs for media files with proper cleanup
  const mediaUrls = useMemo(() => {
    return mediaFiles.map(file => {
      try {
        return {
          url: URL.createObjectURL(file),
          file,
          type: file.type
        };
      } catch (error) {
        console.error('Error creating object URL:', error);
        return null;
      }
    }).filter(Boolean);
  }, [mediaFiles]);

  // Cleanup object URLs when mediaFiles change or component unmounts
  useEffect(() => {
    const urls = mediaUrls.map(m => m?.url).filter((url): url is string => Boolean(url));
    return () => {
      urls.forEach(url => {
        try {
          URL.revokeObjectURL(url);
        } catch (error) {
          console.warn('Error revoking object URL:', error);
        }
      });
    };
  }, [mediaUrls]);

  // Reset image errors when media files change
  useEffect(() => {
    setImageErrors(new Set());
  }, [mediaFiles]);

  // Handle image load errors
  const handleImageError = useCallback((url: string) => {
    setImageErrors(prev => new Set(prev).add(url));
  }, []);

  // Render media with error handling
  const renderMediaWithFallback = useCallback((mediaUrl: any, className: string, alt: string, testId?: string) => {
    if (!mediaUrl || imageErrors.has(mediaUrl.url)) {
      return (
        <div className={`${className} bg-gray-100 flex items-center justify-center border-2 border-dashed border-gray-300`}>
          <div className="text-center text-gray-500">
            <Image className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-xs">Media not available</p>
          </div>
        </div>
      );
    }

    if (mediaUrl.type.startsWith('video/')) {
      return (
        <video
          src={mediaUrl.url}
          className={className}
          controls={false}
          muted
          loop
          playsInline
          data-testid={testId}
          onError={() => handleImageError(mediaUrl.url)}
        />
      );
    } else {
      return (
        <img
          src={mediaUrl.url}
          alt={alt}
          className={className}
          data-testid={testId}
          onError={() => handleImageError(mediaUrl.url)}
          onLoad={() => {
            // Remove from error set if it loads successfully
            setImageErrors(prev => {
              const newSet = new Set(prev);
              newSet.delete(mediaUrl.url);
              return newSet;
            });
          }}
        />
      );
    }
  }, [imageErrors, handleImageError]);

  // Render TikTok-style preview
  const renderTikTokPreview = () => (
    <div className="relative w-full h-full bg-black" data-testid="tiktok-preview">
      {/* Following/For You tabs */}
      <div className="absolute top-0 left-0 right-0 z-20 flex justify-center items-center h-12 bg-black/30">
        <div className="flex items-center text-white text-sm">
          <span className="px-4 py-1 text-gray-300">Following</span>
          <span className="px-4 py-1 font-semibold border-b-2 border-white">For You</span>
        </div>
      </div>

      {/* Main video area */}
      <div className="w-full h-full relative">
        {mediaUrls.length > 0 && mediaUrls[0]?.type.startsWith('video/') ? (
          renderMediaWithFallback(
            mediaUrls[0],
            "w-full h-full object-cover",
            "TikTok video",
            "tiktok-video"
          )
        ) : mediaUrls.length > 0 && mediaUrls[0]?.type.startsWith('image/') ? (
          <div className="w-full h-full relative">
            {renderMediaWithFallback(
              mediaUrls[0],
              "w-full h-full object-cover",
              "TikTok image",
              "tiktok-image"
            )}
            {/* Image overlay for static content */}
            <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
              <div className="bg-white/90 rounded-full p-3">
                <Play className="w-8 h-8 text-black" />
              </div>
            </div>
          </div>
        ) : (
          <div className="w-full h-full bg-gray-900 flex items-center justify-center">
            <div className="text-center text-white">
              <Video className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">Tap to add video</p>
            </div>
          </div>
        )}
        
        {/* Right-side action stack */}
        <div className="absolute right-3 bottom-32 space-y-6" data-testid="tiktok-right-cta">
          <div className="text-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mb-1 shadow-lg border-2 border-white">
              <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
            <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center -mt-3 mx-auto">
              <Plus className="w-4 h-4 text-white" />
            </div>
          </div>
          <div className="text-center text-white">
            <div className="w-12 h-12 bg-[#161823] rounded-full flex items-center justify-center mb-1 border border-gray-600">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium">12.3K</span>
          </div>
          <div className="text-center text-white">
            <div className="w-12 h-12 bg-[#161823] rounded-full flex items-center justify-center mb-1 border border-gray-600">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium">1,234</span>
          </div>
          <div className="text-center text-white">
            <div className="w-12 h-12 bg-[#161823] rounded-full flex items-center justify-center mb-1 border border-gray-600">
              <Share className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium">567</span>
          </div>
          <div className="text-center text-white">
            <div className="w-12 h-12 bg-[#161823] rounded-full border-4 border-white animate-spin">
              <div className="w-full h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <Music className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom content overlay */}
        <div className="absolute bottom-4 left-4 right-20 text-white">
          <div className="flex items-center gap-2 mb-2">
            <span className="font-semibold text-base">@yourbusiness</span>
          </div>
          <p className="text-sm leading-relaxed mb-2">
            {content || "Your TikTok content will appear here..."}
          </p>
          <div className="flex items-center gap-2 opacity-80">
            <Music className="w-3 h-3" />
            <span className="text-xs">Original sound - yourbusiness</span>
          </div>
        </div>
      </div>
    </div>
  );

  // Render Instagram-style feed post
  const renderInstagramPreview = () => (
    <div className="bg-white w-full" data-testid="instagram-preview">
      {/* Instagram header */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full p-0.5">
            <div className="w-full h-full bg-white rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-gray-600" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1">
              <p className="font-semibold text-sm">yourbusiness</p>
              <CheckCircle className="w-3 h-3 text-blue-500" />
            </div>
            <p className="text-xs text-gray-500">Sponsored</p>
          </div>
        </div>
        <MoreHorizontal className="w-5 h-5 text-gray-600" />
      </div>

      {/* Media content */}
      {mediaUrls.length > 0 && (
        <div className="w-full">
          {mediaUrls.length === 1 ? (
            renderMediaWithFallback(
              mediaUrls[0],
              "w-full aspect-square object-cover",
              "Instagram post",
              "instagram-image"
            )
          ) : (
            <div className="grid grid-cols-2 gap-0.5 aspect-square">
              {mediaUrls.slice(0, 4).map((mediaUrl, index) => (
                <div key={index} className="w-full h-full">
                  {renderMediaWithFallback(
                    mediaUrl,
                    "w-full h-full object-cover",
                    `Instagram post ${index + 1}`,
                    `instagram-image-${index}`
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Instagram action bar */}
      <div className="p-3" data-testid="ig-action-row">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-4">
            <Heart className="w-6 h-6 hover:text-red-500 cursor-pointer" />
            <MessageCircle className="w-6 h-6 hover:text-gray-600 cursor-pointer" />
            <Send className="w-6 h-6 hover:text-gray-600 cursor-pointer" />
          </div>
          <Bookmark className="w-6 h-6 hover:text-gray-600 cursor-pointer" />
        </div>
        
        <div className="space-y-1">
          <p className="font-semibold text-sm">2,847 likes</p>
          <div className="text-sm">
            <span className="font-semibold">yourbusiness</span>
            <span className="ml-2">{content || "Your Instagram caption will appear here..."}</span>
          </div>
          <p className="text-gray-500 text-sm">View all 24 comments</p>
          <p className="text-gray-400 text-xs uppercase">2 hours ago</p>
        </div>
      </div>
    </div>
  );

  // Render Twitter/X-style tweet
  const renderTwitterPreview = () => (
    <div className="bg-white p-4 border-b border-gray-100 w-full" data-testid="twitter-preview">
      <div className="flex gap-3">
        <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
          <User className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-1 mb-1">
            <span className="font-bold text-base">Your Business</span>
            <CheckCircle className="w-4 h-4 text-blue-500" />
            <span className="text-gray-500 text-sm">@yourbusiness</span>
            <span className="text-gray-500 text-sm">·</span>
            <span className="text-gray-500 text-sm">2h</span>
          </div>
          
          <div className="mb-3">
            <p className="text-base leading-relaxed">
              {content || "Your tweet content will appear here..."}
            </p>
          </div>

          {mediaUrls.length > 0 && (
            <div className="mb-3 rounded-2xl overflow-hidden border border-gray-200">
              {renderMediaWithFallback(
                mediaUrls[0],
                "w-full aspect-video object-cover",
                "Tweet media",
                "twitter-image"
              )}
            </div>
          )}

          <div className="flex items-center justify-between max-w-md text-gray-500">
            <div className="flex items-center gap-1 hover:text-blue-500 cursor-pointer">
              <MessageCircle className="w-4 h-4" />
              <span className="text-sm">24</span>
            </div>
            <div className="flex items-center gap-1 hover:text-green-500 cursor-pointer">
              <Repeat2 className="w-4 h-4" />
              <span className="text-sm">12</span>
            </div>
            <div className="flex items-center gap-1 hover:text-red-500 cursor-pointer">
              <Heart className="w-4 h-4" />
              <span className="text-sm">156</span>
            </div>
            <Share className="w-4 h-4 hover:text-blue-500 cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );

  // Render LinkedIn-style post
  const renderLinkedInPreview = () => (
    <div className="bg-white border border-gray-200 rounded-lg w-full" data-testid="linkedin-preview">
      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="font-semibold text-base">Your Business</p>
            <p className="text-sm text-gray-600">1,234 followers</p>
            <p className="text-xs text-gray-500">2h • Edited</p>
          </div>
        </div>
        
        <div className="mb-4">
          <p className="text-base leading-relaxed">
            {content || "Your LinkedIn post content will appear here..."}
          </p>
        </div>

        {mediaUrls.length > 0 && (
          <div className="mb-4 rounded-lg overflow-hidden">
            {renderMediaWithFallback(
              mediaUrls[0],
              "w-full aspect-video object-cover",
              "LinkedIn post",
              "linkedin-image"
            )}
          </div>
        )}
      </div>

      <div className="border-t border-gray-100 px-4 py-2">
        <div className="flex items-center justify-between text-gray-600">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <ThumbsUp className="w-5 h-5" />
              <span className="text-sm font-medium">Like</span>
            </div>
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Comment</span>
            </div>
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <Share className="w-5 h-5" />
              <span className="text-sm font-medium">Share</span>
            </div>
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <Send className="w-5 h-5" />
              <span className="text-sm font-medium">Send</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Render Facebook-style feed post
  const renderFacebookPreview = () => (
    <div className="bg-white border border-gray-200 rounded-lg w-full" data-testid="facebook-preview">
      <div className="p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-1">
              <p className="font-semibold text-base">Your Business</p>
              <CheckCircle className="w-4 h-4 text-blue-500" />
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <span>2h</span>
              <span>·</span>
              <Eye className="w-3 h-3" />
            </div>
          </div>
          <MoreHorizontal className="w-5 h-5 text-gray-600 cursor-pointer" />
        </div>
        
        <div className="mb-4">
          <p className="text-base leading-relaxed">
            {content || "Your Facebook post content will appear here..."}
          </p>
        </div>

        {mediaUrls.length > 0 && (
          <div className="mb-4 rounded-lg overflow-hidden">
            {renderMediaWithFallback(
              mediaUrls[0],
              "w-full aspect-[4/3] object-cover",
              "Facebook post",
              "facebook-image"
            )}
          </div>
        )}
      </div>

      <div className="border-t border-gray-100 px-4 py-2">
        <div className="flex items-center justify-between text-gray-600">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <ThumbsUp className="w-5 h-5" />
              <span className="text-sm font-medium">Like</span>
            </div>
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Comment</span>
            </div>
            <div className="flex items-center gap-2 hover:text-blue-600 cursor-pointer">
              <Share className="w-5 h-5" />
              <span className="text-sm font-medium">Share</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Render YouTube-style video preview
  const renderYouTubePreview = () => (
    <div className="bg-white w-full" data-testid="youtube-preview">
      {/* Video player area */}
      <div className="relative bg-black aspect-video">
        {mediaUrls.length > 0 ? (
          renderMediaWithFallback(
            mediaUrls[0],
            "w-full h-full object-cover",
            "YouTube video",
            "youtube-video"
          )
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="text-center text-white">
              <Play className="w-16 h-16 mx-auto mb-4 opacity-75" />
              <p className="text-lg">Video Preview</p>
            </div>
          </div>
        )}
        {/* Play button overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-red-600 hover:bg-red-700 rounded-full p-4 cursor-pointer">
            <Play className="w-8 h-8 text-white fill-current" />
          </div>
        </div>
      </div>

      {/* Video info */}
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2 line-clamp-2">
          {content || "Your YouTube video title will appear here..."}
        </h3>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center">
            <User className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-semibold text-sm">Your Business</p>
            <p className="text-xs text-gray-500">1.2M subscribers</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-gray-600">
          <div className="flex items-center gap-1">
            <ThumbsUp className="w-5 h-5" />
            <span className="text-sm">12K</span>
          </div>
          <div className="flex items-center gap-1">
            <Share className="w-5 h-5" />
            <span className="text-sm">Share</span>
          </div>
          <div className="flex items-center gap-1">
            <Bookmark className="w-5 h-5" />
            <span className="text-sm">Save</span>
          </div>
        </div>
      </div>
    </div>
  );

  // Render Snapchat-style story preview
  const renderSnapchatPreview = () => (
    <div className="relative w-full h-full bg-gradient-to-br from-yellow-400 to-pink-400" data-testid="snapchat-preview">
      {/* Top header */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4">
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-yellow-400" />
            </div>
            <span className="font-semibold text-sm">yourbusiness</span>
          </div>
          <div className="flex items-center gap-3">
            <MoreHorizontal className="w-5 h-5" />
          </div>
        </div>
        {/* Story progress bar */}
        <div className="mt-3 h-0.5 bg-white/30 rounded-full">
          <div className="h-full w-1/3 bg-white rounded-full"></div>
        </div>
      </div>

      {/* Main content area */}
      <div className="w-full h-full flex items-center justify-center p-8">
        {mediaUrls.length > 0 ? (
          renderMediaWithFallback(
            mediaUrls[0],
            "w-full h-full object-cover rounded-lg",
            "Snapchat story",
            "snapchat-image"
          )
        ) : (
          <div className="text-center text-white">
            <Camera className="w-16 h-16 mx-auto mb-4 opacity-75" />
            <p className="text-lg font-semibold">Tap to add photo</p>
          </div>
        )}
      </div>

      {/* Text overlay */}
      {content && (
        <div className="absolute bottom-32 left-4 right-4 text-center">
          <div className="bg-black/50 backdrop-blur-sm rounded-full px-4 py-2">
            <p className="text-white font-semibold">
              {content}
            </p>
          </div>
        </div>
      )}

      {/* Bottom action bar */}
      <div className="absolute bottom-8 left-0 right-0 px-4">
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center gap-4">
            <MessageCircle className="w-6 h-6" />
            <Send className="w-6 h-6" />
          </div>
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
            <Camera className="w-8 h-8 text-yellow-400" />
          </div>
          <div className="flex items-center gap-4">
            <Bookmark className="w-6 h-6" />
            <MoreHorizontal className="w-6 h-6" />
          </div>
        </div>
      </div>
    </div>
  );

  const renderPlatformPreview = () => {
    switch (selectedPlatform) {
      case 'tiktok':
        return renderTikTokPreview();
      case 'instagram':
        return renderInstagramPreview();
      case 'twitter':
        return renderTwitterPreview();
      case 'linkedin':
        return renderLinkedInPreview();
      case 'facebook':
        return renderFacebookPreview();
      case 'youtube':
        return renderYouTubePreview();
      case 'snapchat':
        return renderSnapchatPreview();
      default:
        return renderInstagramPreview(); // Default fallback
    }
  };

  return (
    <div className="space-y-4" data-testid="mobile-preview">
      {/* Device Toggle */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-700 flex items-center">
          <Smartphone className="w-4 h-4 mr-2 text-blue-500" />
          Preview
        </h3>
        <div className="flex bg-gray-100 rounded-lg p-1">
          <Button
            variant={device === 'mobile' ? 'default' : 'ghost'}
            size="sm"
            className="text-xs h-7"
            onClick={() => setDevice('mobile')}
            data-testid="button-mobile-view"
          >
            <Smartphone className="w-3 h-3 mr-1" />
            Mobile
          </Button>
          <Button
            variant={device === 'desktop' ? 'default' : 'ghost'}
            size="sm"
            className="text-xs h-7"
            onClick={() => setDevice('desktop')}
            data-testid="button-desktop-view"
          >
            <Monitor className="w-3 h-3 mr-1" />
            Desktop
          </Button>
        </div>
      </div>

      {/* Platform Switcher */}
      <div className="flex gap-1 overflow-x-auto">
        {[
          { id: 'instagram', icon: Image },
          { id: 'facebook', icon: User },
          { id: 'twitter', icon: MessageCircle },
          { id: 'linkedin', icon: FileText },
          { id: 'youtube', icon: Video },
          { id: 'tiktok', icon: Music },
          { id: 'snapchat', icon: Camera }
        ].map(({ id, icon: Icon }) => (
          <Button
            key={id}
            variant={selectedPlatform === id ? 'default' : 'outline'}
            size="sm"
            className="text-xs flex-shrink-0"
            onClick={() => setSelectedPlatform(id)}
            data-testid={`button-preview-${id}`}
          >
            <Icon className="w-3 h-3 mr-1" />
            {id.charAt(0).toUpperCase() + id.slice(1)}
          </Button>
        ))}
      </div>

      {/* Mobile Mockup */}
      {device === 'mobile' && (
        <div className="mx-auto" style={{ width: '280px' }}>
          <div 
            className="relative rounded-[20px] p-1.5 shadow-2xl"
            style={{ 
              background: 'linear-gradient(145deg, #1a1a1a, #2d2d2d)',
              width: '280px',
              height: selectedPlatform === 'tiktok' || selectedPlatform === 'snapchat' ? '600px' : '500px'
            }}
            data-testid="iphone-mockup"
          >
            <div className="w-full h-full bg-black rounded-[15px] overflow-hidden relative">
              {/* Status Bar */}
              <div className="absolute top-0 left-0 right-0 h-9 flex justify-between items-center px-4 pt-2 z-30">
                <span className="text-xs font-semibold text-white">9:41</span>
                <div className="flex items-center gap-1">
                  <div className="w-1 h-1 bg-white rounded-full"></div>
                  <div className="w-1 h-1 bg-white rounded-full"></div>
                  <div className="w-1 h-1 bg-white rounded-full"></div>
                  <div className="w-4 h-2 border border-white rounded-sm">
                    <div className="w-3/4 h-full bg-white rounded-sm"></div>
                  </div>
                </div>
              </div>

              {/* Platform Content */}
              <div className="absolute top-9 left-0 right-0 bottom-0 overflow-hidden">
                <div className="w-full h-full flex flex-col">
                  {renderPlatformPreview()}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Preview */}
      {device === 'desktop' && (
        <div className="border border-gray-200 rounded-lg overflow-hidden bg-white" data-testid="desktop-preview">
          <div className="p-3 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
            <span className="font-medium capitalize">{selectedPlatform} Desktop</span>
            <ExternalLink className="w-4 h-4 text-gray-500" />
          </div>
          <div className="p-4 flex justify-center">
            <div className="w-full max-w-md">
              {renderPlatformPreview()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}