import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";

interface MediaUploadProps {
  onMediaUpload: (files: File[]) => void;
  maxFiles?: number;
  acceptedTypes?: string[];
}

export default function MediaUpload({ onMediaUpload, maxFiles = 10, acceptedTypes = ['image/*', 'video/*'] }: MediaUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    
    const fileArray = Array.from(files).slice(0, maxFiles);
    setUploadedFiles(prev => [...prev, ...fileArray].slice(0, maxFiles));
    onMediaUpload(fileArray);
    console.log('Files uploaded:', fileArray.map(f => f.name));
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const removeFile = (index: number) => {
    const newFiles = uploadedFiles.filter((_, i) => i !== index);
    setUploadedFiles(newFiles);
    console.log('File removed:', uploadedFiles[index]?.name);
  };

  return (
    <div className="space-y-4" data-testid="media-upload">
      {/* Upload Zone */}
      <div
        className={`border-2 border-dashed rounded-lg p-4 text-center transition-all duration-200 ${
          isDragOver 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 bg-gray-50 hover:border-gray-400'
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        data-testid="drop-zone"
      >
        <div className="space-y-2">
          <i className="fas fa-cloud-upload-alt text-xl text-gray-400"></i>
          <div>
            <p className="text-sm font-medium text-gray-700">
              Drag & drop files here, or{" "}
              <button 
                className="text-blue-600 hover:text-blue-700 underline"
                onClick={() => fileInputRef.current?.click()}
                data-testid="button-browse-files"
              >
                browse
              </button>
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Supports images and videos • Max {maxFiles} files • Up to 10MB each
            </p>
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes.join(',')}
        className="hidden"
        onChange={(e) => handleFileSelect(e.target.files)}
        data-testid="file-input"
      />

      {/* Media Management */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-gray-700">
              Uploaded Media ({uploadedFiles.length}/{maxFiles})
            </h4>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setUploadedFiles([])}
              data-testid="button-clear-all"
            >
              <i className="fas fa-trash mr-1"></i>
              Clear All
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {uploadedFiles.map((file, index) => (
              <div 
                key={index} 
                className="relative group border border-gray-200 rounded-lg p-2 bg-white hover:shadow-sm transition-shadow"
                data-testid={`media-item-${index}`}
              >
                <div className="w-[50px] h-[50px] bg-gray-100 rounded flex items-center justify-center mb-2 flex-shrink-0">
                  {file.type.startsWith('image/') ? (
                    <i className="fas fa-image text-lg text-gray-400"></i>
                  ) : file.type.startsWith('video/') ? (
                    <i className="fas fa-video text-lg text-gray-400"></i>
                  ) : (
                    <i className="fas fa-file text-lg text-gray-400"></i>
                  )}
                </div>
                <p className="text-xs text-gray-600 truncate" title={file.name}>
                  {file.name}
                </p>
                <p className="text-xs text-gray-400">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
                
                <button
                  className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => removeFile(index)}
                  data-testid={`button-remove-${index}`}
                >
                  <i className="fas fa-times text-xs"></i>
                </button>
              </div>
            ))}
          </div>

          {/* Upload Actions */}
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              data-testid="button-add-more"
            >
              <i className="fas fa-plus mr-1"></i>
              Add More
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => console.log('Generate captions triggered')}
              data-testid="button-ai-captions"
            >
              <i className="fas fa-magic mr-1"></i>
              AI Captions
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}