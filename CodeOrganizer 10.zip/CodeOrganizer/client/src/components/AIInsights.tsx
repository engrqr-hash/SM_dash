import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface Insight {
  id: string;
  type: 'performance' | 'audience' | 'content' | 'timing' | 'trending';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  actionable: boolean;
  metrics?: {
    current: number;
    potential: number;
    improvement: string;
  };
}

export default function AIInsights() {
  const insights: Insight[] = [
    {
      id: '1',
      type: 'performance',
      title: 'Optimal Posting Schedule Detected',
      description: 'Your audience is most active between 6-8 PM on weekdays. Posts during this time get 34% more engagement.',
      impact: 'high',
      actionable: true,
      metrics: {
        current: 150,
        potential: 201,
        improvement: '+34%'
      }
    },
    {
      id: '2',
      type: 'content',
      title: 'Video Content Outperforming Images',
      description: 'Your video posts receive 2.3x more engagement than static images. Consider increasing video content ratio.',
      impact: 'high',
      actionable: true,
      metrics: {
        current: 89,
        potential: 204,
        improvement: '+129%'
      }
    },
    {
      id: '3',
      type: 'audience',
      title: 'Growing Millennial Audience',
      description: 'Your millennial follower segment grew 18% this month. They prefer educational and behind-the-scenes content.',
      impact: 'medium',
      actionable: true
    },
    {
      id: '4',
      type: 'trending',
      title: 'Trending Topic Opportunity',
      description: 'The hashtag #SustainableTech is trending in your industry. Creating content around this could boost visibility.',
      impact: 'medium',
      actionable: true
    },
    {
      id: '5',
      type: 'timing',
      title: 'Weekend Engagement Drop',
      description: 'Weekend posts get 45% less engagement. Consider focusing your content schedule on weekdays.',
      impact: 'medium',
      actionable: true,
      metrics: {
        current: 120,
        potential: 218,
        improvement: '+82%'
      }
    }
  ];

  const getInsightIcon = (type: string) => {
    const icons = {
      performance: 'fas fa-chart-line text-green-500',
      audience: 'fas fa-users text-blue-500',
      content: 'fas fa-file-alt text-purple-500',
      timing: 'fas fa-clock text-orange-500',
      trending: 'fas fa-fire text-red-500'
    };
    return icons[type as keyof typeof icons] || 'fas fa-lightbulb text-yellow-500';
  };

  const getImpactColor = (impact: string) => {
    const colors = {
      high: 'bg-red-100 text-red-700 border-red-200',
      medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      low: 'bg-green-100 text-green-700 border-green-200'
    };
    return colors[impact as keyof typeof colors];
  };

  const highImpactInsights = insights.filter(insight => insight.impact === 'high');
  const totalInsights = insights.length;
  const actionableInsights = insights.filter(insight => insight.actionable).length;

  return (
    <div className="space-y-6" data-testid="ai-insights">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center">
            <i className="fas fa-brain mr-2 text-blue-500"></i>
            AI Insights
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Data-driven recommendations to boost your social media performance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="bg-blue-100 text-blue-700">
            <i className="fas fa-lightbulb mr-1"></i>
            {actionableInsights} actionable
          </Badge>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => console.log('Generate new insights')}
            data-testid="button-refresh-insights"
          >
            <i className="fas fa-sync mr-1"></i>
            Refresh
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-800">{totalInsights}</p>
              <p className="text-xs text-gray-600">Total Insights</p>
            </div>
            <i className="fas fa-brain text-blue-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-red-600">{highImpactInsights.length}</p>
              <p className="text-xs text-gray-600">High Impact</p>
            </div>
            <i className="fas fa-exclamation-triangle text-red-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-green-600">+47%</p>
              <p className="text-xs text-gray-600">Avg. Improvement</p>
            </div>
            <i className="fas fa-arrow-up text-green-500 text-xl"></i>
          </div>
        </Card>
      </div>

      {/* Insights List */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <i className="fas fa-list mr-2 text-gray-500"></i>
          Recommendations
        </h3>
        
        <div className="space-y-3">
          {insights.map((insight) => (
            <Card key={insight.id} className="hover-elevate cursor-pointer" data-testid={`insight-${insight.id}`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="mt-1">
                    <i className={getInsightIcon(insight.type)}></i>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <h4 className="text-sm font-semibold text-gray-800">
                        {insight.title}
                      </h4>
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline" 
                          className={`text-xs px-2 py-0 h-5 ${getImpactColor(insight.impact)}`}
                        >
                          {insight.impact} impact
                        </Badge>
                        {insight.actionable && (
                          <Badge variant="secondary" className="text-xs px-2 py-0 h-5">
                            <i className="fas fa-bolt mr-1"></i>
                            Actionable
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">
                      {insight.description}
                    </p>
                    
                    {insight.metrics && (
                      <div className="bg-gray-50 rounded-lg p-3 mb-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs text-gray-600">Potential Improvement</span>
                          <span className="text-xs font-semibold text-green-600">
                            {insight.metrics.improvement}
                          </span>
                        </div>
                        <Progress 
                          value={(insight.metrics.potential / (insight.metrics.potential + 50)) * 100} 
                          className="h-2 mb-2"
                        />
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Current: {insight.metrics.current}</span>
                          <span>Potential: {insight.metrics.potential}</span>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-xs h-7"
                        onClick={() => console.log(`Apply insight: ${insight.id}`)}
                        data-testid={`button-apply-${insight.id}`}
                      >
                        <i className="fas fa-check mr-1"></i>
                        Apply
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs h-7"
                        onClick={() => console.log(`Dismiss insight: ${insight.id}`)}
                        data-testid={`button-dismiss-${insight.id}`}
                      >
                        <i className="fas fa-times mr-1"></i>
                        Dismiss
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs h-7"
                        onClick={() => console.log(`Learn more: ${insight.id}`)}
                        data-testid={`button-learn-more-${insight.id}`}
                      >
                        <i className="fas fa-info-circle mr-1"></i>
                        Learn More
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* AI Learning Status */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500 rounded-lg">
              <i className="fas fa-robot text-white"></i>
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-800 mb-1">
                AI Learning Progress
              </h4>
              <p className="text-xs text-gray-600 mb-2">
                AI is analyzing your content patterns and audience behavior to provide better insights.
              </p>
              <Progress value={73} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">73% complete • Next update in 2 days</p>
            </div>
            <Button variant="outline" size="sm" className="text-xs">
              <i className="fas fa-cog mr-1"></i>
              Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}