import { useState } from "react";
import PlatformToggle from '../PlatformToggle';

export default function PlatformToggleExample() {
  const platforms = [
    { id: 'facebook', name: 'Facebook', icon: 'fab fa-facebook-f', color: '#1877f2' },
    { id: 'instagram', name: 'Instagram', icon: 'fab fa-instagram', color: '#E4405F' },
    { id: 'twitter', name: 'X (Twitter)', icon: 'fab fa-x-twitter', color: '#000000' },
    { id: 'linkedin', name: 'LinkedIn', icon: 'fab fa-linkedin-in', color: '#0077b5' },
    { id: 'tiktok', name: 'TikTok', icon: 'fab fa-tiktok', color: '#000000' },
    { id: 'youtube', name: 'YouTube', icon: 'fab fa-youtube', color: '#ff0000' },
  ];

  //todo: remove mock functionality
  const [activePlatforms, setActivePlatforms] = useState(new Set(['instagram', 'facebook', 'twitter']));

  const handleToggle = (platformId: string) => {
    const newActive = new Set(activePlatforms);
    if (newActive.has(platformId)) {
      newActive.delete(platformId);
    } else {
      newActive.add(platformId);
    }
    setActivePlatforms(newActive);
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-semibold">Platform Selection</h2>
      <p className="text-gray-600 text-sm">
        Active platforms: {Array.from(activePlatforms).join(', ') || 'None'}
      </p>
      <PlatformToggle 
        platforms={platforms}
        activePlatforms={activePlatforms}
        onToggle={handleToggle}
      />
    </div>
  );
}