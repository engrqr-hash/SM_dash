import { useState } from "react";
import MobilePreview from '../MobilePreview';
import { Textarea } from "@/components/ui/textarea";

export default function MobilePreviewExample() {
  //todo: remove mock functionality
  const [content, setContent] = useState("Check out our amazing new product! 🚀 It's going to revolutionize the way you work. #innovation #productivity #newproduct");
  const [platform, setPlatform] = useState("instagram");

  return (
    <div className="p-4 grid md:grid-cols-2 gap-6">
      <div className="space-y-4">
        <h2 className="text-lg font-semibold">Content Editor</h2>
        <Textarea 
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Enter your post content..."
          className="min-h-[100px]"
          data-testid="content-editor"
        />
        <div className="flex gap-2">
          {['instagram', 'facebook', 'twitter', 'linkedin'].map((p) => (
            <button
              key={p}
              className={`px-3 py-1 text-xs rounded border ${
                platform === p 
                  ? 'bg-blue-500 text-white border-blue-500' 
                  : 'bg-white text-gray-600 border-gray-300 hover:border-gray-400'
              }`}
              onClick={() => setPlatform(p)}
              data-testid={`button-platform-${p}`}
            >
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>
      </div>
      
      <div>
        <MobilePreview 
          content={content}
          platform={platform}
          mediaFiles={[]}
        />
      </div>
    </div>
  );
}