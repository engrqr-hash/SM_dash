import PostComposer from '../PostComposer';

export default function PostComposerExample() {
  const handlePost = (data: any) => {
    console.log('Post data received:', data);
    alert('Post created successfully! Check console for details.');
  };

  return (
    <div className="p-4 max-w-2xl">
      <PostComposer onPost={handlePost} />
    </div>
  );
}