import { useState } from "react";
import Toast, { useToast } from '../Toast';
import { Button } from "@/components/ui/button";

export default function ToastExample() {
  const { toast, showToast, hideToast } = useToast();

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-lg font-semibold">Toast Notifications</h2>
      
      <div className="flex gap-2 flex-wrap">
        <Button 
          onClick={() => showToast('Success! Your post has been published.', 'success')}
          data-testid="button-success-toast"
        >
          Show Success Toast
        </Button>
        
        <Button 
          onClick={() => showToast('Error: Failed to upload media file.', 'error')}
          variant="destructive"
          data-testid="button-error-toast"
        >
          Show Error Toast
        </Button>
        
        <Button 
          onClick={() => showToast('Warning: API rate limit approaching.', 'warning')}
          variant="secondary"
          data-testid="button-warning-toast"
        >
          Show Warning Toast
        </Button>
      </div>

      <Toast 
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </div>
  );
}