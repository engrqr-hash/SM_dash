import { useState } from "react";
import Sidebar from '../Sidebar';

export default function SidebarExample() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [currentView, setCurrentView] = useState('composer');

  return (
    <div className="relative h-screen">
      <Sidebar 
        isExpanded={isExpanded}
        onToggle={() => setIsExpanded(!isExpanded)}
        currentView={currentView}
        onViewChange={setCurrentView}
      />
      <div className={`transition-all duration-300 ${isExpanded ? 'ml-64' : 'ml-[100px]'} p-4`}>
        <div className="bg-gray-50 rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-2">Current View: {currentView}</h2>
          <p className="text-gray-600">
            Sidebar is {isExpanded ? 'expanded' : 'collapsed'}. 
            Click the menu button to toggle or try other navigation items.
          </p>
        </div>
      </div>
    </div>
  );
}