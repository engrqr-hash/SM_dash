import { useState } from "react";
import HashtagGenerator from '../HashtagGenerator';

export default function HashtagGeneratorExample() {
  const [selectedHashtags, setSelectedHashtags] = useState<string[]>([]);

  const handleHashtagAdd = (hashtag: string) => {
    if (!selectedHashtags.includes(hashtag)) {
      setSelectedHashtags(prev => [...prev, hashtag]);
    }
  };

  return (
    <div className="p-4 max-w-md space-y-4">
      <HashtagGenerator onHashtagAdd={handleHashtagAdd} />
      
      {selectedHashtags.length > 0 && (
        <div className="p-3 bg-gray-50 rounded-lg">
          <h3 className="text-sm font-semibold mb-2">Selected Hashtags:</h3>
          <p className="text-sm text-gray-700">
            {selectedHashtags.join(' ')}
          </p>
          <button 
            className="text-xs text-blue-600 hover:text-blue-700 mt-2"
            onClick={() => setSelectedHashtags([])}
          >
            Clear all
          </button>
        </div>
      )}
    </div>
  );
}