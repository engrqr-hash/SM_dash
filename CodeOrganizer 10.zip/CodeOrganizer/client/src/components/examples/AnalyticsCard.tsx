import AnalyticsCard from '../AnalyticsCard';

export default function AnalyticsCardExample() {
  //todo: remove mock functionality
  const mockData = [
    {
      title: "Total Reach",
      value: "12.5K",
      change: "+24%",
      changeType: "positive" as const,
      icon: "fas fa-eye"
    },
    {
      title: "Engagement",
      value: "89%",
      change: "+12%", 
      changeType: "positive" as const,
      icon: "fas fa-heart"
    },
    {
      title: "Comments",
      value: 156,
      change: "-3%",
      changeType: "negative" as const,
      icon: "fas fa-comment"
    },
    {
      title: "Shares",
      value: 34,
      change: "+18%",
      changeType: "positive" as const,
      icon: "fas fa-share"
    }
  ];

  return (
    <div className="p-4 max-w-md">
      <AnalyticsCard data={mockData} showChart={true} />
    </div>
  );
}