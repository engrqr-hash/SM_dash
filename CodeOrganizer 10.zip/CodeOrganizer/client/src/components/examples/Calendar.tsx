import Calendar from '../Calendar';

export default function CalendarExample() {
  const handleDateClick = (date: number) => {
    console.log(`Calendar date clicked: ${date}`);
  };

  return (
    <div className="p-4 max-w-md">
      <Calendar onDateClick={handleDateClick} />
    </div>
  );
}