import MediaUpload from '../MediaUpload';

export default function MediaUploadExample() {
  const handleMediaUpload = (files: File[]) => {
    console.log('Media files uploaded:', files);
  };

  return (
    <div className="p-4 max-w-2xl">
      <h2 className="text-lg font-semibold mb-4">Media Upload</h2>
      <MediaUpload onMediaUpload={handleMediaUpload} />
    </div>
  );
}