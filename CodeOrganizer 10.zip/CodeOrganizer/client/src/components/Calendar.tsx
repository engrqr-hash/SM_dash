import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, ExternalLink, Instagram, Facebook, Twitter, Linkedin } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Post } from '@shared/schema';

interface CalendarEvent {
  date: number;
  type: 'instagram' | 'facebook' | 'twitter' | 'linkedin';
  title: string;
}

interface CalendarProps {
  events?: CalendarEvent[];
  onDateClick?: (date: number) => void;
  onViewChange?: (view: string) => void;
}

export default function Calendar({ events = [], onDateClick, onViewChange }: CalendarProps) {
  const [currentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  const today = currentDate.getDate();
  
  // Get first day of month and number of days
  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const platformIcons = {
    instagram: Instagram,
    facebook: Facebook,
    twitter: Twitter,
    linkedin: Linkedin
  };

  const platformColors = {
    instagram: 'text-pink-500',
    facebook: 'text-blue-500', 
    twitter: 'text-gray-800',
    linkedin: 'text-blue-600'
  };

  // Fetch posts from API
  const { data: posts = [] } = useQuery({
    queryKey: ['/api/posts'],
    queryFn: async () => {
      const response = await fetch('/api/posts');
      if (!response.ok) {
        throw new Error('Failed to fetch posts');
      }
      return response.json();
    }
  });

  // Convert posts to calendar events for the current month
  const scheduledEvents: CalendarEvent[] = posts
    .filter(post => {
      if (!post.scheduledTime || post.status !== 'scheduled') return false;
      const scheduledDate = new Date(post.scheduledTime);
      return scheduledDate.getMonth() === currentMonth && scheduledDate.getFullYear() === currentYear;
    })
    .map(post => {
      const scheduledDate = new Date(post.scheduledTime!);
      const platforms = Array.isArray(post.platforms) ? post.platforms : [post.platforms];
      return {
        date: scheduledDate.getDate(),
        type: platforms[0] as 'instagram' | 'facebook' | 'twitter' | 'linkedin',
        title: post.content.substring(0, 50) + (post.content.length > 50 ? '...' : '')
      };
    });

  const allEvents = [...events, ...scheduledEvents];

  const getEventsForDate = (date: number) => {
    return allEvents.filter(event => event.date === date);
  };

  return (
    <Card className="w-full" data-testid="calendar">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-gray-800 flex items-center justify-between">
          <div className="flex items-center">
            <CalendarIcon className="h-4 w-4 mr-2 text-blue-500" />
            Content Calendar
          </div>
          <span className="text-xs text-gray-500 font-normal">
            {monthNames[currentMonth]} {currentYear}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {/* Calendar Grid */}
        <div className="space-y-1">
          {/* Day Headers */}
          <div className="grid grid-cols-7 gap-1">
            {dayNames.map(day => (
              <div key={day} className="text-center text-xs font-medium text-gray-500 py-1 h-6 flex items-center justify-center">
                {day.slice(0, 3)}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 gap-1" data-testid="calendar-grid">
            {/* Empty cells for days before month starts */}
            {Array.from({ length: firstDay }).map((_, index) => (
              <div key={`empty-${index}`} className="aspect-square h-12 min-h-[44px] [@media(pointer:coarse)]:h-11"></div>
            ))}
            
            {/* Month days */}
            {Array.from({ length: daysInMonth }).map((_, index) => {
              const date = index + 1;
              const dayEvents = getEventsForDate(date);
              const isToday = date === today;
              const isSelected = date === selectedDate;
              
              return (
                <button
                  key={date}
                  className={`aspect-square h-12 min-h-[44px] [@media(pointer:coarse)]:h-11 text-xs border border-gray-100 rounded transition-all hover-elevate ${
                    isToday ? 'bg-blue-500 text-white font-semibold' :
                    isSelected ? 'bg-blue-100 border-blue-300' :
                    dayEvents.length > 0 ? 'bg-blue-50 border-blue-200 text-blue-700 font-medium' :
                    'text-gray-700'
                  }`}
                  onClick={() => {
                    setSelectedDate(date);
                    onDateClick?.(date);
                    console.log(`Date ${date} clicked`);
                  }}
                  data-testid={`calendar-day-${date}`}
                  aria-label={`Day ${date} ${dayEvents.length > 0 ? `with ${dayEvents.length} event${dayEvents.length > 1 ? 's' : ''}` : ''}`}
                >
                  <div className="flex flex-col items-center justify-center h-full">
                    <span className="leading-none">{date}</span>
                    {dayEvents.length > 0 && (
                      <div className="flex gap-0.5 mt-0.5 flex-wrap justify-center items-center">
                        {dayEvents.slice(0, 3).map((event, eventIndex) => {
                          const IconComponent = platformIcons[event.type];
                          return (
                            <IconComponent
                              key={eventIndex}
                              className={`h-2.5 w-2.5 ${platformColors[event.type]}`}
                            />
                          );
                        })}
                        {dayEvents.length > 3 && (
                          <div className="text-xs leading-none font-bold text-gray-600" title={`+${dayEvents.length - 3} more events`}>+{dayEvents.length - 3}</div>
                        )}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Date Events */}
        {selectedDate && getEventsForDate(selectedDate).length > 0 && (
          <div className="bg-gray-50 rounded p-2" data-testid="selected-date-events">
            <h4 className="text-xs font-semibold text-gray-700 mb-1">
              {monthNames[currentMonth]} {selectedDate}
            </h4>
            <div className="space-y-1">
              {getEventsForDate(selectedDate).map((event, index) => {
                const IconComponent = platformIcons[event.type];
                return (
                  <div key={index} className="flex items-center gap-1 text-xs">
                    <IconComponent className={`h-3 w-3 ${platformColors[event.type]}`} />
                    <span className="text-gray-600 capitalize">{event.type}:</span>
                    <span className="text-gray-800 truncate">{event.title}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Legend */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5">
              <Instagram className="h-3 w-3 text-pink-500" />
              <span className="text-gray-600 text-xs">IG</span>
            </div>
            <div className="flex items-center gap-0.5">
              <Facebook className="h-3 w-3 text-blue-500" />
              <span className="text-gray-600 text-xs">FB</span>
            </div>
            <div className="flex items-center gap-0.5">
              <Twitter className="h-3 w-3 text-gray-800" />
              <span className="text-gray-600 text-xs">X</span>
            </div>
            <div className="flex items-center gap-0.5">
              <Linkedin className="h-3 w-3 text-blue-600" />
              <span className="text-gray-600 text-xs">LI</span>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            className="text-xs"
            onClick={() => {
              console.log('Full calendar triggered');
              onViewChange?.('calendar');
            }}
            data-testid="button-full-calendar"
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            Full View
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}