import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  CheckCircle, 
  XCircle, 
  Send, 
  Edit, 
  Clock, 
  AlertTriangle,
  MessageCircle,
  Heart,
  Brain,
  Filter,
  RefreshCw,
  Trash2,
  Eye
} from 'lucide-react';
import type { GeneratedReply } from '@shared/schema';

interface ApprovalQueueProps {
  onViewChange?: (view: string) => void;
}

export default function ApprovalQueue({ onViewChange }: ApprovalQueueProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [editingReply, setEditingReply] = useState<GeneratedReply | null>(null);
  const [editedContent, setEditedContent] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [platformFilter, setPlatformFilter] = useState<string>('all');

  // Fetch generated replies
  const { data: replies = [], isLoading } = useQuery({
    queryKey: ['/api/generated-replies', { status: statusFilter, priority: priorityFilter, platform: platformFilter }],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/generated-replies?status=${statusFilter}&priority=${priorityFilter}&platform=${platformFilter}`);
      return res.json();
    }
  });

  // Bulk operations mutation
  const bulkOperationMutation = useMutation({
    mutationFn: async (data: { action: 'approve' | 'reject' | 'send'; ids: string[] }) => {
      const res = await apiRequest('POST', '/api/generated-replies/bulk', data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/generated-replies'] });
      setSelectedItems([]);
      toast({ 
        title: 'Success', 
        description: `${data?.processed || 0} replies processed successfully`, 
        variant: 'default' 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to process bulk operation', 
        variant: 'destructive' 
      });
    }
  });

  // Individual reply operations
  const replyOperationMutation = useMutation({
    mutationFn: async (data: { id: string; action: 'approve' | 'reject' | 'send'; content?: string }) => {
      const updateData = { 
        status: data.action === 'approve' ? 'approved' : data.action === 'reject' ? 'rejected' : 'sent',
        ...(data.content && { finalText: data.content })
      };
      const res = await apiRequest('PUT', `/api/generated-replies/${data.id}`, updateData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/generated-replies'] });
      setEditingReply(null);
      toast({ 
        title: 'Success', 
        description: 'Reply updated successfully', 
        variant: 'default' 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to update reply', 
        variant: 'destructive' 
      });
    }
  });

  const handleBulkOperation = (action: 'approve' | 'reject' | 'send') => {
    if (selectedItems.length === 0) return;
    bulkOperationMutation.mutate({ action, ids: selectedItems });
  };

  const handleIndividualOperation = (reply: GeneratedReply, action: 'approve' | 'reject' | 'send') => {
    replyOperationMutation.mutate({ id: reply.id, action });
  };

  const handleEdit = (reply: any) => {
    setEditingReply(reply);
    setEditedContent(reply.finalText || reply.draftText || '');
  };

  const handleSaveEdit = () => {
    if (!editingReply) return;
    replyOperationMutation.mutate({ 
      id: editingReply.id, 
      action: 'approve', 
      content: editedContent 
    });
  };

  const toggleSelectItem = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const selectAll = () => {
    const pendingReplies = replies.filter((reply: any) => reply.status === 'draft');
    setSelectedItems(pendingReplies.map((reply: any) => reply.id));
  };

  const clearSelection = () => setSelectedItems([]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'rejected': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'sent': return <Send className="w-4 h-4 text-blue-500" />;
      default: return <Clock className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    const variants = {
      high: 'destructive' as const,
      medium: 'secondary' as const,
      low: 'outline' as const
    };
    return <Badge variant={variants[priority as keyof typeof variants] || 'outline'}>{priority}</Badge>;
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-600';
    if (confidence >= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const pendingReplies = replies.filter((reply: any) => reply.status === 'draft');
  const processedReplies = replies.filter((reply: any) => reply.status !== 'draft');

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-gray-400" />
        <span className="ml-2 text-gray-600">Loading approval queue...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="approval-queue">
      {/* Header with Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Approval</p>
                <p className="text-2xl font-bold text-yellow-600" data-testid="pending-count">
                  {pendingReplies.length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Approved</p>
                <p className="text-2xl font-bold text-green-600" data-testid="approved-count">
                  {replies.filter((r: any) => r.status === 'approved').length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Sent</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="sent-count">
                  {replies.filter((r: any) => r.status === 'sent').length}
                </p>
              </div>
              <Send className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">High Priority</p>
                <p className="text-2xl font-bold text-red-600" data-testid="high-priority-count">
                  {replies.filter((r: any) => (r.scores as any)?.risk_score > 0.7).length}
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Bulk Actions */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium">Filters:</span>
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32" data-testid="filter-status">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                </SelectContent>
              </Select>

              <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                <SelectTrigger className="w-32" data-testid="filter-priority">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>

              <Select value={platformFilter} onValueChange={setPlatformFilter}>
                <SelectTrigger className="w-32" data-testid="filter-platform">
                  <SelectValue placeholder="Platform" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Platforms</SelectItem>
                  <SelectItem value="facebook">Facebook</SelectItem>
                  <SelectItem value="instagram">Instagram</SelectItem>
                  <SelectItem value="twitter">Twitter</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              {selectedItems.length > 0 && (
                <>
                  <Badge variant="secondary" data-testid="selected-count">
                    {selectedItems.length} selected
                  </Badge>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={clearSelection}
                    data-testid="button-clear-selection"
                  >
                    Clear
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleBulkOperation('approve')}
                    disabled={bulkOperationMutation.isPending}
                    data-testid="button-bulk-approve"
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Approve All
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleBulkOperation('reject')}
                    disabled={bulkOperationMutation.isPending}
                    data-testid="button-bulk-reject"
                  >
                    <XCircle className="w-4 h-4 mr-1" />
                    Reject All
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleBulkOperation('send')}
                    disabled={bulkOperationMutation.isPending}
                    data-testid="button-bulk-send"
                  >
                    <Send className="w-4 h-4 mr-1" />
                    Send All
                  </Button>
                </>
              )}
              {pendingReplies.length > 0 && selectedItems.length === 0 && (
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={selectAll}
                  data-testid="button-select-all"
                >
                  Select All Pending
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Approval Queue Tabs */}
      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pending" data-testid="tab-pending">
            Pending Approval ({pendingReplies.length})
          </TabsTrigger>
          <TabsTrigger value="processed" data-testid="tab-processed">
            Processed ({processedReplies.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          {pendingReplies.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">All caught up!</h3>
                <p className="text-gray-500">No replies pending approval at the moment.</p>
                {onViewChange && (
                  <Button 
                    className="mt-4" 
                    onClick={() => onViewChange('auto-replies')}
                    data-testid="button-configure-auto-replies"
                  >
                    Configure Auto Replies
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            pendingReplies.map((reply: GeneratedReply) => (
              <Card key={reply.id} className="hover-elevate" data-testid={`reply-card-${reply.id}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={selectedItems.includes(reply.id)}
                        onCheckedChange={() => toggleSelectItem(reply.id)}
                        data-testid={`checkbox-select-${reply.id}`}
                      />
                      <div className="flex items-center gap-2">
                        {getStatusIcon(reply.status)}
                        <span className="font-medium">Reply</span>
                        {getPriorityBadge(((reply.scores as any)?.risk_score || 0) > 0.7 ? 'high' : ((reply.scores as any)?.risk_score || 0) > 0.3 ? 'medium' : 'low')}
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {reply.createdAt && new Date(reply.createdAt).toLocaleString()}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Original Message Context */}
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <MessageCircle className="w-4 h-4 text-gray-500" />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        Original Message
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400" data-testid={`original-message-${reply.id}`}>
                      {(reply.modelInfo as any)?.originalMessage as string || 'No original message available'}
                    </p>
                  </div>

                  {/* Generated Reply */}
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Brain className="w-4 h-4 text-blue-500" />
                        <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                          Generated Reply
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-medium ${getConfidenceColor((reply.scores as any)?.confidence || 0)}`}>
                          {Math.round(((reply.scores as any)?.confidence || 0) * 100)}% confidence
                        </span>
                        {(reply.modelInfo as any)?.sentiment && (
                          <Badge variant="outline" className="text-xs">
                            {(reply.modelInfo as any)?.sentiment}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300" data-testid={`generated-reply-${reply.id}`}>
                      {reply.finalText || reply.draftText || 'No content available'}
                    </p>
                  </div>

                  {/* Metadata */}
                  {reply.modelInfo && (
                    <div className="grid grid-cols-2 gap-4 text-xs text-gray-500">
                      <div>
                        <span className="font-medium">Model:</span> {(reply.modelInfo as any).model || 'N/A'}
                      </div>
                      <div>
                        <span className="font-medium">Temperature:</span> {(reply.modelInfo as any).temperature || 'N/A'}
                      </div>
                      <div>
                        <span className="font-medium">Tokens:</span> {(reply.modelInfo as any).tokens_used || 'N/A'}
                      </div>
                      <div>
                        <span className="font-medium">Processing Time:</span> {(reply.modelInfo as any).processing_time || 'N/A'}ms
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-3 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleIndividualOperation(reply, 'approve')}
                        disabled={replyOperationMutation.isPending}
                        data-testid={`button-approve-${reply.id}`}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(reply)}
                        data-testid={`button-edit-${reply.id}`}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleIndividualOperation(reply, 'send')}
                        disabled={replyOperationMutation.isPending}
                        data-testid={`button-send-${reply.id}`}
                      >
                        <Send className="w-4 h-4 mr-1" />
                        Send Now
                      </Button>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleIndividualOperation(reply, 'reject')}
                      disabled={replyOperationMutation.isPending}
                      data-testid={`button-reject-${reply.id}`}
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Reject
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="processed" className="space-y-4">
          {processedReplies.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Eye className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No processed replies</h3>
                <p className="text-gray-500">Approved, rejected, and sent replies will appear here.</p>
              </CardContent>
            </Card>
          ) : (
            processedReplies.map((reply: GeneratedReply) => (
              <Card key={reply.id} className="opacity-75" data-testid={`processed-card-${reply.id}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(reply.status)}
                        <span className="font-medium">Reply</span>
                        {getPriorityBadge(((reply.scores as any)?.risk_score || 0) > 0.7 ? 'high' : ((reply.scores as any)?.risk_score || 0) > 0.3 ? 'medium' : 'low')}
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      {reply.updatedAt && new Date(reply.updatedAt).toLocaleString()}
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600 dark:text-gray-400" data-testid={`processed-content-${reply.id}`}>
                      {reply.finalText || reply.draftText || 'No content available'}
                    </p>
                    {(reply.scores as any)?.confidence && (
                      <div className="text-xs text-gray-500">
                        Confidence: {Math.round(((reply.scores as any).confidence * 100))}%
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={!!editingReply} onOpenChange={() => setEditingReply(null)}>
        <DialogContent className="sm:max-w-md" data-testid="edit-reply-dialog">
          <DialogHeader>
            <DialogTitle>Edit Reply</DialogTitle>
            <DialogDescription>
              Modify the generated reply before approving and sending.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <Textarea
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              placeholder="Enter your reply..."
              className="min-h-24"
              data-testid="textarea-edit-content"
            />
            <div className="text-xs text-gray-500">
              {editedContent.length} characters
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setEditingReply(null)}
              data-testid="button-cancel-edit"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSaveEdit}
              disabled={replyOperationMutation.isPending}
              data-testid="button-save-edit"
            >
              Save & Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}