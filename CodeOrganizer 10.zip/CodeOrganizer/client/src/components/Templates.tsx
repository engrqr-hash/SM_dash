import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Copy,
  Eye,
  BarChart3,
  Hash,
  Tag,
  TestTube,
  Star,
  TrendingUp,
  MessageSquare,
  Settings,
  Search,
  Filter,
  RefreshCw,
  CheckCircle,
  XCircle,
  Trophy,
  Target,
  Zap,
  Users,
  Activity,
  Clock,
  Play,
  Pause,
  Square,
  GitBranch,
  AlertTriangle
} from 'lucide-react';
import type { Template, InsertTemplate } from '@shared/schema';

interface TemplatesProps {
  onViewChange?: (view: string) => void;
}

const TEMPLATE_INTENTS = [
  'support',
  'compliment',
  'greeting',
  'sales',
  'marketing',
  'follow_up',
  'general'
];

const COMMON_VARIABLES = [
  '{customerName}',
  '{companyName}',
  '{productName}',
  '{orderId}',
  '{supportTicket}',
  '{firstName}',
  '{lastName}',
  '{email}',
  '{date}',
  '{time}',
  '{platform}',
  '{issue}',
  '{resolution}'
];

export default function Templates({ onViewChange }: TemplatesProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State for template management
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Template | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<Template | null>(null);

  // A/B Testing state
  const [isExperimentDialogOpen, setIsExperimentDialogOpen] = useState(false);
  const [isVariantDialogOpen, setIsVariantDialogOpen] = useState(false);
  const [isResultsDialogOpen, setIsResultsDialogOpen] = useState(false);
  const [selectedExperiment, setSelectedExperiment] = useState<Template | null>(null);
  const [selectedExperimentId, setSelectedExperimentId] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'templates' | 'experiments'>('templates');
  
  // Form state
  const [formData, setFormData] = useState<Partial<InsertTemplate>>({
    name: '',
    text: '',
    intent: 'general',
    variables: [],
    tags: [],
    isDefault: false,
    usageCount: 0,
    rating: 0
  });
  
  // Filters and search
  const [searchQuery, setSearchQuery] = useState('');
  const [intentFilter, setIntentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('name');

  // Preview variables
  const [previewVariables, setPreviewVariables] = useState<Record<string, string>>({});

  // Fetch templates
  const { data: templates = [], isLoading } = useQuery<Template[]>({
    queryKey: ['/api/templates', { intent: intentFilter, status: statusFilter, sort: sortBy }],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/templates?intent=${intentFilter}&status=${statusFilter}&sort=${sortBy}`);
      return res.json();
    }
  });

  // Fetch active experiments
  const { data: experiments = [], isLoading: experimentsLoading } = useQuery<Template[]>({
    queryKey: ['/api/experiments'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/experiments');
      return res.json();
    }
  });

  // Fetch experiment results
  const { data: experimentResults, isLoading: resultsLoading } = useQuery({
    queryKey: ['/api/experiments', selectedExperimentId, 'results'],
    queryFn: async () => {
      if (!selectedExperimentId) return null;
      const res = await apiRequest('GET', `/api/experiments/${selectedExperimentId}/results`);
      return res.json();
    },
    enabled: !!selectedExperimentId
  });

  // Template mutations
  const createMutation = useMutation({
    mutationFn: async (data: InsertTemplate) => {
      const res = await apiRequest('POST', '/api/templates', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      setIsCreateDialogOpen(false);
      resetForm();
      toast({ 
        title: 'Success', 
        description: 'Template created successfully', 
        variant: 'default' 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to create template', 
        variant: 'destructive' 
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string, data: Partial<InsertTemplate> }) => {
      const res = await apiRequest('PUT', `/api/templates/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      setIsEditDialogOpen(false);
      setEditingTemplate(null);
      resetForm();
      toast({ 
        title: 'Success', 
        description: 'Template updated successfully', 
        variant: 'default' 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to update template', 
        variant: 'destructive' 
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest('DELETE', `/api/templates/${id}`);
      return res.ok;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      toast({ 
        title: 'Success', 
        description: 'Template deleted successfully', 
        variant: 'default' 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to delete template', 
        variant: 'destructive' 
      });
    }
  });

  const duplicateMutation = useMutation({
    mutationFn: async (template: Template) => {
      const duplicateData: InsertTemplate = {
        name: `${template.name} (Copy)`,
        text: template.text,
        intent: template.intent,
        variables: template.variables as string[],
        tags: template.tags as string[],
        isDefault: false,
        usageCount: 0,
        rating: 0,
        conversionCount: template.conversionCount || 0,
        impressionCount: template.impressionCount || 0
      };
      const res = await apiRequest('POST', '/api/templates', duplicateData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      toast({ 
        title: 'Success', 
        description: 'Template duplicated successfully', 
        variant: 'default' 
      });
    }
  });

  // A/B Testing mutations
  const createVariantMutation = useMutation({
    mutationFn: async ({ templateId, variantData }: { templateId: string, variantData: { name: string, text: string, variantType: string } }) => {
      const res = await apiRequest('POST', `/api/templates/${templateId}/variants`, variantData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/experiments'] });
      setIsVariantDialogOpen(false);
      setSelectedExperiment(null);
      toast({ 
        title: 'Success', 
        description: 'Variant created successfully', 
        variant: 'default' 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to create variant', 
        variant: 'destructive' 
      });
    }
  });

  const updateMetricsMutation = useMutation({
    mutationFn: async ({ templateId, impressions, conversions }: { templateId: string, impressions: number, conversions: number }) => {
      const res = await apiRequest('PATCH', `/api/templates/${templateId}/metrics`, { impressions, conversions });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      queryClient.invalidateQueries({ queryKey: ['/api/experiments'] });
      if (selectedExperimentId) {
        queryClient.invalidateQueries({ queryKey: ['/api/experiments', selectedExperimentId, 'results'] });
      }
    }
  });

  const resetForm = () => {
    setFormData({
      name: '',
      text: '',
      intent: 'general',
      variables: [],
      tags: [],
      isDefault: false,
      usageCount: 0,
      rating: 0
    });
  };

  const handleCreate = () => {
    createMutation.mutate(formData as InsertTemplate);
  };

  const handleEdit = (template: Template) => {
    setEditingTemplate(template);
    setFormData({
      name: template.name,
      text: template.text,
      intent: template.intent,
      variables: template.variables as string[],
      tags: template.tags as string[],
      isDefault: template.isDefault,
      usageCount: template.usageCount || 0,
      rating: typeof template.rating === 'string' ? parseFloat(template.rating) : (template.rating || 0)
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = () => {
    if (!editingTemplate) return;
    updateMutation.mutate({ 
      id: editingTemplate.id, 
      data: formData as Partial<InsertTemplate> 
    });
  };

  const handleDelete = (template: Template) => {
    if (window.confirm(`Are you sure you want to delete "${template.name}"?`)) {
      deleteMutation.mutate(template.id);
    }
  };

  const handlePreview = (template: Template) => {
    setPreviewTemplate(template);
    // Initialize preview variables
    const variables = template.variables as string[];
    const initialVars: Record<string, string> = {};
    variables.forEach(variable => {
      initialVars[variable] = variable === '{customerName}' ? 'John Doe' : 
                              variable === '{companyName}' ? 'Acme Corp' : 
                              variable === '{productName}' ? 'Premium Widget' : '';
    });
    setPreviewVariables(initialVars);
    setIsPreviewDialogOpen(true);
  };

  // A/B Testing handlers
  const handleCreateExperiment = (template: Template) => {
    setSelectedExperiment(template);
    setIsExperimentDialogOpen(true);
  };

  const handleCreateVariant = (template: Template) => {
    setSelectedExperiment(template);
    setIsVariantDialogOpen(true);
  };

  const handleViewResults = (experiment: Template) => {
    setSelectedExperimentId(experiment.abTestId || '');
    setIsResultsDialogOpen(true);
  };

  const handleSimulateTraffic = (templateId: string) => {
    // Simulate some traffic for demo purposes
    const impressions = Math.floor(Math.random() * 50) + 10;
    const conversions = Math.floor(Math.random() * impressions * 0.3);
    updateMetricsMutation.mutate({ templateId, impressions, conversions });
  };

  // Filter templates for experiments view
  const filterTemplatesForView = (): Template[] => {
    if (activeView === 'experiments') {
      return templates.filter((template: Template) => template.abTestId);
    }
    return templates;
  };

  const insertVariable = (variable: string) => {
    const textarea = document.getElementById('template-text') as HTMLTextAreaElement;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      const newText = text.substring(0, start) + variable + text.substring(end);
      
      setFormData(prev => ({ ...prev, text: newText }));
      
      // Update variables array
      if (!formData.variables?.includes(variable)) {
        setFormData(prev => ({ 
          ...prev, 
          variables: [...(prev.variables || []), variable] 
        }));
      }
    }
  };

  const renderPreviewContent = (text: string) => {
    let rendered = text;
    Object.entries(previewVariables).forEach(([variable, value]) => {
      rendered = rendered.replace(new RegExp(variable.replace(/[{}]/g, '\\$&'), 'g'), value || variable);
    });
    return rendered;
  };

  const getIntentIcon = (intent: string) => {
    switch (intent) {
      case 'support': return <Settings className="w-4 h-4" />;
      case 'sales': return <TrendingUp className="w-4 h-4" />;
      case 'marketing': return <Star className="w-4 h-4" />;
      case 'compliment': return <MessageSquare className="w-4 h-4" />;
      case 'greeting': return <MessageSquare className="w-4 h-4" />;
      default: return <Tag className="w-4 h-4" />;
    }
  };

  const getIntentColor = (intent: string) => {
    switch (intent) {
      case 'support': return 'bg-orange-100 text-orange-800';
      case 'sales': return 'bg-green-100 text-green-800';
      case 'marketing': return 'bg-purple-100 text-purple-800';
      case 'compliment': return 'bg-blue-100 text-blue-800';
      case 'greeting': return 'bg-cyan-100 text-cyan-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4) return 'text-green-600';
    if (rating >= 3) return 'text-yellow-600';
    if (rating >= 2) return 'text-orange-600';
    return 'text-red-600';
  };

  // Filter templates based on search and filters
  const filteredTemplates = templates.filter((template: Template) => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.text.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesIntent = intentFilter === 'all' || template.intent === intentFilter;
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'default' && template.isDefault) ||
                         (statusFilter === 'custom' && !template.isDefault);
    
    return matchesSearch && matchesIntent && matchesStatus;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-gray-400" />
        <span className="ml-2 text-gray-600">Loading templates...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="templates-page">
      {/* Header with Tabs and Stats */}
      <div className="space-y-4">
        <Tabs value={activeView} onValueChange={(value) => setActiveView(value as 'templates' | 'experiments')}>
          <div className="flex items-center justify-between">
            <TabsList className="grid w-80 grid-cols-2">
              <TabsTrigger value="templates" data-testid="tab-templates">
                <MessageSquare className="w-4 h-4 mr-2" />
                Templates
              </TabsTrigger>
              <TabsTrigger value="experiments" data-testid="tab-experiments">
                <TestTube className="w-4 h-4 mr-2" />
                A/B Tests
              </TabsTrigger>
            </TabsList>
            
            <div className="flex gap-2">
              <Button 
                onClick={() => setIsCreateDialogOpen(true)} 
                data-testid="button-create-template"
                variant="default"
              >
                <Plus className="w-4 h-4 mr-2" />
                New Template
              </Button>
            </div>
          </div>

          <TabsContent value="templates">
            {/* Templates Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Templates</p>
                      <p className="text-2xl font-bold text-blue-600" data-testid="total-templates-count">
                        {templates.length}
                      </p>
                    </div>
                    <MessageSquare className="w-8 h-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Templates</p>
                      <p className="text-2xl font-bold text-green-600" data-testid="active-templates-count">
                        {templates.filter((t: Template) => t.isDefault).length}
                      </p>
                    </div>
                    <CheckCircle className="w-8 h-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">In Experiments</p>
                      <p className="text-2xl font-bold text-purple-600" data-testid="experiment-templates-count">
                        {templates.filter((t: Template) => t.abTestId).length}
                      </p>
                    </div>
                    <TestTube className="w-8 h-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Avg Rating</p>
                      <p className="text-2xl font-bold text-orange-600" data-testid="avg-rating">
                        {templates.length > 0 ? (templates.reduce((acc: number, t: Template) => acc + (typeof t.rating === 'string' ? parseFloat(t.rating) : (t.rating || 0)), 0) / templates.length).toFixed(1) : '0.0'}
                      </p>
                    </div>
                    <Star className="w-8 h-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="experiments">
            {/* A/B Testing Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Experiments</p>
                      <p className="text-2xl font-bold text-blue-600" data-testid="active-experiments-count">
                        {experiments.length}
                      </p>
                    </div>
                    <TestTube className="w-8 h-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Variants</p>
                      <p className="text-2xl font-bold text-green-600" data-testid="total-variants-count">
                        {templates.filter((t: Template) => t.abTestId && t.variantType !== 'control').length}
                      </p>
                    </div>
                    <GitBranch className="w-8 h-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Impressions</p>
                      <p className="text-2xl font-bold text-purple-600" data-testid="total-impressions-count">
                        {templates.reduce((sum: number, t: Template) => sum + (t.impressionCount || 0), 0)}
                      </p>
                    </div>
                    <Eye className="w-8 h-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                      <p className="text-2xl font-bold text-orange-600" data-testid="overall-conversion-rate">
                        {(() => {
                          const totalImpressions = templates.reduce((sum: number, t: Template) => sum + (t.impressionCount || 0), 0);
                          const totalConversions = templates.reduce((sum: number, t: Template) => sum + (t.conversionCount || 0), 0);
                          return totalImpressions > 0 ? `${((totalConversions / totalImpressions) * 100).toFixed(1)}%` : '0.0%';
                        })()}
                      </p>
                    </div>
                    <Target className="w-8 h-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4 flex-1 min-w-0">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search templates..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="search-templates"
                />
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium">Filters:</span>
              </div>

              <Select value={intentFilter} onValueChange={setIntentFilter}>
                <SelectTrigger className="w-40" data-testid="filter-intent">
                  <SelectValue placeholder="Intent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Intents</SelectItem>
                  {TEMPLATE_INTENTS.map(intent => (
                    <SelectItem key={intent} value={intent}>
                      {intent.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {activeView === 'templates' && (
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-32" data-testid="filter-status">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="default">Active</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                    <SelectItem value="experiment">In Experiment</SelectItem>
                  </SelectContent>
                </Select>
              )}

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40" data-testid="sort-templates">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Name</SelectItem>
                  <SelectItem value="intent">Intent</SelectItem>
                  <SelectItem value="usageCount">Usage Count</SelectItem>
                  <SelectItem value="rating">Rating</SelectItem>
                  <SelectItem value="createdAt">Created Date</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {activeView === 'experiments' && (
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline"
                  onClick={() => {
                    // Simulate traffic for all experiment templates
                    experiments.forEach((exp: Template) => {
                      if (exp.abTestId) {
                        const experimentTemplates = templates.filter((t: Template) => t.abTestId === exp.abTestId);
                        experimentTemplates.forEach(template => {
                          handleSimulateTraffic(template.id);
                        });
                      }
                    });
                  }}
                  data-testid="button-simulate-traffic"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Simulate Traffic
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Content based on active view */}
      {activeView === 'templates' ? (
        /* Templates Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map((template: Template) => (
            <Card key={template.id} className="hover-elevate" data-testid={`template-card-${template.id}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      {getIntentIcon(template.intent)}
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                      {template.isDefault && (
                        <Badge variant="default" className="text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Active
                        </Badge>
                      )}
                      {template.abTestId && (
                        <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-800">
                          <TestTube className="w-3 h-3 mr-1" />
                          A/B Testing
                        </Badge>
                      )}
                    </div>
                    <Badge className={`text-xs ${getIntentColor(template.intent)}`}>
                      {template.intent.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <div className="text-sm text-gray-600 line-clamp-3">
                  {template.text}
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <BarChart3 className="w-3 h-3" />
                      <span>{template.usageCount || 0} uses</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3" />
                      <span className={getRatingColor(typeof template.rating === 'string' ? parseFloat(template.rating) : (template.rating || 0))}>
                        {typeof template.rating === 'string' ? parseFloat(template.rating).toFixed(1) : (template.rating || 0).toFixed(1)}
                      </span>
                    </div>
                    {template.abTestId && (
                      <div className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        <span>{template.impressionCount || 0}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handlePreview(template)}
                      data-testid={`button-preview-${template.id}`}
                    >
                      <Eye className="w-3 h-3" />
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(template)}
                      data-testid={`button-edit-${template.id}`}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>

                    {!template.abTestId ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCreateExperiment(template)}
                        data-testid={`button-experiment-${template.id}`}
                        title="Create A/B Test"
                      >
                        <TestTube className="w-3 h-3" />
                      </Button>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCreateVariant(template)}
                        data-testid={`button-variant-${template.id}`}
                        title="Create Variant"
                      >
                        <GitBranch className="w-3 h-3" />
                      </Button>
                    )}

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => duplicateMutation.mutate(template)}
                      disabled={duplicateMutation.isPending}
                      data-testid={`button-duplicate-${template.id}`}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(template)}
                      data-testid={`button-delete-${template.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        /* Experiments Grid */
        <div className="space-y-6">
          {experiments.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <TestTube className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Active Experiments</h3>
                <p className="text-gray-600 mb-4">
                  Start by creating an A/B test for one of your templates to compare performance.
                </p>
                <Button onClick={() => setActiveView('templates')}>
                  <MessageSquare className="w-4 h-4 mr-2" />
                  View Templates
                </Button>
              </CardContent>
            </Card>
          ) : (
            experiments.map((experiment: Template) => {
              const experimentTemplates = templates.filter((t: Template) => t.abTestId === experiment.abTestId);
              const totalImpressions = experimentTemplates.reduce((sum, t) => sum + (t.impressionCount || 0), 0);
              const totalConversions = experimentTemplates.reduce((sum, t) => sum + (t.conversionCount || 0), 0);
              const conversionRate = totalImpressions > 0 ? (totalConversions / totalImpressions) * 100 : 0;
              
              return (
                <Card key={experiment.id} className="hover-elevate" data-testid={`experiment-card-${experiment.id}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <TestTube className="w-6 h-6 text-purple-600" />
                        <div>
                          <CardTitle className="text-xl">{experiment.name} - A/B Test</CardTitle>
                          <p className="text-sm text-gray-600 mt-1">
                            {experimentTemplates.length} variants • {experiment.intent} intent
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                          <Activity className="w-3 h-3 mr-1" />
                          Running
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    {/* Experiment Summary */}
                    <div className="grid grid-cols-4 gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-600">{experimentTemplates.length}</p>
                        <p className="text-sm text-gray-600">Variants</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-purple-600">{totalImpressions}</p>
                        <p className="text-sm text-gray-600">Impressions</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">{totalConversions}</p>
                        <p className="text-sm text-gray-600">Conversions</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-orange-600">{conversionRate.toFixed(1)}%</p>
                        <p className="text-sm text-gray-600">Conv. Rate</p>
                      </div>
                    </div>

                    {/* Variants Performance */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold">Variant Performance</h4>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewResults(experiment)}
                          data-testid={`button-results-${experiment.id}`}
                        >
                          <BarChart3 className="w-4 h-4 mr-2" />
                          View Detailed Results
                        </Button>
                      </div>
                      
                      {experimentTemplates.map((variant, index) => {
                        const variantConversionRate = (variant.impressionCount || 0) > 0 
                          ? ((variant.conversionCount || 0) / (variant.impressionCount || 0)) * 100 
                          : 0;
                        const isWinner = variantConversionRate === Math.max(...experimentTemplates.map(v => 
                          (v.impressionCount || 0) > 0 ? ((v.conversionCount || 0) / (v.impressionCount || 0)) * 100 : 0
                        ));

                        return (
                          <div key={variant.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className={`w-3 h-3 rounded-full ${
                                variant.variantType === 'control' ? 'bg-blue-500' : 
                                variant.variantType === 'variant_a' ? 'bg-green-500' : 'bg-orange-500'
                              }`} />
                              <div>
                                <p className="font-medium">
                                  {variant.variantType === 'control' ? 'Control' : 
                                   variant.variantType === 'variant_a' ? 'Variant A' : 'Variant B'}
                                  {isWinner && totalImpressions > 50 && (
                                    <Trophy className="inline w-4 h-4 ml-2 text-yellow-500" />
                                  )}
                                </p>
                                <p className="text-sm text-gray-600">{variant.impressionCount || 0} impressions</p>
                              </div>
                            </div>
                            
                            <div className="text-right">
                              <p className="font-semibold">{variantConversionRate.toFixed(1)}%</p>
                              <p className="text-sm text-gray-600">{variant.conversionCount || 0} conversions</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-2 border-t">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCreateVariant(experiment)}
                          data-testid={`button-add-variant-${experiment.id}`}
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          Add Variant
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            experimentTemplates.forEach(template => {
                              handleSimulateTraffic(template.id);
                            });
                          }}
                          data-testid={`button-simulate-${experiment.id}`}
                        >
                          <Zap className="w-4 h-4 mr-2" />
                          Simulate Traffic
                        </Button>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            // Stop experiment logic
                            toast({ 
                              title: 'Experiment Paused', 
                              description: 'A/B test has been paused', 
                              variant: 'default' 
                            });
                          }}
                          data-testid={`button-pause-${experiment.id}`}
                        >
                          <Pause className="w-4 h-4 mr-2" />
                          Pause
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      )}

      {filteredTemplates.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No templates found</h3>
            <p className="text-gray-500 mb-4">
              {searchQuery || intentFilter !== 'all' || statusFilter !== 'all' 
                ? 'No templates match your current filters.' 
                : 'Get started by creating your first template.'
              }
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)} data-testid="button-create-first-template">
              <Plus className="w-4 h-4 mr-2" />
              Create Template
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Create Template Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-2xl" data-testid="create-template-dialog">
          <DialogHeader>
            <DialogTitle>Create New Template</DialogTitle>
            <DialogDescription>
              Create a reusable template with variables for personalized responses.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="template-name">Template Name</Label>
                <Input
                  id="template-name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter template name..."
                  data-testid="input-template-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="template-intent">Intent</Label>
                <Select 
                  value={formData.intent || 'general'} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, intent: value }))}
                >
                  <SelectTrigger data-testid="select-template-intent">
                    <SelectValue placeholder="Select intent" />
                  </SelectTrigger>
                  <SelectContent>
                    {TEMPLATE_INTENTS.map(intent => (
                      <SelectItem key={intent} value={intent}>
                        {intent.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="template-text">Template Text</Label>
              <Textarea
                id="template-text"
                value={formData.text || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, text: e.target.value }))}
                placeholder="Enter your template text with variables like {customerName}..."
                className="min-h-32"
                data-testid="textarea-template-text"
              />
            </div>

            <div className="space-y-2">
              <Label>Common Variables</Label>
              <div className="flex flex-wrap gap-2">
                {COMMON_VARIABLES.map(variable => (
                  <Button
                    key={variable}
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => insertVariable(variable)}
                    data-testid={`button-insert-${variable.replace(/[{}]/g, '')}`}
                  >
                    {variable}
                  </Button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="template-active"
                  checked={formData.isDefault || false}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isDefault: checked }))}
                  data-testid="switch-template-active"
                />
                <Label htmlFor="template-active">Active Template</Label>
              </div>

              <div className="space-y-2">
                <Label htmlFor="ab-test-group">A/B Test Group</Label>
                <Input
                  id="ab-test-group"
                  value={formData.tags?.join(', ') || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(Boolean) }))}
                  placeholder="Optional: A or B"
                  data-testid="input-ab-test-group"
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateDialogOpen(false)}
              data-testid="button-cancel-create"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreate}
              disabled={createMutation.isPending}
              data-testid="button-save-create"
            >
              Create Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Template Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-2xl" data-testid="edit-template-dialog">
          <DialogHeader>
            <DialogTitle>Edit Template</DialogTitle>
            <DialogDescription>
              Modify your template content and settings.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-template-name">Template Name</Label>
                <Input
                  id="edit-template-name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter template name..."
                  data-testid="input-edit-template-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-template-intent">Intent</Label>
                <Select 
                  value={formData.intent || 'general'} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, intent: value }))}
                >
                  <SelectTrigger data-testid="select-edit-template-intent">
                    <SelectValue placeholder="Select intent" />
                  </SelectTrigger>
                  <SelectContent>
                    {TEMPLATE_INTENTS.map(intent => (
                      <SelectItem key={intent} value={intent}>
                        {intent.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-template-text">Template Text</Label>
              <Textarea
                id="edit-template-text"
                value={formData.text || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, text: e.target.value }))}
                placeholder="Enter your template text with variables like {customerName}..."
                className="min-h-32"
                data-testid="textarea-edit-template-text"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="edit-template-active"
                  checked={formData.isDefault || false}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isDefault: checked }))}
                  data-testid="switch-edit-template-active"
                />
                <Label htmlFor="edit-template-active">Active Template</Label>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-ab-test-group">A/B Test Group</Label>
                <Input
                  id="edit-ab-test-group"
                  value={formData.tags?.join(', ') || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(Boolean) }))}
                  placeholder="Optional: A or B"
                  data-testid="input-edit-ab-test-group"
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              data-testid="button-cancel-edit"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleUpdate}
              disabled={updateMutation.isPending}
              data-testid="button-save-edit"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Template Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="sm:max-w-2xl" data-testid="preview-template-dialog">
          <DialogHeader>
            <DialogTitle>Preview Template</DialogTitle>
            <DialogDescription>
              See how your template will look with sample data.
            </DialogDescription>
          </DialogHeader>

          {previewTemplate && (
            <div className="space-y-4">
              <div className="space-y-3">
                <Label>Variable Values</Label>
                {(previewTemplate.variables as string[]).map(variable => (
                  <div key={variable} className="grid grid-cols-4 gap-2 items-center">
                    <Label className="text-sm">{variable}</Label>
                    <Input
                      className="col-span-3"
                      value={previewVariables[variable] || ''}
                      onChange={(e) => setPreviewVariables(prev => ({ 
                        ...prev, 
                        [variable]: e.target.value 
                      }))}
                      placeholder={`Enter ${variable} value...`}
                      data-testid={`input-preview-${variable.replace(/[{}]/g, '')}`}
                    />
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <Label>Preview</Label>
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <p className="text-sm whitespace-pre-wrap" data-testid="preview-content">
                    {renderPreviewContent(previewTemplate.text)}
                  </p>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsPreviewDialogOpen(false)}
              data-testid="button-close-preview"
            >
              Close Preview
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}