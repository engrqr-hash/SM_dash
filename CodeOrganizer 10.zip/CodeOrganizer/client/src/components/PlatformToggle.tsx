import { Button } from "@/components/ui/button";

interface Platform {
  id: string;
  name: string;
  icon: string;
  color: string;
}

interface PlatformToggleProps {
  platforms: Platform[];
  activePlatforms: Set<string>;
  onToggle: (platformId: string) => void;
}

export default function PlatformToggle({ platforms, activePlatforms, onToggle }: PlatformToggleProps) {
  return (
    <div className="flex flex-wrap gap-1" data-testid="platform-toggles">
      {platforms.map((platform) => {
        const isActive = activePlatforms.has(platform.id);
        
        return (
          <Button
            key={platform.id}
            variant={isActive ? "default" : "outline"}
            size="sm"
            className={`text-xs h-7 px-2 transition-all duration-200 hover-elevate ${
              isActive 
                ? 'text-white shadow-md' 
                : 'text-gray-600 hover:text-gray-800'
            }`}
            style={isActive ? { backgroundColor: platform.color } : {}}
            onClick={() => {
              onToggle(platform.id);
              console.log(`${platform.name} toggled: ${!isActive}`);
            }}
            data-testid={`toggle-${platform.id}`}
          >
            <i className={`${platform.icon} mr-1`}></i>
            {platform.name}
          </Button>
        );
      })}
    </div>
  );
}