import { useState } from "react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isExpanded: boolean;
  onToggle: () => void;
  currentView: string;
  onViewChange: (view: string) => void;
}

export default function Sidebar({ isExpanded, onToggle, currentView, onViewChange }: SidebarProps) {
  const menuItems = [
    { id: "menu", icon: "fas fa-bars", label: "Menu", action: onToggle },
    { id: "composer", icon: "fas fa-edit", label: "Composer" },
    { id: "inbox", icon: "fas fa-inbox", label: "Inbox & Engagement" },
    { id: "ai-assistant", icon: "fas fa-robot", label: "AI Assistant" },
    { id: "ai-insights", icon: "fas fa-brain", label: "AI Insights" },
    { id: "upcoming-posts", icon: "fas fa-calendar-check", label: "Scheduled Posts" },
    { id: "clone-post", icon: "fas fa-copy", label: "Clone Post" },
    { id: "auto-replies", icon: "fas fa-robot", label: "Auto Replies" },
    { id: "approval-queue", icon: "fas fa-check-circle", label: "Approval Queue" },
    { id: "templates", icon: "fas fa-file-text", label: "Templates" },
    { id: "analytics", icon: "fas fa-chart-line", label: "Analytics" },
    { id: "calendar", icon: "fas fa-calendar-alt", label: "Calendar" },
    { id: "media-library", icon: "fas fa-folder-open", label: "Media Library" },
    { id: "team-management", icon: "fas fa-users", label: "Team" },
    { id: "reports", icon: "fas fa-file-chart", label: "Reports" },
    { id: "settings", icon: "fas fa-cog", label: "Settings" },
  ];

  return (
    <div 
      className={`fixed left-0 top-0 h-full bg-white border-r border-gray-200 transition-all duration-300 z-40 ${
        isExpanded ? 'w-64' : 'w-[100px]'
      }`}
      data-testid="sidebar"
    >
      {/* Logo */}
      <div className="p-2 border-b border-gray-100">
        <div className="flex items-center justify-center">
          {isExpanded ? (
            <div className="flex items-center gap-2" data-testid="logo-full">
              <div className="w-6 h-6 bg-gradient-to-r from-brand-primary to-brand-secondary rounded-lg flex items-center justify-center">
                <span className="text-white text-xs font-bold">SM</span>
              </div>
              <span className="font-bold text-sm text-gray-800">SocialManager</span>
            </div>
          ) : (
            <div className="w-6 h-6 bg-gradient-to-r from-brand-primary to-brand-secondary rounded-lg flex items-center justify-center" data-testid="logo-mini">
              <span className="text-white text-xs font-bold">SM</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Menu Items */}
      <nav className="p-1">
        <div className="space-y-1">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant={currentView === item.id ? "default" : "ghost"}
              size="sm"
              className={`w-full justify-start gap-2 h-9 ${
                currentView === item.id ? 'text-brand-primary bg-brand-primary/10' : 'text-gray-600'
              } hover-elevate`}
              onClick={() => {
                if (item.action) {
                  item.action();
                } else {
                  onViewChange(item.id);
                  console.log(`${item.label} clicked`);
                }
              }}
              data-testid={`button-${item.id}`}
            >
              <i className={`${item.icon} text-sm`}></i>
              {isExpanded && <span className="text-xs font-medium">{item.label}</span>}
            </Button>
          ))}
        </div>
        
        {/* Platform Integration Quick Access */}
        <div className="px-2 py-1 mt-4">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 h-9 text-gray-600 hover-elevate"
            onClick={() => console.log('Platform integration clicked')}
            data-testid="button-platforms"
            title="Platform Integration"
          >
            <i className="fas fa-plug text-sm text-brand-primary"></i>
            {isExpanded && <span className="text-xs font-medium">Platforms</span>}
            {isExpanded && (
              <div className="ml-auto flex gap-1" data-testid="platform-status-indicators">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full" title="3 connected"></div>
                <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full" title="1 pending"></div>
                <div className="w-1.5 h-1.5 bg-red-500 rounded-full" title="2 disconnected"></div>
              </div>
            )}
          </Button>
        </div>
      </nav>
      
      {/* User Profile */}
      <div className="absolute bottom-0 left-0 right-0 p-2 border-t border-gray-100">
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start gap-2 h-9 text-gray-600 hover-elevate"
          onClick={() => console.log('Profile clicked')}
          data-testid="button-profile"
        >
          <div className="w-5 h-5 bg-gradient-to-r from-brand-primary to-brand-secondary rounded-full flex items-center justify-center">
            <span className="text-white text-xs font-bold">U</span>
          </div>
          {isExpanded && <span className="text-xs font-medium">Profile</span>}
        </Button>
      </div>
    </div>
  );
}