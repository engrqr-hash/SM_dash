import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import type { Post } from '@shared/schema';

// Use Post type from schema
type ScheduledPost = Post;

export default function UpcomingPosts() {
  const [activeTab, setActiveTab] = useState('all');
  const [selectedPosts, setSelectedPosts] = useState<string[]>([]);
  
  // Fetch posts from API
  const { data: posts = [], isLoading, error } = useQuery({
    queryKey: ['/api/posts'],
    queryFn: async () => {
      const response = await fetch('/api/posts');
      if (!response.ok) {
        throw new Error('Failed to fetch posts');
      }
      return response.json();
    }
  });
  
  const scheduledPosts: ScheduledPost[] = posts;

  const getPlatformIcon = (platform: string) => {
    const icons = {
      instagram: 'fab fa-instagram text-pink-500',
      facebook: 'fab fa-facebook-f text-blue-500',
      twitter: 'fab fa-x-twitter text-gray-800',
      linkedin: 'fab fa-linkedin-in text-blue-600'
    };
    return icons[platform as keyof typeof icons] || 'fas fa-globe';
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      scheduled: { variant: 'secondary' as const, icon: 'fas fa-clock', color: 'text-blue-600 bg-blue-100' },
      pending: { variant: 'secondary' as const, icon: 'fas fa-hourglass-half', color: 'text-yellow-600 bg-yellow-100' },
      failed: { variant: 'destructive' as const, icon: 'fas fa-exclamation-triangle', color: 'text-red-600 bg-red-100' },
      published: { variant: 'default' as const, icon: 'fas fa-check-circle', color: 'text-green-600 bg-green-100' },
      draft: { variant: 'outline' as const, icon: 'fas fa-file-alt', color: 'text-gray-600 bg-gray-100' }
    };
    return variants[status as keyof typeof variants] || variants.scheduled;
  };

  const formatDate = (date: Date | null | string) => {
    if (!date) return 'Not scheduled';
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffTime = dateObj.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays === -1) return 'Yesterday';
    if (diffDays < 0) return `${Math.abs(diffDays)} days ago`;
    return `In ${diffDays} days`;
  };

  const formatTime = (date: Date | null | string) => {
    if (!date) return '';
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const filteredPosts = scheduledPosts.filter(post => {
    if (activeTab === 'all') return true;
    if (activeTab === 'upcoming') return ['scheduled', 'pending'].includes(post.status);
    if (activeTab === 'published') return post.status === 'published';
    if (activeTab === 'failed') return post.status === 'failed';
    if (activeTab === 'draft') return post.status === 'draft';
    return Array.isArray(post.platforms) ? post.platforms.includes(activeTab) : post.platforms === activeTab;
  });

  const togglePostSelection = (postId: string) => {
    setSelectedPosts(prev => 
      prev.includes(postId) 
        ? prev.filter(id => id !== postId)
        : [...prev, postId]
    );
  };

  const getStatusCounts = () => {
    return {
      scheduled: scheduledPosts.filter(p => p.status === 'scheduled').length,
      pending: scheduledPosts.filter(p => p.status === 'pending').length,
      published: scheduledPosts.filter(p => p.status === 'published').length,
      failed: scheduledPosts.filter(p => p.status === 'failed').length,
      draft: scheduledPosts.filter(p => p.status === 'draft').length
    };
  };

  const statusCounts = getStatusCounts();

  return (
    <div className="space-y-6" data-testid="upcoming-posts">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800 flex items-center">
            <i className="fas fa-calendar-check mr-2 text-green-500"></i>
            Scheduled Posts
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage your upcoming and published content across all platforms
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selectedPosts.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {selectedPosts.length} selected
            </Badge>
          )}
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => console.log('Schedule new post')}
            data-testid="button-schedule-new"
          >
            <i className="fas fa-plus mr-1"></i>
            Schedule Post
          </Button>
        </div>
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-blue-600">{statusCounts.scheduled}</p>
              <p className="text-xs text-gray-600">Scheduled</p>
            </div>
            <i className="fas fa-clock text-blue-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-yellow-600">{statusCounts.pending}</p>
              <p className="text-xs text-gray-600">Pending</p>
            </div>
            <i className="fas fa-hourglass-half text-yellow-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-gray-600">{statusCounts.draft}</p>
              <p className="text-xs text-gray-600">Drafts</p>
            </div>
            <i className="fas fa-file-alt text-gray-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-green-600">{statusCounts.published}</p>
              <p className="text-xs text-gray-600">Published</p>
            </div>
            <i className="fas fa-check-circle text-green-500 text-xl"></i>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-bold text-red-600">{statusCounts.failed}</p>
              <p className="text-xs text-gray-600">Failed</p>
            </div>
            <i className="fas fa-exclamation-triangle text-red-500 text-xl"></i>
          </div>
        </Card>
      </div>

      {/* Bulk Actions */}
      {selectedPosts.length > 0 && (
        <Card className="p-4 bg-blue-50 border-blue-200">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-blue-800">
              {selectedPosts.length} posts selected
            </span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="text-xs h-7">
                <i className="fas fa-edit mr-1"></i>
                Edit
              </Button>
              <Button variant="outline" size="sm" className="text-xs h-7">
                <i className="fas fa-clone mr-1"></i>
                Duplicate
              </Button>
              <Button variant="outline" size="sm" className="text-xs h-7">
                <i className="fas fa-trash mr-1"></i>
                Delete
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs h-7"
                onClick={() => setSelectedPosts([])}
              >
                Clear
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Posts List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Posts</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-8 mb-4">
              <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
              <TabsTrigger value="upcoming" className="text-xs">Upcoming</TabsTrigger>
              <TabsTrigger value="published" className="text-xs">Published</TabsTrigger>
              <TabsTrigger value="draft" className="text-xs">Drafts</TabsTrigger>
              <TabsTrigger value="failed" className="text-xs">Failed</TabsTrigger>
              <TabsTrigger value="instagram" className="text-xs">Instagram</TabsTrigger>
              <TabsTrigger value="facebook" className="text-xs">Facebook</TabsTrigger>
              <TabsTrigger value="twitter" className="text-xs">X</TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab}>
              {isLoading ? (
                <div className="text-center py-12">
                  <i className="fas fa-spinner fa-spin text-2xl text-gray-400 mb-4"></i>
                  <p className="text-gray-500">Loading posts...</p>
                </div>
              ) : error ? (
                <div className="text-center py-12">
                  <i className="fas fa-exclamation-triangle text-2xl text-red-400 mb-4"></i>
                  <p className="text-gray-500">Failed to load posts. Please try again.</p>
                </div>
              ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredPosts.map((post) => {
                  const statusBadge = getStatusBadge(post.status);
                  
                  return (
                    <div
                      key={post.id}
                      className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 hover-elevate cursor-pointer"
                      data-testid={`post-${post.id}`}
                    >
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          checked={selectedPosts.includes(post.id)}
                          onChange={() => togglePostSelection(post.id)}
                          className="mt-1"
                          data-testid={`checkbox-${post.id}`}
                        />
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <div className="flex items-center gap-2">
                              <i className={getPlatformIcon(Array.isArray(post.platforms) ? post.platforms[0] : post.platforms)}></i>
                              <span className="text-sm font-medium text-gray-800 capitalize">
                                {Array.isArray(post.platforms) ? post.platforms[0] : post.platforms}
                              </span>
                              {Array.isArray(post.platforms) && post.platforms.length > 1 && (
                                <Badge variant="outline" className="text-xs px-1 py-0 h-4">
                                  <i className="fas fa-share-alt mr-1"></i>
                                  {post.platforms.length} platforms
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant={statusBadge.variant}
                                className={`text-xs px-2 py-0 h-5 ${statusBadge.color}`}
                              >
                                <i className={`${statusBadge.icon} mr-1`}></i>
                                {post.status}
                              </Badge>
                            </div>
                          </div>
                          
                          <p className="text-sm text-gray-700 mb-3 line-clamp-2">
                            {post.content}
                          </p>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <span className="flex items-center gap-1">
                                <i className="fas fa-calendar mr-1"></i>
                                {formatDate(post.scheduledTime)}
                              </span>
                              <span className="flex items-center gap-1">
                                <i className="fas fa-clock mr-1"></i>
                                {formatTime(post.scheduledTime)}
                              </span>
                            </div>
                            
                            {post.engagement && typeof post.engagement === 'object' && post.engagement !== null && (
                              <div className="flex items-center gap-3 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  <i className="fas fa-heart text-red-500"></i>
                                  {(post.engagement as any)?.likes || 0}
                                </span>
                                <span className="flex items-center gap-1">
                                  <i className="fas fa-comment text-blue-500"></i>
                                  {(post.engagement as any)?.comments || 0}
                                </span>
                                <span className="flex items-center gap-1">
                                  <i className="fas fa-share text-green-500"></i>
                                  {(post.engagement as any)?.shares || 0}
                                </span>
                              </div>
                            )}
                            
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                                <i className="fas fa-edit mr-1"></i>
                                Edit
                              </Button>
                              <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                                <i className="fas fa-eye mr-1"></i>
                                Preview
                              </Button>
                              {post.status === 'scheduled' && (
                                <Button variant="ghost" size="sm" className="h-6 px-2 text-xs text-red-600">
                                  <i className="fas fa-times mr-1"></i>
                                  Cancel
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                
                {filteredPosts.length === 0 && (
                  <div className="text-center py-12">
                    <i className="fas fa-calendar-times text-4xl text-gray-300 mb-4"></i>
                    <p className="text-gray-500">No posts in this category</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-3"
                      onClick={() => console.log('Schedule first post')}
                    >
                      <i className="fas fa-plus mr-1"></i>
                      Schedule Your First Post
                    </Button>
                  </div>
                )}
              </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}