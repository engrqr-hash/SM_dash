import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface HashtagGeneratorProps {
  onHashtagAdd: (hashtag: string) => void;
  content?: string;
}

export default function HashtagGenerator({ onHashtagAdd, content = "" }: HashtagGeneratorProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const generateHashtags = async () => {
    setIsLoading(true);
    
    // Simulate AI processing delay
    setTimeout(() => {
      const contentBasedHashtags = generateContentBasedHashtags(content);
      setSuggestions(contentBasedHashtags);
      setIsLoading(false);
      console.log('Content-based hashtags generated');
    }, 1200);
  };

  // Generate hashtags based on content analysis
  const generateContentBasedHashtags = (text: string): string[] => {
    const hashtagDatabase = {
      business: ["#business", "#entrepreneur", "#startup", "#growth", "#success", "#leadership"],
      marketing: ["#marketing", "#digital", "#branding", "#strategy", "#socialmedia", "#content"],
      technology: ["#technology", "#tech", "#innovation", "#ai", "#digital", "#future"],
      creative: ["#creative", "#design", "#art", "#inspiration", "#creativity", "#visual"],
      lifestyle: ["#lifestyle", "#wellness", "#motivation", "#mindset", "#health", "#balance"],
      food: ["#food", "#foodie", "#recipe", "#cooking", "#delicious", "#cuisine"],
      travel: ["#travel", "#adventure", "#explore", "#wanderlust", "#vacation", "#destination"],
      fitness: ["#fitness", "#workout", "#health", "#gym", "#training", "#wellness"],
      fashion: ["#fashion", "#style", "#outfit", "#trendy", "#ootd", "#fashionista"],
      photography: ["#photography", "#photo", "#photographer", "#capture", "#visual", "#art"]
    };

    const generalHashtags = ["#motivation", "#success", "#inspiration", "#growth", "#life", "#goals", "#happy", "#love"];
    
    // Convert content to lowercase for keyword matching
    const lowerContent = text.toLowerCase();
    const matchedHashtags: string[] = [];

    // Check for keywords and add relevant hashtags
    Object.entries(hashtagDatabase).forEach(([category, hashtags]) => {
      const keywords = {
        business: ["business", "company", "work", "professional", "career", "office"],
        marketing: ["marketing", "brand", "campaign", "promotion", "advertising", "social"],
        technology: ["technology", "tech", "software", "app", "digital", "online", "ai", "computer"],
        creative: ["creative", "design", "art", "create", "artistic", "visual", "graphic"],
        lifestyle: ["life", "lifestyle", "daily", "routine", "living", "personal"],
        food: ["food", "eat", "recipe", "cook", "meal", "delicious", "taste"],
        travel: ["travel", "trip", "vacation", "journey", "explore", "visit", "destination"],
        fitness: ["fitness", "workout", "exercise", "gym", "training", "health", "sport"],
        fashion: ["fashion", "style", "outfit", "clothes", "wear", "dress", "look"],
        photography: ["photo", "picture", "image", "photography", "camera", "shot", "capture"]
      };

      const categoryKeywords = keywords[category as keyof typeof keywords] || [];
      
      if (categoryKeywords.some(keyword => lowerContent.includes(keyword))) {
        matchedHashtags.push(...hashtags.slice(0, 3)); // Add top 3 hashtags from matched category
      }
    });

    // If no specific matches, use general hashtags
    if (matchedHashtags.length === 0) {
      matchedHashtags.push(...generalHashtags.slice(0, 6));
    }

    // Add some variety and remove duplicates
    const uniqueHashtags = Array.from(new Set(matchedHashtags));
    
    // Shuffle and return 8-12 hashtags
    const shuffled = uniqueHashtags.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, Math.min(12, Math.max(8, shuffled.length)));
  };

  const trendingHashtags = [
    "#trending", "#viral", "#fyp", "#motivation", "#success",
    "#inspiration", "#productivity", "#lifestyle", "#wellness"
  ];

  return (
    <Card className="w-full" data-testid="hashtag-generator">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-gray-800 flex items-center">
          <i className="fas fa-hashtag mr-2 text-purple-500"></i>
          Hashtag Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* AI Generation */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold text-gray-700">AI-Powered Suggestions</h4>
            <Button
              size="sm"
              onClick={generateHashtags}
              disabled={isLoading}
              className="text-xs bg-gradient-to-r from-brand-primary to-brand-secondary"
              data-testid="button-generate-ai-hashtags"
            >
              {isLoading ? (
                <>
                  <div className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin mr-1"></div>
                  Generating...
                </>
              ) : (
                <>
                  <i className="fas fa-robot mr-1"></i>
                  Generate
                </>
              )}
            </Button>
          </div>

          {/* AI Suggestions */}
          {suggestions.length > 0 && (
            <div className="flex flex-wrap gap-1" data-testid="ai-suggestions">
              {suggestions.map((hashtag, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer text-xs bg-blue-100 text-blue-700 hover:bg-blue-200 hover-elevate"
                  onClick={() => {
                    onHashtagAdd(hashtag);
                    console.log(`Added hashtag: ${hashtag}`);
                  }}
                  data-testid={`ai-hashtag-${index}`}
                >
                  {hashtag}
                </Badge>
              ))}
            </div>
          )}

          {suggestions.length === 0 && !isLoading && (
            <p className="text-xs text-gray-500 text-center py-4 border-2 border-dashed border-gray-200 rounded-lg">
              Click "Generate" to get AI-powered hashtag suggestions based on your content
            </p>
          )}
        </div>

        {/* Trending Hashtags */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-700 flex items-center">
            <i className="fas fa-fire mr-1 text-red-500"></i>
            Trending Now
          </h4>
          <div className="flex flex-wrap gap-1" data-testid="trending-hashtags">
            {trendingHashtags.map((hashtag, index) => (
              <Badge
                key={index}
                variant="outline"
                className="cursor-pointer text-xs hover:bg-red-50 hover:border-red-300 hover-elevate"
                onClick={() => {
                  onHashtagAdd(hashtag);
                  console.log(`Added trending hashtag: ${hashtag}`);
                }}
                data-testid={`trending-hashtag-${index}`}
              >
                {hashtag}
              </Badge>
            ))}
          </div>
        </div>

        {/* Popular Categories */}
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-700 flex items-center">
            <i className="fas fa-star mr-1 text-yellow-500"></i>
            Popular Categories
          </h4>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-xs justify-start h-8"
              onClick={() => console.log('Business hashtags clicked')}
              data-testid="button-business-hashtags"
            >
              <i className="fas fa-briefcase mr-1 text-blue-500"></i>
              Business
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-xs justify-start h-8"
              onClick={() => console.log('Lifestyle hashtags clicked')}
              data-testid="button-lifestyle-hashtags"
            >
              <i className="fas fa-heart mr-1 text-pink-500"></i>
              Lifestyle
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-xs justify-start h-8"
              onClick={() => console.log('Tech hashtags clicked')}
              data-testid="button-tech-hashtags"
            >
              <i className="fas fa-laptop mr-1 text-green-500"></i>
              Technology
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-xs justify-start h-8"
              onClick={() => console.log('Creative hashtags clicked')}
              data-testid="button-creative-hashtags"
            >
              <i className="fas fa-palette mr-1 text-purple-500"></i>
              Creative
            </Button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex gap-2 pt-2 border-t border-gray-100">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 text-xs"
            onClick={() => console.log('Copy all hashtags triggered')}
            data-testid="button-copy-hashtags"
          >
            <i className="fas fa-copy mr-1"></i>
            Copy All
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1 text-xs"
            onClick={() => {
              setSuggestions([]);
              console.log('Hashtags cleared');
            }}
            data-testid="button-clear-hashtags"
          >
            <i className="fas fa-trash mr-1"></i>
            Clear
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}