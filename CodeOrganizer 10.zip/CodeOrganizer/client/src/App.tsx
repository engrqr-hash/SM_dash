import { useState, useEffect } from "react";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { queryClient } from "./lib/queryClient";

// Import components
import Sidebar from "./components/Sidebar";
import PostComposer from "./components/PostComposer";
import MediaUpload from "./components/MediaUpload";
import MobilePreview from "./components/MobilePreview";
import AnalyticsCard from "./components/AnalyticsCard";
import HashtagGenerator from "./components/HashtagGenerator";
import Calendar from "./components/Calendar";
import ActivityFeed from "./components/ActivityFeed";
import Toast, { useToast } from "./components/Toast";

// Import new dashboard components
import InboxEngagement from "./components/InboxEngagement";
import AIAssistant from "./components/AIAssistant";
import AIInsights from "./components/AIInsights";
import UpcomingPosts from "./components/UpcomingPosts";
import MediaLibrary from "./components/MediaLibrary";
import Settings from "./components/Settings";
import ClonePost from "./components/ClonePost";
import AutoReplies from "./components/AutoReplies";
import ApprovalQueue from "./components/ApprovalQueue";
import Templates from "./components/Templates";
import TeamManagement from "./components/TeamManagement";
import Reports from "./components/Reports";

function App() {
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  const [currentView, setCurrentView] = useState('composer');
  const [postContent, setPostContent] = useState("");
  const [uploadedMedia, setUploadedMedia] = useState<File[]>([]);
  const [currentPlatform, setCurrentPlatform] = useState("instagram");
  const [isPreviewVisible, setIsPreviewVisible] = useState(false);
  const { toast, showToast, hideToast } = useToast();

  // Default analytics data while we fetch real data
  const defaultAnalyticsData = [
    { title: "Total Posts", value: "0", change: "+0%", changeType: "positive" as const, icon: "fas fa-file-alt" },
    { title: "Scheduled", value: "0", change: "+0%", changeType: "positive" as const, icon: "fas fa-clock" },
    { title: "Published", value: "0", change: "+0%", changeType: "positive" as const, icon: "fas fa-share" },
    { title: "Engagement", value: "0", change: "+0%", changeType: "positive" as const, icon: "fas fa-heart" }
  ];

  // Update document title when view changes
  useEffect(() => {
    document.title = `${getPageTitle()} | Social Media Manager`;
  }, [currentView]);

  const handlePost = (postData: any) => {
    console.log('Post created:', postData);
    showToast('Post published successfully!', 'success');
    setPostContent("");
    setUploadedMedia([]);
  };

  const handleClonePost = (cloneData: any) => {
    console.log('Post cloned:', cloneData);
    showToast('Post cloned successfully!', 'success');
  };

  const handleAutoReply = (autoReplyData: any) => {
    console.log('Auto Reply saved:', autoReplyData);
    showToast('Auto Reply configured successfully!', 'success');
  };

  const handleMediaUpload = (files: File[]) => {
    setUploadedMedia(files);
    // Auto-show preview when media is uploaded
    if (files.length > 0) {
      setIsPreviewVisible(true);
    }
    showToast(`${files.length} media files uploaded`, 'success');
  };

  const handleHashtagAdd = (hashtag: string) => {
    setPostContent(prev => prev + (prev.endsWith(' ') ? '' : ' ') + hashtag);
    showToast(`Added hashtag: ${hashtag}`, 'success');
  };

  const handleDateClick = (date: number) => {
    console.log(`Calendar date clicked: ${date}`);
    showToast(`Viewing events for date ${date}`, 'success');
  };

  // Functions to get dynamic page title and description
  const getPageTitle = () => {
    switch (currentView) {
      case 'composer':
        return 'AI-Powered Social Media Manager';
      case 'inbox':
        return 'Inbox & Engagement';
      case 'ai-assistant':
        return 'AI Assistant';
      case 'ai-insights':
        return 'AI Insights';
      case 'approval-queue':
        return 'Approval Queue';
      case 'templates':
        return 'Templates Management';
      case 'upcoming-posts':
        return 'Scheduled Posts';
      case 'media-library':
        return 'Media Library';
      case 'analytics':
        return 'Analytics Dashboard';
      case 'calendar':
        return 'Content Calendar';
      case 'settings':
        return 'Settings';
      default:
        return 'AI-Powered Social Media Manager';
    }
  };

  const getPageDescription = () => {
    switch (currentView) {
      case 'composer':
        return 'Create, schedule, and analyze your social media content with AI assistance';
      case 'inbox':
        return 'Manage comments, mentions, and messages across all social media platforms';
      case 'ai-assistant':
        return 'Get AI-powered help with content creation, optimization, and strategy';
      case 'ai-insights':
        return 'Data-driven recommendations to boost your social media performance';
      case 'approval-queue':
        return 'Review and manage AI-generated replies before they are sent';
      case 'templates':
        return 'Create and manage reusable templates with variables and A/B testing';
      case 'upcoming-posts':
        return 'Manage your upcoming and published content across all platforms';
      case 'media-library':
        return 'Organize and manage your images, videos, and documents for social media';
      case 'analytics':
        return 'Comprehensive analytics and performance metrics for your content';
      case 'calendar':
        return 'Plan and schedule your content with an intuitive calendar view';
      case 'settings':
        return 'Configure your application settings and preferences';
      default:
        return 'Create, schedule, and analyze your social media content with AI assistance';
    }
  };

  // Function to render the current view
  const renderCurrentView = () => {
    switch (currentView) {
      case 'composer':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Left Column - Main Composer */}
            <div className="lg:col-span-2 space-y-4">
              <PostComposer 
                onPost={handlePost} 
                onViewChange={setCurrentView}
                onPreviewToggle={setIsPreviewVisible}
                isPreviewVisible={isPreviewVisible}
              />
              
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center">
                  <i className="fas fa-upload mr-2 text-green-500"></i>
                  Media Upload
                </h3>
                <MediaUpload onMediaUpload={handleMediaUpload} />
              </div>

              <HashtagGenerator onHashtagAdd={handleHashtagAdd} content={postContent} />
            </div>

            {/* Right Column - Preview & Tools */}
            <div className="space-y-4">
              {isPreviewVisible && (
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-semibold text-gray-700 flex items-center">
                      <i className="fas fa-mobile-alt mr-2 text-blue-500"></i>
                      Live Preview
                    </h3>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setIsPreviewVisible(false)}
                      data-testid="button-close-preview"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <i className="fas fa-times"></i>
                    </Button>
                  </div>
                  <MobilePreview 
                    content={postContent}
                    platform={currentPlatform}
                    mediaFiles={uploadedMedia}
                  />
                </div>
              )}
              <AnalyticsCard data={defaultAnalyticsData} showChart={true} onViewChange={setCurrentView} />
            </div>
          </div>
        );
      
      case 'inbox':
        return <InboxEngagement />;
      
      case 'ai-assistant':
        return <AIAssistant />;
      
      case 'ai-insights':
        return <AIInsights />;
      
      case 'upcoming-posts':
        return <UpcomingPosts />;
      
      case 'media-library':
        return <MediaLibrary />;
      
      case 'analytics':
        return (
          <div className="space-y-4">
            <AnalyticsCard data={defaultAnalyticsData} showChart={true} onViewChange={setCurrentView} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ActivityFeed onViewChange={setCurrentView} />
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Performance Metrics</h3>
                <p className="text-gray-600">Detailed analytics and performance metrics coming soon...</p>
              </div>
            </div>
          </div>
        );
      
      case 'calendar':
        return (
          <div className="space-y-4">
            <Calendar onDateClick={handleDateClick} onViewChange={setCurrentView} />
            <ActivityFeed onViewChange={setCurrentView} />
          </div>
        );
      
      case 'settings':
        return <Settings />;
      
      case 'clone-post':
        return <ClonePost onClone={handleClonePost} onViewChange={setCurrentView} />;
      
      case 'auto-replies':
        return <AutoReplies onSave={handleAutoReply} onViewChange={setCurrentView} />;
      
      case 'team-management':
        return <TeamManagement />;
      
      case 'reports':
        return <Reports />;
      
      case 'approval-queue':
        return <ApprovalQueue onViewChange={setCurrentView} />;
      
      case 'templates':
        return <Templates onViewChange={setCurrentView} />;
      
      default:
        return <PostComposer onPost={handlePost} />;
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gray-50">
          {/* Sidebar */}
          <Sidebar 
            isExpanded={isSidebarExpanded}
            onToggle={() => setIsSidebarExpanded(!isSidebarExpanded)}
            currentView={currentView}
            onViewChange={setCurrentView}
          />
          
          {/* Main Content */}
          <div 
            className={`transition-all duration-300 ${
              isSidebarExpanded ? 'ml-64' : 'ml-[100px]'
            } p-4`}
            data-testid="main-content"
          >
            <div className="max-w-7xl mx-auto">
              {/* Dynamic Header */}
              <div className="mb-4">
                <h1 className="text-xl font-bold text-gray-800 mb-1">
                  {getPageTitle()}
                </h1>
                <p className="text-gray-600">
                  {getPageDescription()}
                </p>
              </div>

              {/* Dynamic Content Based on Current View */}
              {renderCurrentView()}

              {/* Footer */}
              <div className="mt-6 text-center text-sm text-gray-500 border-t border-gray-200 pt-4">
                <p>
                  Social Media Manager • Built with React & TypeScript • 
                  <span className="ml-1 text-green-600">
                    <i className="fas fa-circle text-xs mr-1"></i>
                    AI Connected
                  </span>
                </p>
              </div>
            </div>
          </div>

          {/* Toast Notifications */}
          <Toast 
            message={toast.message}
            type={toast.type}
            isVisible={toast.isVisible}
            onClose={hideToast}
          />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
