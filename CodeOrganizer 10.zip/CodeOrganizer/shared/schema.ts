import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, jsonb, integer, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  postName: text("post_name"),
  campaignLabel: text("campaign_label"),
  platforms: jsonb("platforms").notNull(), // array of platform IDs
  firstComment: text("first_comment"),
  status: text("status").notNull().default("draft"), // draft, scheduled, published, failed
  scheduledTime: timestamp("scheduled_time"),
  publishedTime: timestamp("published_time"),
  mediaFiles: jsonb("media_files"), // array of media file references
  engagement: jsonb("engagement"), // likes, comments, shares data
  isEvergreen: boolean("is_evergreen").notNull().default(false),
  evergreenSettings: jsonb("evergreen_settings"), // repeat interval, next execution, etc.
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const autoReplies = pgTable("auto_replies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  triggerKeywords: jsonb("trigger_keywords").notNull(), // array of keywords
  responseTemplate: text("response_template").notNull(),
  platforms: jsonb("platforms").notNull(), // array of platform IDs
  isActive: boolean("is_active").notNull().default(true),
  replyType: text("reply_type").notNull(), // comment, message, both
  mode: text("mode").notNull().default("auto"), // auto, assist, manual
  intents: jsonb("intents").default("[]"), // array of intent types
  language: text("language").default("auto"), // auto or specific language code
  riskThreshold: decimal("risk_threshold").default("0.5"), // 0-1 risk threshold
  rateLimit: jsonb("rate_limit").default("{\"perMinute\": 5, \"perHour\": 50}"), // rate limiting
  schedule: jsonb("schedule").default("{\"days\": [], \"start\": \"09:00\", \"end\": \"17:00\"}"), // scheduling window
  escalateAfter: integer("escalate_after").default(3), // turns before escalation
  escalateTo: text("escalate_to"), // email/user to escalate to
  useLLM: boolean("use_llm").notNull().default(false), // enable AI generation
  modelId: text("model_id").default("gpt-3.5-turbo"), // AI model to use
  temperature: decimal("temperature").default("0.7"), // AI creativity
  maxTokens: integer("max_tokens").default(150), // response length limit
  safety: jsonb("safety").default("{\"moderate\": true, \"blockPII\": true}"), // safety settings
  abTestId: text("ab_test_id"), // A/B testing group
  settings: jsonb("settings"), // legacy settings for compatibility
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  platform: text("platform").notNull(),
  externalId: text("external_id").notNull(), // platform-specific conversation ID
  author: jsonb("author").notNull(), // {name, username, avatar, id}
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").notNull(),
  threadId: text("thread_id"), // for tracking conversation threads
  history: jsonb("history").default("[]"), // previous messages in thread
  sentiment: text("sentiment"), // positive, negative, neutral, urgent
  intent: text("intent"), // support, compliment, complaint, question, etc.
  language: text("language"), // detected language
  priority: integer("priority").default(1), // 1-5 priority level
  riskScore: decimal("risk_score").default("0"), // 0-1 risk assessment
  status: text("status").default("unread"), // unread, read, replied, escalated
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const generatedReplies = pgTable("generated_replies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").notNull().references(() => conversations.id),
  autoReplyId: varchar("auto_reply_id").references(() => autoReplies.id),
  draftText: text("draft_text").notNull(),
  finalText: text("final_text"), // edited version after human review
  mode: text("mode").notNull(), // auto, assist, manual
  approvedBy: text("approved_by"), // user who approved (if any)
  sentAt: timestamp("sent_at"), // when reply was actually sent
  status: text("status").notNull().default("draft"), // draft, approved, sent, rejected
  modelInfo: jsonb("model_info"), // {model, temperature, tokens_used, etc.}
  scores: jsonb("scores"), // {confidence, relevance, sentiment_match, etc.}
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const templates = pgTable("templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  intent: text("intent").notNull(), // support, compliment, greeting, etc.
  text: text("text").notNull(),
  variables: jsonb("variables").default("[]"), // [name, username, post, brand, etc.]
  tags: jsonb("tags").default("[]"), // for categorization and search
  isDefault: boolean("is_default").default(false),
  usageCount: integer("usage_count").default(0),
  rating: decimal("rating").default("0"), // user feedback rating
  abTestId: text("ab_test_id"), // A/B testing experiment ID
  variantType: text("variant_type"), // 'control', 'variant_a', 'variant_b', etc.
  parentTemplateId: text("parent_template_id"), // Original template for variants
  conversionCount: integer("conversion_count").default(0), // Success conversions
  impressionCount: integer("impression_count").default(0), // Times shown
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// Evergreen settings validation schema
const evergreenSettingsSchema = z.object({
  repeatInterval: z.enum(["daily", "weekly", "monthly"]),
  repeatTime: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
  repeatDays: z.array(z.string()).optional(), // For weekly
  monthlyDay: z.number().min(1).max(31).optional(), // For monthly
  endDate: z.string().nullable().optional(),
  maxRepeats: z.number().positive().nullable().optional(),
  nextExecution: z.string().nullable().optional(),
  executionCount: z.number().default(0)
}).refine(
  (data) => {
    // Weekly must have at least one day selected
    if (data.repeatInterval === "weekly") {
      return data.repeatDays && data.repeatDays.length > 0;
    }
    // Monthly must have a day specified
    if (data.repeatInterval === "monthly") {
      return data.monthlyDay && data.monthlyDay >= 1 && data.monthlyDay <= 31;
    }
    return true;
  },
  { message: "Invalid repeat configuration" }
);

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  evergreenSettings: evergreenSettingsSchema.nullable().optional()
});

// Enhanced AutoReply validation schemas
const rateLimitSchema = z.object({
  perMinute: z.number().min(1).max(60).default(5),
  perHour: z.number().min(1).max(1000).default(50)
});

const scheduleSchema = z.object({
  days: z.array(z.enum(["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"])).default([]),
  start: z.string().regex(/^\d{2}:\d{2}$/).default("09:00"),
  end: z.string().regex(/^\d{2}:\d{2}$/).default("17:00")
});

const safetySchema = z.object({
  moderate: z.boolean().default(true),
  blockPII: z.boolean().default(true)
});

export const insertAutoReplySchema = createInsertSchema(autoReplies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  triggerKeywords: z.array(z.string()).min(1, "At least one trigger keyword is required"),
  platforms: z.array(z.string()).min(1, "At least one platform must be selected"),
  mode: z.enum(["auto", "assist", "manual"]).default("auto"),
  intents: z.array(z.string()).default([]),
  language: z.string().default("auto"),
  riskThreshold: z.number().min(0).max(1).default(0.5),
  rateLimit: rateLimitSchema.default({ perMinute: 5, perHour: 50 }),
  schedule: scheduleSchema.default({ days: [], start: "09:00", end: "17:00" }),
  escalateAfter: z.number().min(1).max(10).default(3),
  useLLM: z.boolean().default(false),
  modelId: z.string().default("gpt-3.5-turbo"),
  temperature: z.number().min(0).max(2).default(0.7),
  maxTokens: z.number().min(50).max(1000).default(150),
  safety: safetySchema.default({ moderate: true, blockPII: true })
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  author: z.object({
    name: z.string(),
    username: z.string(),
    avatar: z.string().optional(),
    id: z.string()
  }),
  history: z.array(z.object({
    content: z.string(),
    timestamp: z.string(),
    author: z.string()
  })).default([]),
  sentiment: z.enum(["positive", "negative", "neutral", "urgent"]).optional(),
  intent: z.enum(["support", "compliment", "complaint", "question", "spam", "other"]).optional(),
  priority: z.number().min(1).max(5).default(1),
  riskScore: z.number().min(0).max(1).default(0),
  status: z.enum(["unread", "read", "replied", "escalated"]).default("unread")
});

export const insertGeneratedReplySchema = createInsertSchema(generatedReplies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  mode: z.enum(["auto", "assist", "manual"]),
  status: z.enum(["draft", "approved", "sent", "rejected"]).default("draft"),
  modelInfo: z.object({
    model: z.string(),
    temperature: z.number().optional(),
    tokens_used: z.number().optional(),
    processing_time: z.number().optional()
  }).optional(),
  scores: z.object({
    confidence: z.number().min(0).max(1).optional(),
    relevance: z.number().min(0).max(1).optional(),
    sentiment_match: z.number().min(0).max(1).optional(),
    risk_score: z.number().min(0).max(1).optional()
  }).optional()
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  variables: z.array(z.string()).default([]),
  tags: z.array(z.string()).default([]),
  usageCount: z.number().min(0).default(0),
  rating: z.number().min(0).max(5).default(0),
  conversionCount: z.number().min(0).default(0),
  impressionCount: z.number().min(0).default(0)
});

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertAutoReply = z.infer<typeof insertAutoReplySchema>;
export type AutoReply = typeof autoReplies.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertGeneratedReply = z.infer<typeof insertGeneratedReplySchema>;
export type GeneratedReply = typeof generatedReplies.$inferSelect;
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;
