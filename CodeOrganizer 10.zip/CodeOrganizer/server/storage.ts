import { 
  type User, type InsertUser,
  type AutoReply, type InsertAutoReply,
  type Conversation, type InsertConversation,
  type GeneratedReply, type InsertGeneratedReply,
  type Template, type InsertTemplate,
  type Post, type InsertPost
} from "@shared/schema";
import { randomUUID } from "crypto";

// Enhanced storage interface supporting AI-powered auto-replies
export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // AutoReplies management
  getAllAutoReplies(): Promise<AutoReply[]>;
  getAutoReply(id: string): Promise<AutoReply | undefined>;
  createAutoReply(autoReply: InsertAutoReply): Promise<AutoReply>;
  updateAutoReply(id: string, autoReply: Partial<InsertAutoReply>): Promise<AutoReply | undefined>;
  deleteAutoReply(id: string): Promise<boolean>;

  // Conversations management
  getAllConversations(): Promise<Conversation[]>;
  getConversation(id: string): Promise<Conversation | undefined>;
  getConversationsByPlatform(platform: string): Promise<Conversation[]>;
  getConversationsByStatus(status: string): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: string, conversation: Partial<InsertConversation>): Promise<Conversation | undefined>;
  deleteConversation(id: string): Promise<boolean>;

  // Generated Replies management (Approval Queue)
  getAllGeneratedReplies(): Promise<GeneratedReply[]>;
  getGeneratedReply(id: string): Promise<GeneratedReply | undefined>;
  getGeneratedRepliesByStatus(status: string): Promise<GeneratedReply[]>;
  getGeneratedRepliesByConversation(conversationId: string): Promise<GeneratedReply[]>;
  createGeneratedReply(reply: InsertGeneratedReply): Promise<GeneratedReply>;
  updateGeneratedReply(id: string, reply: Partial<InsertGeneratedReply>): Promise<GeneratedReply | undefined>;
  deleteGeneratedReply(id: string): Promise<boolean>;

  // Templates management
  getAllTemplates(): Promise<Template[]>;
  getTemplate(id: string): Promise<Template | undefined>;
  getTemplatesByIntent(intent: string): Promise<Template[]>;
  getTemplatesByAbTestId(abTestId: string): Promise<Template[]>;
  getTemplateVariants(parentTemplateId: string): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: string, template: Partial<InsertTemplate>): Promise<Template | undefined>;
  deleteTemplate(id: string): Promise<boolean>;
  
  // Posts management
  getAllPosts(): Promise<Post[]>;
  getPost(id: string): Promise<Post | undefined>;
  getPostsByStatus(status: string): Promise<Post[]>;
  getPostsByPlatform(platform: string): Promise<Post[]>;
  getScheduledPosts(): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, post: Partial<InsertPost>): Promise<Post | undefined>;
  deletePost(id: string): Promise<boolean>;
  
  // A/B Testing management
  getActiveExperiments(): Promise<Template[]>;
  getExperimentResults(abTestId: string): Promise<{
    experimentId: string;
    variants: Array<{
      template: Template;
      metrics: {
        impressions: number;
        conversions: number;
        conversionRate: number;
        usage: number;
        rating: number;
      };
    }>;
    totalImpressions: number;
    totalConversions: number;
    winner?: string;
  }>;
  updateTemplateMetrics(id: string, impressions: number, conversions: number): Promise<Template | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private autoReplies: Map<string, AutoReply>;
  private conversations: Map<string, Conversation>;
  private generatedReplies: Map<string, GeneratedReply>;
  private templates: Map<string, Template>;
  private posts: Map<string, Post>;

  constructor() {
    this.users = new Map();
    this.autoReplies = new Map();
    this.conversations = new Map();
    this.generatedReplies = new Map();
    this.templates = new Map();
    this.posts = new Map();
  }

  // User management
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // AutoReplies management
  async getAllAutoReplies(): Promise<AutoReply[]> {
    return Array.from(this.autoReplies.values());
  }

  async getAutoReply(id: string): Promise<AutoReply | undefined> {
    return this.autoReplies.get(id);
  }

  async createAutoReply(insertAutoReply: InsertAutoReply): Promise<AutoReply> {
    const id = randomUUID();
    const now = new Date();
    const autoReply: AutoReply = {
      ...insertAutoReply,
      id,
      isActive: insertAutoReply.isActive ?? true,
      riskThreshold: String(insertAutoReply.riskThreshold ?? 0.5),
      temperature: String(insertAutoReply.temperature ?? 0.7),
      escalateAfter: insertAutoReply.escalateAfter ?? 3,
      maxTokens: insertAutoReply.maxTokens ?? 150,
      escalateTo: insertAutoReply.escalateTo || null,
      createdAt: now,
      updatedAt: now,
    };
    this.autoReplies.set(id, autoReply);
    return autoReply;
  }

  async updateAutoReply(id: string, updates: Partial<InsertAutoReply>): Promise<AutoReply | undefined> {
    const existing = this.autoReplies.get(id);
    if (!existing) return undefined;

    const updated: AutoReply = {
      ...existing,
      ...updates,
      riskThreshold: updates.riskThreshold !== undefined ? String(updates.riskThreshold) : existing.riskThreshold,
      temperature: updates.temperature !== undefined ? String(updates.temperature) : existing.temperature,
      updatedAt: new Date(),
    };
    this.autoReplies.set(id, updated);
    return updated;
  }

  async deleteAutoReply(id: string): Promise<boolean> {
    return this.autoReplies.delete(id);
  }

  // Conversations management
  async getAllConversations(): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getConversationsByPlatform(platform: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .filter(conv => conv.platform === platform)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getConversationsByStatus(status: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .filter(conv => conv.status === status)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const now = new Date();
    const conversation: Conversation = {
      ...insertConversation,
      id,
      language: insertConversation.language || null,
      riskScore: String(insertConversation.riskScore ?? 0),
      priority: insertConversation.priority ?? 1,
      status: insertConversation.status ?? 'unread',
      threadId: insertConversation.threadId || null,
      createdAt: now,
      updatedAt: now,
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async updateConversation(id: string, updates: Partial<InsertConversation>): Promise<Conversation | undefined> {
    const existing = this.conversations.get(id);
    if (!existing) return undefined;

    const updated: Conversation = {
      ...existing,
      ...updates,
      riskScore: updates.riskScore !== undefined ? String(updates.riskScore) : existing.riskScore,
      updatedAt: new Date(),
    };
    this.conversations.set(id, updated);
    return updated;
  }

  async deleteConversation(id: string): Promise<boolean> {
    return this.conversations.delete(id);
  }

  // Generated Replies management (Approval Queue)
  async getAllGeneratedReplies(): Promise<GeneratedReply[]> {
    return Array.from(this.generatedReplies.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getGeneratedReply(id: string): Promise<GeneratedReply | undefined> {
    return this.generatedReplies.get(id);
  }

  async getGeneratedRepliesByStatus(status: string): Promise<GeneratedReply[]> {
    return Array.from(this.generatedReplies.values())
      .filter(reply => reply.status === status)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getGeneratedRepliesByConversation(conversationId: string): Promise<GeneratedReply[]> {
    return Array.from(this.generatedReplies.values())
      .filter(reply => reply.conversationId === conversationId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createGeneratedReply(insertGeneratedReply: InsertGeneratedReply): Promise<GeneratedReply> {
    const id = randomUUID();
    const now = new Date();
    const generatedReply: GeneratedReply = {
      ...insertGeneratedReply,
      id,
      autoReplyId: insertGeneratedReply.autoReplyId || null,
      finalText: insertGeneratedReply.finalText || null,
      approvedBy: insertGeneratedReply.approvedBy || null,
      sentAt: insertGeneratedReply.sentAt || null,
      modelInfo: insertGeneratedReply.modelInfo || {},
      scores: insertGeneratedReply.scores || {},
      createdAt: now,
      updatedAt: now,
    };
    this.generatedReplies.set(id, generatedReply);
    return generatedReply;
  }

  async updateGeneratedReply(id: string, updates: Partial<InsertGeneratedReply>): Promise<GeneratedReply | undefined> {
    const existing = this.generatedReplies.get(id);
    if (!existing) return undefined;

    const updated: GeneratedReply = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };
    this.generatedReplies.set(id, updated);
    return updated;
  }

  async deleteGeneratedReply(id: string): Promise<boolean> {
    return this.generatedReplies.delete(id);
  }

  // Templates management
  async getAllTemplates(): Promise<Template[]> {
    return Array.from(this.templates.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getTemplate(id: string): Promise<Template | undefined> {
    return this.templates.get(id);
  }

  async getTemplatesByIntent(intent: string): Promise<Template[]> {
    return Array.from(this.templates.values())
      .filter(template => template.intent === intent)
      .sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0)); // Sort by usage count
  }

  async createTemplate(insertTemplate: InsertTemplate): Promise<Template> {
    const id = randomUUID();
    const now = new Date();
    const template: Template = {
      ...insertTemplate,
      id,
      isDefault: insertTemplate.isDefault ?? false,
      usageCount: insertTemplate.usageCount ?? 0,
      rating: String(insertTemplate.rating ?? 0),
      abTestId: insertTemplate.abTestId || null,
      variantType: insertTemplate.variantType || null,
      parentTemplateId: insertTemplate.parentTemplateId || null,
      conversionCount: insertTemplate.conversionCount ?? 0,
      impressionCount: insertTemplate.impressionCount ?? 0,
      createdAt: now,
      updatedAt: now,
    };
    this.templates.set(id, template);
    return template;
  }

  async updateTemplate(id: string, updates: Partial<InsertTemplate>): Promise<Template | undefined> {
    const existing = this.templates.get(id);
    if (!existing) return undefined;

    const updated: Template = {
      ...existing,
      ...updates,
      rating: updates.rating !== undefined ? String(updates.rating) : existing.rating,
      updatedAt: new Date(),
    };
    this.templates.set(id, updated);
    return updated;
  }

  async deleteTemplate(id: string): Promise<boolean> {
    return this.templates.delete(id);
  }

  // A/B Testing management implementation
  async getTemplatesByAbTestId(abTestId: string): Promise<Template[]> {
    return Array.from(this.templates.values())
      .filter(template => template.abTestId === abTestId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async getTemplateVariants(parentTemplateId: string): Promise<Template[]> {
    return Array.from(this.templates.values())
      .filter(template => template.parentTemplateId === parentTemplateId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async getActiveExperiments(): Promise<Template[]> {
    // Get all templates that are part of active A/B tests (have abTestId)
    const experimentsMap = new Map<string, Template>();
    
    Array.from(this.templates.values())
      .filter(template => template.abTestId && template.variantType === 'control')
      .forEach(template => {
        if (template.abTestId) {
          experimentsMap.set(template.abTestId, template);
        }
      });

    return Array.from(experimentsMap.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getExperimentResults(abTestId: string): Promise<{
    experimentId: string;
    variants: Array<{
      template: Template;
      metrics: {
        impressions: number;
        conversions: number;
        conversionRate: number;
        usage: number;
        rating: number;
      };
    }>;
    totalImpressions: number;
    totalConversions: number;
    winner?: string;
  }> {
    const variants = await this.getTemplatesByAbTestId(abTestId);
    
    const processedVariants = variants.map(template => ({
      template,
      metrics: {
        impressions: template.impressionCount || 0,
        conversions: template.conversionCount || 0,
        conversionRate: template.impressionCount ? 
          ((template.conversionCount || 0) / template.impressionCount) * 100 : 0,
        usage: template.usageCount || 0,
        rating: typeof template.rating === 'string' ? parseFloat(template.rating) : (template.rating || 0)
      }
    }));

    const totalImpressions = processedVariants.reduce((sum, v) => sum + v.metrics.impressions, 0);
    const totalConversions = processedVariants.reduce((sum, v) => sum + v.metrics.conversions, 0);

    // Determine winner based on conversion rate and statistical significance
    let winner: string | undefined;
    if (processedVariants.length > 1 && totalImpressions > 100) {
      const sortedByConversion = [...processedVariants].sort((a, b) => b.metrics.conversionRate - a.metrics.conversionRate);
      if (sortedByConversion[0].metrics.conversionRate > sortedByConversion[1].metrics.conversionRate * 1.1) {
        winner = sortedByConversion[0].template.id;
      }
    }

    return {
      experimentId: abTestId,
      variants: processedVariants,
      totalImpressions,
      totalConversions,
      winner
    };
  }

  async updateTemplateMetrics(id: string, impressions: number, conversions: number): Promise<Template | undefined> {
    const existing = this.templates.get(id);
    if (!existing) return undefined;

    const updated: Template = {
      ...existing,
      impressionCount: (existing.impressionCount || 0) + impressions,
      conversionCount: (existing.conversionCount || 0) + conversions,
      usageCount: (existing.usageCount || 0) + 1,
      updatedAt: new Date(),
    };
    this.templates.set(id, updated);
    return updated;
  }

  // Posts management
  async getAllPosts(): Promise<Post[]> {
    return Array.from(this.posts.values());
  }

  async getPost(id: string): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPostsByStatus(status: string): Promise<Post[]> {
    return Array.from(this.posts.values()).filter(post => post.status === status);
  }

  async getPostsByPlatform(platform: string): Promise<Post[]> {
    return Array.from(this.posts.values()).filter(post => {
      const platforms = Array.isArray(post.platforms) ? post.platforms : [];
      return platforms.includes(platform);
    });
  }

  async getScheduledPosts(): Promise<Post[]> {
    return Array.from(this.posts.values()).filter(post => 
      post.status === 'scheduled' && post.scheduledTime
    );
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const now = new Date();
    const post: Post = {
      ...insertPost,
      id,
      status: insertPost.status || 'draft',
      createdAt: now,
      updatedAt: now,
    };
    this.posts.set(id, post);
    return post;
  }

  async updatePost(id: string, updates: Partial<InsertPost>): Promise<Post | undefined> {
    const existing = this.posts.get(id);
    if (!existing) return undefined;

    const updated: Post = {
      ...existing,
      ...updates,
      updatedAt: new Date(),
    };
    this.posts.set(id, updated);
    return updated;
  }

  async deletePost(id: string): Promise<boolean> {
    return this.posts.delete(id);
  }
}

export const storage = new MemStorage();
