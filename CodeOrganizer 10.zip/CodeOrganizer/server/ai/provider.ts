import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT - using javascript_gemini integration
// Note that the newest Gemini model series is "gemini-2.5-flash" or "gemini-2.5-pro"

// AI Provider Interface
export interface IAIProvider {
  classify(text: string, context?: string): Promise<ClassificationResult>;
  generate(request: GenerationRequest): Promise<GenerationResult>;
  moderate(text: string): Promise<ModerationResult>;
  generatePostContent(prompt: string, type?: string): Promise<{ content?: string; text?: string }>;
  optimizePostContent(content: string, platforms: string[], postType: string): Promise<{ optimizedContent?: string; content?: string }>;
}

// Classification types and interfaces
export interface ClassificationResult {
  sentiment: 'positive' | 'negative' | 'neutral' | 'urgent';
  intent: 'support' | 'compliment' | 'complaint' | 'question' | 'spam' | 'other';
  language: string;
  riskScore: number; // 0-1
  confidence: number; // 0-1
  priority: number; // 1-5
}

export interface GenerationRequest {
  context: string; // original message content
  conversationHistory?: Array<{content: string, author: string, timestamp: string}>;
  platform: string;
  template?: string;
  variables?: Record<string, string>;
  intent?: string;
  tone?: 'friendly' | 'professional' | 'casual' | 'apologetic';
  maxLength?: number;
  temperature?: number;
}

export interface GenerationResult {
  text: string;
  confidence: number;
  relevance: number;
  sentimentMatch: number;
  riskScore: number;
  tokensUsed?: number;
  processingTime: number;
  model: string;
}

export interface ModerationResult {
  flagged: boolean;
  categories: Array<{
    category: string;
    flagged: boolean;
    score: number;
  }>;
  hasPII: boolean;
  riskScore: number;
}

// Gemini AI Provider Implementation
export class GeminiAIProvider implements IAIProvider {
  private ai: GoogleGenAI;
  private model: string = "gemini-2.5-flash"; // Using Flash-Lite as requested

  constructor() {
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    this.ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }

  async classify(text: string, context?: string): Promise<ClassificationResult> {
    try {
      const startTime = Date.now();
      
      const prompt = `Analyze this social media message and provide classification in JSON format:

Message: "${text}"
${context ? `Context: ${context}` : ''}

Provide response in this exact JSON format:
{
  "sentiment": "positive|negative|neutral|urgent",
  "intent": "support|compliment|complaint|question|spam|other", 
  "language": "language_code",
  "riskScore": number_between_0_and_1,
  "confidence": number_between_0_and_1,
  "priority": number_between_1_and_5
}

Classification guidelines:
- sentiment: "urgent" for time-sensitive issues or emergencies, "negative" for complaints/criticism, "positive" for praise/thanks, "neutral" for factual queries
- intent: categorize based on user's primary purpose
- language: detect language (use ISO codes like "en", "es", "fr")
- riskScore: 0.8+ for offensive/spam content, 0.5+ for negative sentiment, 0.2- for positive
- confidence: how certain you are about the classification (0-1)
- priority: 5=urgent, 4=complaint, 3=question, 2=compliment, 1=general`;

      const response = await this.ai.models.generateContent({
        model: this.model,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              sentiment: { type: "string" },
              intent: { type: "string" },
              language: { type: "string" },
              riskScore: { type: "number" },
              confidence: { type: "number" },
              priority: { type: "number" }
            },
            required: ["sentiment", "intent", "language", "riskScore", "confidence", "priority"]
          }
        },
        contents: prompt
      });

      const result = JSON.parse(response.text || '{}');
      
      return {
        sentiment: result.sentiment || 'neutral',
        intent: result.intent || 'other',
        language: result.language || 'en',
        riskScore: Math.max(0, Math.min(1, result.riskScore || 0)),
        confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
        priority: Math.max(1, Math.min(5, Math.round(result.priority || 3)))
      };
    } catch (error) {
      console.error('Classification error:', error);
      // Return safe defaults
      return {
        sentiment: 'neutral',
        intent: 'other', 
        language: 'en',
        riskScore: 0.5,
        confidence: 0.3,
        priority: 3
      };
    }
  }

  async generate(request: GenerationRequest): Promise<GenerationResult> {
    try {
      const startTime = Date.now();
      
      // Platform-specific character limits
      const platformLimits: Record<string, number> = {
        twitter: 280,
        instagram: 2200,
        facebook: 63206,
        linkedin: 3000,
        youtube: 10000,
        tiktok: 2200,
        snapchat: 250
      };

      const maxLength = request.maxLength || platformLimits[request.platform] || 300;
      const temperature = request.temperature || 0.7;

      let prompt = `Generate a ${request.tone || 'friendly'} social media response for ${request.platform}.

Original message: "${request.context}"
${request.intent ? `Message intent: ${request.intent}` : ''}
${request.template ? `Use this template as inspiration: "${request.template}"` : ''}

Requirements:
- Maximum ${maxLength} characters
- ${request.tone || 'Friendly'} and professional tone
- Appropriate for ${request.platform} platform
- Address the user's ${request.intent || 'message'} directly
- Be helpful and engaging`;

      if (request.conversationHistory && request.conversationHistory.length > 0) {
        prompt += `\n\nConversation history:\n${request.conversationHistory
          .slice(-3) // Last 3 messages for context
          .map(msg => `${msg.author}: ${msg.content}`)
          .join('\n')}`;
      }

      if (request.variables) {
        prompt += `\n\nAvailable variables to use: ${Object.entries(request.variables)
          .map(([key, value]) => `[${key}] = "${value}"`)
          .join(', ')}`;
      }

      prompt += '\n\nGenerate only the response text, no quotes or formatting.';

      const response = await this.ai.models.generateContent({
        model: this.model,
        contents: prompt,
        config: {
          temperature: temperature,
          maxOutputTokens: Math.min(1000, Math.ceil(maxLength / 3)) // Rough token estimate
        }
      });

      const generatedText = response.text?.trim() || '';
      const processingTime = Date.now() - startTime;

      // Simple scoring based on response quality
      const confidence = generatedText.length > 10 ? 0.8 : 0.4;
      const relevance = request.intent && generatedText.toLowerCase().includes(request.intent) ? 0.9 : 0.7;
      const sentimentMatch = 0.8; // Would need sentiment analysis of generated text for accuracy

      return {
        text: generatedText,
        confidence,
        relevance,
        sentimentMatch,
        riskScore: 0.1, // Generated responses should be low risk
        tokensUsed: Math.ceil(generatedText.length / 4), // Rough estimate
        processingTime,
        model: this.model
      };
    } catch (error) {
      console.error('Generation error:', error);
      throw new Error(`Failed to generate response: ${error}`);
    }
  }

  async moderate(text: string): Promise<ModerationResult> {
    try {
      const prompt = `Analyze this text for harmful content and personally identifiable information:

Text: "${text}"

Provide response in JSON format:
{
  "flagged": boolean,
  "categories": [
    {"category": "harassment", "flagged": boolean, "score": number_0_to_1},
    {"category": "hate_speech", "flagged": boolean, "score": number_0_to_1},
    {"category": "spam", "flagged": boolean, "score": number_0_to_1},
    {"category": "violence", "flagged": boolean, "score": number_0_to_1}
  ],
  "hasPII": boolean,
  "riskScore": number_0_to_1
}

Flag content that contains harassment, hate speech, spam, violence, or PII (emails, phone numbers, addresses, SSN, etc.)`;

      const response = await this.ai.models.generateContent({
        model: this.model,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              flagged: { type: "boolean" },
              categories: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    category: { type: "string" },
                    flagged: { type: "boolean" },
                    score: { type: "number" }
                  }
                }
              },
              hasPII: { type: "boolean" },
              riskScore: { type: "number" }
            },
            required: ["flagged", "categories", "hasPII", "riskScore"]
          }
        },
        contents: prompt
      });

      const result = JSON.parse(response.text || '{}');

      return {
        flagged: result.flagged || false,
        categories: result.categories || [],
        hasPII: result.hasPII || false,
        riskScore: Math.max(0, Math.min(1, result.riskScore || 0))
      };
    } catch (error) {
      console.error('Moderation error:', error);
      // Return safe defaults - flag as risky when in doubt
      return {
        flagged: true,
        categories: [
          { category: "unknown", flagged: true, score: 0.5 }
        ],
        hasPII: false,
        riskScore: 0.5
      };
    }
  }

  async generatePostContent(prompt: string, type: string = 'content-generation'): Promise<{ content?: string; text?: string }> {
    try {
      const response = await this.ai.models.generateContent({
        model: this.model,
        contents: prompt,
        config: {
          temperature: 0.8,
          maxOutputTokens: 1000
        }
      });

      const generatedText = response.text?.trim() || '';
      return {
        content: generatedText,
        text: generatedText
      };
    } catch (error) {
      console.error('Post content generation error:', error);
      throw new Error(`Failed to generate post content: ${error}`);
    }
  }

  async optimizePostContent(content: string, platforms: string[], postType: string): Promise<{ optimizedContent?: string; content?: string }> {
    try {
      const platformText = platforms.length > 0 ? platforms.join(', ') : 'social media';
      const prompt = `Optimize this ${postType} post for ${platformText}:

"${content}"

Make it more engaging by:
- Improving readability and flow
- Adding relevant hashtags if appropriate
- Using platform-specific best practices
- Keeping the core message intact
- Making it more engaging and shareable

Return only the optimized content without quotes or explanations.`;

      const response = await this.ai.models.generateContent({
        model: this.model,
        contents: prompt,
        config: {
          temperature: 0.7,
          maxOutputTokens: 1000
        }
      });

      const optimizedText = response.text?.trim() || content;
      return {
        optimizedContent: optimizedText,
        content: optimizedText
      };
    } catch (error) {
      console.error('Post content optimization error:', error);
      // Return original content if optimization fails
      return {
        optimizedContent: content,
        content: content
      };
    }
  }
}

// Factory function to get AI provider
export function createAIProvider(): IAIProvider {
  return new GeminiAIProvider();
}

// Export default provider instance
export const aiProvider = createAIProvider();